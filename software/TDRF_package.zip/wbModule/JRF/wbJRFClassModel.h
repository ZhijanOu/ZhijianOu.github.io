// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// class-based TDRF models.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/** 
 * \file
 * \author wangbin
 * \date 2014-11-13
 * \brief 
 */
#pragma once
#include "wbJRFCDmodel.h"

namespace wbJRF
{
#ifdef Scheme1
	typedef  CDmodel_len ClassModel_base;
#else
	typedef  CDmodel ClassModel_base;
#endif
	/** 
	 * \class
	 * \brief class model. 
	 */
	class ClassModel_len : public ClassModel_base
	{
	public:
		//wbDArray<wbArray<double>*> *m_pClassProb;
		int m_nClassAccept;
		int m_nClassTotal;
		int m_nClassGibbsTimes;

		int m_nJumpAccept;
		int m_nJumpTotal;
	public:
		ClassModel_len(Vocab *vocab, int maxLen = 10) : ClassModel_base(vocab, maxLen)
		{
			//m_pClassProb = NULL;
			m_nClassAccept = 0;
			m_nClassTotal = 0;
			m_nClassGibbsTimes = 1;

			m_nJumpAccept = 0;
			m_nJumpTotal = 0;
		}
		virtual void PrepareInitModel(bool bAllockMsgBuffer = false)
		{
			ClassModel_base::PrepareInitModel(bAllockMsgBuffer);

// 			m_bContainPredictGram = false;
// 			m_bContainMixGram = false;

			if ( !m_bContainClassGram ) {
				lout_error("[ClassModel] No class features !!!");
			}
		}

		/// �޶����Ӵ˿̿�ʼ����������class����
// 		void ClassOn();
// 		///�޶����Ӵ˿̿�ʼ������������class����
// 		void ExceptClassOn();
// 		///��ԭ��ǣ���ClassOn��ExceptClassOn������ʹ��
// 		void Off();

		/// ����ֲ�����
		//LogP GetWeightSum_Class(VocabID *pSeq, int nLen, int nPos);
		/// ����ֲ�����
		//LogP GetWeightSum_ExceptClass(VocabID *pSeq, int nLen, int nPos);

		/// ��posλ�ý��в���
		virtual LogP GibbsSample(VocabID *pSeq, int nLen, int pos, bool bSample = true);
		/// ������λ����һ��Gibbs����
		virtual void GibbsSample(VocabID *pSeq, int nLen);

		///һ��GibbsSample
		virtual void OneGibbsSample(VocabID *pSeq, int nLen, int pos);
		/// һ�β���
		virtual void OneSampling(VocabID *pSeq, int &nLen);

		virtual void Sampling(VocabID *pSeq, int &nLen, int nTimes  = 1 )
		{
			for (int i=0; i<nTimes; i++)
				OneSampling(pSeq, nLen);
		}

		virtual void ClassProposal(Prob *pJumpProb, VocabID *pSeq, int nLen, int nPos);

		///�����뵱ǰclass��ص�����
		void FindFeatures_class(wbArray<int> &a, VocabID *pSeq, int nLen, int h, int nOrder, int tagPos);
		/// ��ü���㸽����Ȩ�غͣ�
		virtual LogP GetWeightSum_class(VocabID *pSeq, int nLen, int nPos);
	};
}