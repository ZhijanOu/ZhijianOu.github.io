// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF models estimation. Joint SA estimation
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFSA.h"

namespace wbJRF
{
	bool SATaskPack::Process(int nThreadId)
	{
		//wbThreadManager::Printf( nThreadId, "[task %d] process!\n", this->nId );

		memset(m_pFeatCount, 0, sizeof(m_pFeatCount[0])*(m_pModel->m_nFeatNum));
		memset(m_pLenCount, 0, sizeof(m_pLenCount[0])*(m_pModel->m_nMaxLen+1));

		m_pLenFeatTrie->Clean();

#ifdef Hessian
		//m_pDArrayCount->Fill(0);
		memset(m_pFeatSquareCount, 0, sizeof(m_pFeatSquareCount[0]) * (m_pModel->m_nFeatNum) );
#endif
#ifdef _LBFGS
		memset(m_pWeightedFeatCount, 0, sizeof(m_pWeightedFeatCount[0]) * (m_pModel->m_nFeatNum) );
		memset(m_pLenWeightedCount, 0, sizeof(m_pLenWeightedCount[0]) * (m_pModel->m_nMaxLen+1) );
#endif
#ifdef _Class
		m_pClassCount->Clean();
#endif

		for (int n=0; n<m_nSampleNum; n++) {

			//����
			m_pModel->Sampling(m_pSeqBuf, *m_pnSeqLen, m_nSampleStep);


			//ȷ���������Trie
			bool bFound;
			wbTrie<int, int> *pSubTrie = m_pLenFeatTrie->InsertTrie(m_pnSeqLen, 1, bFound);
			
			// wb: 2014-11-4
			//ʹ��Hash���ٲ��ҵ�ǰ���м��������
			wbLHash<int, int> aCurFeatNum;
			wbArray<int> aFeatures;
			for (int nOrder=1; nOrder<=m_pModel->m_nOrder; nOrder++) {
				for (int h=0; h<=*m_pnSeqLen-nOrder; h++) {
					aFeatures.Clean();
					m_pModel->FindFeatures(aFeatures, m_pSeqBuf, *m_pnSeqLen, h, nOrder);
					for (int i=0; i<aFeatures.GetNum(); i++) {
						int *p = aCurFeatNum.Insert(aFeatures[i], bFound);
						if ( !bFound ) *p = 0;
						(*p)++;
					}
				}
			}

			wbLHashIter<int, int> iter(&aCurFeatNum);
			int nFeat, *pCount;
			while( pCount = iter.Next( nFeat ) ) {
				int temp = *pCount;
				m_pFeatCount[nFeat] += temp;
				if ( temp > 0 ) {
					int *pCount = pSubTrie->Insert(&nFeat, 1, bFound);
					if (!bFound)
						*pCount = 0;
					(*pCount) += temp;
#ifdef Hessian
					//m_pDArrayCount->Get(*m_pnSeqLen, nFeat) += temp;
					m_pFeatSquareCount[nFeat] += temp*temp;
#endif
				}
			}

#ifdef _LBFGS
			if ( m_pVectorS )
			{
				double dAlpha = 0;  
				iter.Init();
				while ( pCount = iter.Next(nFeat) ) { //���� F^T * s
					dAlpha += (*pCount) * m_pVectorS[nFeat];
				}
				iter.Init();
				while ( pCount = iter.Next(nFeat) ) {
					m_pWeightedFeatCount[nFeat] += dAlpha * (*pCount);
				}
				m_pLenWeightedCount[*m_pnSeqLen] += dAlpha;
			}
			
#endif

#ifdef _Class
			//wbTrie<int, int> *pSubClassCount = m_pClassCount->InsertTrie(m_pnSeqLen, 1, bFound);
			int idx[3];
			idx[0] = *m_pnSeqLen;
			//ͳ��ÿ��λ�ô�Class���ִ���
			for (int h=0; h<*m_pnSeqLen; h++) {
				VocabID nc = m_pModel->m_pVocab->aVocabInfo[m_pSeqBuf[h]].cid;
				idx[1] = h; //λ��
				idx[2] = nc; //���
				int *pCount = m_pClassCount->Insert(idx, 3, bFound);
				if ( !bFound )
					*pCount = 0;
				*pCount += 1;
			}
#endif

			//ͳ��ÿ�����ȵĳ��ִ���
			m_pLenCount[*m_pnSeqLen] += 1;
			titlePrecent();
		}
// 		wbFile f("e:\\wangbin\\dbg\\tests.txt", "wt");
// 		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
// 			if ( m_pFeatCount[i] > 0 )
// 				f.Print("%d\t%d\n", i, m_pFeatCount[i]);
// 		}

		//wbThreadManager::Printf( nThreadId, "[task %d] finished!\n", this->nId );

		return true;
	}

	wbTaskPack *SAThreadMager::CreateTask()
	{
		if (m_nTaskNum >= m_nThreadNum)
			return NULL;

		SATaskPack *pTask = new SATaskPack(m_nTaskNum);
		pTask->m_pModel = m_pModel;
		pTask->m_nSampleNum = m_pSampleNum[m_nTaskNum];
		pTask->m_nSampleStep = m_nSampleStep;
		pTask->m_pSeqBuf = m_ppSeqBuf[m_nTaskNum];
		pTask->m_pnSeqLen = &m_pSeqLen[m_nTaskNum];
		pTask->m_pFeatCount = m_ppFeatCount[m_nTaskNum];
		pTask->m_pLenCount = m_ppLenCount[m_nTaskNum];
		pTask->m_pLenFeatTrie = &m_pLenFeatTries[m_nTaskNum];
#ifdef Hessian
		//pTask->m_pDArrayCount = m_ppLenFeatCount[m_nTaskNum];
		pTask->m_pFeatSquareCount = m_ppFeatSquareCount[m_nTaskNum];
#endif
#ifdef _LBFGS
		pTask->m_pVectorS = m_pVectorS;
		pTask->m_pWeightedFeatCount = m_ppWeightedFeatCount[m_nTaskNum];
		pTask->m_pLenWeightedCount = m_ppLenWeightCount[m_nTaskNum];
#endif
#ifdef _Class
		pTask->m_pClassCount = &m_pClassCount[m_nTaskNum];
#endif
		//m_nCurTask++;
		m_nTaskNum++;

		return pTask;
	}

	void SAThreadMager::Save(wbFile &file)
	{
		// ���浱ǰ������
		file.Print("thread=%d\n", m_nThreadNum);
		for (int i=0; i<m_nThreadNum; i++)
		{
			file.Print("len=%d\t", m_pSeqLen[i]);
			for (int n=0; n<m_pSeqLen[i]; n++)
				file.Print("%d ", m_ppSeqBuf[i][n]);
			file.Print("\n");
		}
		file.Close();
	}
	void SAThreadMager::Load(wbFile &file)
	{
		if ( file.Good() == false )
			return;

		int thread;
		fscanf(file, "thread=%d\n", &thread);
		for (int i=0; i<min(thread, m_nThreadNum); i++)
		{
			fscanf(file, "len=%d\t", &m_pSeqLen[i]);
			for (int n=0; n<m_pSeqLen[i]; n++)
				fscanf(file, "%d ", &m_ppSeqBuf[i][n]);
			fscanf(file, "\n");
		}

		lout<<"[SAThreadMager] Load "<<min(thread, m_nThreadNum)<<" Sequences"<<endl;
		for (int i=0; i<min(thread, m_nThreadNum); i++) {
			lout<<" \t len="<<m_pSeqLen[i]<<endl;
		}
		lout<<"[SAThreadMager] End"<<endl;
	}
	void SAThreadMager::GetResult(double *pPnfi, wbDArray<double> *pLenFeatExp /*= NULL*/)
	{
		memset(pPnfi, 0, sizeof(pPnfi[0])*(m_pModel->m_nFeatNum));
		for (int t=0; t<m_nThreadNum; t++) {
			for (int i=0; i<m_pModel->m_nFeatNum; i++) {
				pPnfi[i] += 1.0 * m_ppFeatCount[t][i] / m_nMinBatch; 
			}
		}

		if ( pLenFeatExp ) 
		{
			pLenFeatExp->Fill(0);
			for (int j=1; j<=m_pModel->m_nMaxLen; j++) { //length 
				int nTotalNum = 0;
				for (int t=0; t<m_nThreadNum; t++)
					nTotalNum += m_ppLenCount[t][j];

				if (nTotalNum == 0 )
					continue;
				bool bFound;
				for (int t=0; t<m_nThreadNum; t++) {
					wbTrie<int,int> *pSub = m_pLenFeatTries[t].FindTrie(&j, 1, bFound);
					if (pSub) {
						wbTrieIter<int, int> iter(*pSub);
						int nFeat;
						wbTrie<int, int> *p;
						while ( p = iter.Next(nFeat) ) {
							pLenFeatExp->Get(j, nFeat) += 1.0 * (*p->GetData()) / m_nMinBatch/*nTotalNum*/; //����min-batch��Ŀ
						}
					}
				}
			}
		}

#ifdef Scheme1
		CDmodel_len *pM = (CDmodel_len*)m_pModel;
		pM->m_nLocalTimes = m_nMinBatch;
		for (int j=1; j<=m_pModel->m_nMaxLen; j++) {
			pM->m_aAverageNum[j] = 0;
			for (int t=0; t<m_nThreadNum; t++)
				pM->m_aAverageNum[j] += 1.0 * m_ppLenCount[t][j] / m_nMinBatch;
		}
#endif

	}
	void SAThreadMager::GetResult_lenProb(double *pLenProbs)
	{
		memset( pLenProbs, 0, sizeof(double) * (m_pModel->m_nMaxLen+1) );
		for (int t=0; t<m_nThreadNum; t++) {
			for (int len=1; len<=m_pModel->m_nMaxLen; len++)
				pLenProbs[len] += m_ppLenCount[t][len];
		}
		LineNormalize(pLenProbs+1, m_pModel->m_nMaxLen);
	}
#ifdef Hessian
	void SAThreadMager::GetResult_Hessian(double *pFeatSquareExp /* = NULL */, wbDArray<double> *pLenFeatExp /* = NULL */)
	{
		//��� p[f_k^2]
		if (pFeatSquareExp)
		{
			memset(pFeatSquareExp, 0, sizeof(pFeatSquareExp[0])*(m_pModel->m_nFeatNum));
			for (int t=0; t<m_nThreadNum; t++) {
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					pFeatSquareExp[i] += 1.0 * m_ppFeatSquareCount[t][i] / m_nMinBatch; 
				}
			}
		}


		//��ÿ�����ȵ�����������ͳ��
		if (pLenFeatExp)
		{
			pLenFeatExp->Fill(0);
			
			int idx[3];
			bool bFound;

			wbArray<int> aLenCount(m_pModel->m_nMaxLen+1); //ͳ�Ʋ�ͬ���ȵ�count
			aLenCount.Fill(0);
			for (int t=0; t<m_nThreadNum; t++) {
				for (int len=1; len<=m_pModel->m_nMaxLen; len++)
					aLenCount[len] += m_ppLenCount[t][len];
			}

			for (int t=0; t<m_nThreadNum; t++)
			{
				wbTrieIter2<int, int> iterCount(m_pLenFeatTries[t], idx, 2);
				wbTrie<int, int> *pSubCount;
				while (pSubCount = iterCount.Next()) {
					int n = *(pSubCount->GetData());
					lout_assert(aLenCount[idx[0]] > 0);
					pLenFeatExp->Get(idx[0], idx[1]) += 1.0 * n / aLenCount[idx[0]];
				}
			}

// 			for (int j=1; j<=m_pModel->m_nMaxLen; j++) { //length 
// 				int nTotalNum = 0;
// 				for (int t=0; t<m_nThreadNum; t++)
// 					nTotalNum += m_ppLenCount[t][j];
// 
// 				for (int i=0; i<m_pModel->m_nFeatNum; i++) { // features 
// 					int nTotalFeat = 0;
// 					for (int t=0; t<m_nThreadNum; t++)
// 						nTotalFeat += m_ppLenFeatCount[t]->Get(j, i);
// 
// 					pLenFeatExp->Get(j, i) = (nTotalNum != 0)? 1.0 * nTotalFeat / nTotalNum : 0;
// 				}
// 			}
		}
	}
	void SAThreadMager::GetResult_Hessian(double *pFeatSquareExp /*=NULL*/ , wbTrie<int, double> *pLenFeatExp /*= NULL*/  )
	{
		//��� p[f_k^2]
		if (pFeatSquareExp)
		{
			memset(pFeatSquareExp, 0, sizeof(pFeatSquareExp[0])*(m_pModel->m_nFeatNum));
			for (int t=0; t<m_nThreadNum; t++) {
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					pFeatSquareExp[i] += 1.0 * m_ppFeatSquareCount[t][i] / m_nMinBatch; 
				}
			}
		}
		if ( pLenFeatExp )
		{
			int idx[3];
			bool bFound;

			wbArray<int> aLenCount(m_pModel->m_nMaxLen+1); //ͳ�Ʋ�ͬ���ȵ�count
			aLenCount.Fill(0);
			for (int t=0; t<m_nThreadNum; t++) {
				for (int len=1; len<=m_pModel->m_nMaxLen; len++)
					aLenCount[len] += m_ppLenCount[t][len];
			}

			for (int t=0; t<m_nThreadNum; t++)
			{
				wbTrieIter2<int, int> iterCount(m_pLenFeatTries[t], idx, 2);
				wbTrie<int, int> *pSubCount;
				while (pSubCount = iterCount.Next()) {
					int n = *(pSubCount->GetData());
					double *pdTemp = pLenFeatExp->Insert(idx, 2, bFound);
					if ( !bFound ) *pdTemp = 0;
					lout_assert(aLenCount[idx[0]] > 0);
					*pdTemp += 1.0 * n / aLenCount[idx[0]];
				}
			}
		}
	}
#endif
#ifdef _LBFGS
	void SAThreadMager::GetResult_LBFGS(double *pWeightedFeatExp /* = NULL */, double *pLenWeightExp /* = NULL */, wbTrie<int, double> *pLenFeatExp /*=NULL*/ )
	{
		if ( pWeightedFeatExp ) {
			memset(pWeightedFeatExp, 0, sizeof(pWeightedFeatExp[0])*(m_pModel->m_nFeatNum));
			for (int t=0; t<m_nThreadNum; t++) {
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					pWeightedFeatExp[i] += 1.0 * m_ppWeightedFeatCount[t][i] / m_nMinBatch; 
				}
			}
		}
		//ͳ�Ʋ�ͬ���ȳ��ֵ�count
		wbArray<int> aLenCount(m_pModel->m_nMaxLen+1); //ͳ�Ʋ�ͬ���ȵ�count
		aLenCount.Fill(0);
		for (int t=0; t<m_nThreadNum; t++) {
			for (int len=1; len<=m_pModel->m_nMaxLen; len++)
				aLenCount[len] += m_ppLenCount[t][len];
		}
		
		if ( pLenWeightExp ) {
			memset(pLenWeightExp, 0, sizeof(pLenWeightExp[0])*(m_pModel->m_nMaxLen+1) );
			for (int t=0; t<m_nThreadNum; t++) {
				for (int len=1; len<=m_pModel->m_nMaxLen; len++) {
					pLenWeightExp[len] += 1.0 * m_ppLenWeightCount[t][len] / aLenCount[len];
				}
			}
		}

		if ( pLenFeatExp )
		{
			int idx[3];
			bool bFound;

			for (int t=0; t<m_nThreadNum; t++)
			{
				wbTrieIter2<int, int> iterCount(m_pLenFeatTries[t], idx, 2);
				wbTrie<int, int> *pSubCount;
				while (pSubCount = iterCount.Next()) {
					int n = *(pSubCount->GetData());
					double *pdTemp = pLenFeatExp->Insert(idx, 2, bFound);
					if ( !bFound ) *pdTemp = 0;
					lout_assert(aLenCount[idx[0]] > 0);
					*pdTemp += 1.0 * n / aLenCount[idx[0]];
				}
			}
		}
	}
#endif
#ifdef _Class
	void SAThreadMager::GetClassDistribution(wbDArray<wbArray<double>*> &aClassProb)
	{
		for (int len=1; len<=m_pModel->m_nMaxLen; len++)
		for (int h=0; h<len; h++)
		{
			if ( aClassProb.Get(len, h) ) {
				aClassProb.Get(len, h)->Fill(0);
			}
		}

		int idx[4];
		wbTrie<int,int> *pSub;
		bool bFound;

		for (int t=0; t<m_nThreadNum; t++) {
// 			for (int len = 1; len<=m_pModel->m_nMaxLen; len++)
// 			{
// 				for (int h=0; h<m_pModel->m_nMaxLen; h++) {
// 					wbArray<double> *&pProbs = aClassProb.Get(len, h);
// 					if ( !pProbs ) {
// 						pProbs = new wbArray<double>(m_pModel->m_pVocab->nClassIdTop);
// 						pProbs->Fill(0);
// 					}
// 				}
// 			}
// 			idx[0] = 2;
// 			idx[1] = 0;
// 			idx[2] = 1;
// 			int *pN = m_pClassCount[t].Find(idx, 3);
// 			lout_variable(*pN);
// 			Pause();
			wbTrieIter2<int, int> iter(m_pClassCount[t], idx, 3);
			while ( pSub = iter.Next() ) {
				int n = *pSub->GetData();
				wbArray<double> *&pProbs = aClassProb.Get(idx[0], idx[1]);
				if ( !pProbs ) {
					pProbs = new wbArray<double>(m_pModel->m_pVocab->nClassIdTop);
					pProbs->Fill(0);
				}
				pProbs->Get(idx[2]) += n;
			}
		}

		//��һ��
		for (int len = 1; len<=m_pModel->m_nMaxLen; len++)
		{
			for (int h=0; h<len; h++) {
				double dSum = 0;
				wbArray<double> *pProbs = aClassProb.Get(len, h);
				if ( pProbs ) {
					for (int c=0; c<m_pModel->m_pVocab->nClassIdTop; c++)
						dSum += pProbs->Get(c);
				}
				if (dSum >0) {
					for (int c=0; c<m_pModel->m_pVocab->nClassIdTop; c++)
						pProbs->Get(c) /= dSum;
				}
			}
		}
		
	}
#endif

	void SA::Prepare(int nThreadNum, CDmodel *pModel, const char *pathTrain, const char *pathValid, 
		const char *pathTest /* = NULL */,  const char *pathEmpirical/* = NULL*/, const char *pathVar/*= NULL*/, 
		bool bUniformSample /*= false*/)
	{
		//ģ��
		m_pModel = pModel;
		wbFunc::m_nParamNum = m_pModel->m_nFeatNum;
		lout_variable(m_pModel->m_nFeatNum);
		lout_variable(m_pModel->m_pVocab->nSize);

		//���ٿռ�
		SAFE_NEW_ARRAY(m_pPefi, double, m_pModel->m_nFeatNum);
		SAFE_NEW_ARRAY(m_pPnfi, double, m_pModel->m_nFeatNum);
		//m_pLenFeatExp = new wbDArray<double>(pModel->m_nMaxLen+1, pModel->m_nFeatNum);
		
		//��������
		if ( pathTrain ) {
			lout<<"Load Train Corpus"<<endl;
			m_corpusTrain.Reset(pathTrain, false);
			GetCorpusInfo(m_corpusTrain.m_info, m_corpusTrain);
		}
		if ( pathValid ) {
			lout<<"Load Valid Corpus"<<endl;
			m_corpusValid.Reset(pathValid, false);
			GetCorpusInfo(m_corpusValid.m_info, m_corpusValid);
		}
		if ( pathTest ) {
			lout<<"Load Test Corpus"<<endl;
			m_corpusTest.Reset(pathTest, false);
			GetCorpusInfo(m_corpusTest.m_info, m_corpusTest);
		}
		m_nSeqMaxLen = max(m_corpusTrain.m_nSize, max(m_corpusValid.m_nSize, m_corpusTest.m_nSize) );
		m_nSeqNum = m_corpusTrain.m_nLine;
		lout_variable(m_nSeqNum);
		lout_variable(m_nSeqMaxLen);
		if (m_pModel->m_nMaxLen < m_nSeqMaxLen) {
			lout_error("ģ���趨���ȣ�"<<m_pModel->m_nMaxLen<<"�� < ������������󳤶ȣ�"<<m_nSeqMaxLen<<"��");
		}
		


		//ͳ�Ƴ��ȷֲ�
		m_aLenCount.SetNum(m_pModel->m_nMaxLen+1);
		m_aLenCount.Fill(0);
		wbArray<int> aSeq;
		for (int i=0; i<m_corpusTrain.m_nLine; i++) {
			m_corpusTrain.GetLine(i, aSeq);
			m_aLenCount[aSeq.GetNum()]++;
		}
		for (int i=0; i<m_aLenCount.GetNum(); i++) {
			m_aTurLenProb[i] = 1.0 * m_aLenCount[i] / m_corpusTrain.m_nLine;
		}
		if (bUniformSample) {
			m_aSampleLenProb.SetNum(m_pModel->m_nMaxLen+1);
			m_aSampleLenProb.Fill( 1.0 / (m_pModel->m_nMaxLen) );
			m_aSampleLenProb[0] = 0;
		} else {
			m_aSampleLenProb.Copy(m_aTurLenProb);
		}
		

		pModel->m_aLenProb.Copy(m_aSampleLenProb); //��������ķֲ�
// 		if ( pModel->m_aLenProb.GetNum() == 0 ) { //��ģ�͵ĳ��ȷֲ�û�г�ʼ��������г�ʼ��������ʹ��ģ���Դ��ĳ��ȷֲ�
// 			
// 		}
		
		
#ifdef Scheme1
		((CDmodel_len *)pModel)->InitSampling();
		//m_aSampleLenProb.Copy(pModel->m_aLenProb); //����InitSampling�л�ƽ���ֲ��������Ҫ����ƽ���õķֲ�
#endif
#ifdef Hessian
		m_aFeatSquareExp.SetNum(pModel->m_nFeatNum);
#endif
#ifdef _Class
		new (&m_aClassProb) wbDArray<wbArray<double>*>(m_pModel->m_nMaxLen+1, m_pModel->m_nMaxLen+1);
		m_aClassProb.Fill(NULL);
		for (int len=1; len<=m_pModel->m_nMaxLen; len++)
		for (int h=0; h<len; h++) {
			m_aClassProb.Get(len, h) = new wbArray<double>(m_pModel->m_pVocab->nClassIdTop);
			m_aClassProb.Get(len, h)->Fill(1.0/(m_pModel->m_pVocab->nClassIdTop));
		}
#endif


		//��ʼ������Ϊģ�͸������ĳ���
		int nMaxProbLen = 1;
		for (int i=2; i<=pModel->m_nMaxLen; i++) {
			if ( pModel->m_aLenProb[i] > pModel->m_aLenProb[nMaxProbLen] )
				nMaxProbLen = i;
		}

		SAFE_NEW_ARRAY(m_pSeqBuf, VocabID, m_nSeqMaxLen + 10);
		m_nSeqLen = nMaxProbLen;
		for (int i=0; i<nMaxProbLen; i++)
			m_pSeqBuf[i] = 0;
		//m_nSeqLen = 1;
		lout_variable(m_nSeqLen);


		//�����̹߳�����
		m_pThreadMger = new SAThreadMager(nThreadNum, m_pModel, m_nMinBatch, m_nSampleStep);
		m_pThreadMger->StartThread();


		//���㾭��ֲ�
		if (pathEmpirical) {
			lout<<"Read Empirical..."<<endl;
			ReadEmpirical(wbFile(pathEmpirical, "rt"));
		} else {
			lout<<"Count Empirical..."<<endl;
			Empirical(m_corpusTrain);
		}
//  		ReadEmpirical(wbFile("Empirical_2gram_BE_len.dbg", "rt"));
//  		WriteEmpirical(wbFile("Empirical_2gram_BE_len_2.dbg", "wt"));

//#ifdef _FeatNorm

		if ( m_dL1Reg > 0 )  //L1������Ҫ���ݷ���������
		{
			//ͳ����������
			if (pathVar) {
				lout<<"Read Var..."<<endl;
				ReadFeatVar(wbFile(pathVar, "rt"));
			} else {
				lout<<"Count Var..."<<endl;
				EmpiricalVar(m_corpusTrain);
			}
		}
#ifdef _Var		
		if ( m_dL1Reg <= 0 )  
		{
			//ͳ����������
			if (pathVar) {
				lout<<"Read Var..."<<endl;
				ReadFeatVar(wbFile(pathVar, "rt"));
			} else {
				lout<<"Count Var..."<<endl;
				EmpiricalVar(m_corpusTrain);
			}
		}
#endif
//		m_pModel->SetFeatMeanVar( NULL, m_aLogFeaVar );
//#endif

		//ѵ����������
		for (int i=0; i<m_corpusTrain.m_nLine; i++)
			m_aTrainRandSeq[i] = i;
		RandomPos(m_aTrainRandSeq, m_aTrainRandSeq.GetNum(), m_aTrainRandSeq.GetNum());
		m_nTrainRandBeg = 0;
	}

	void SA::Empirical(Corpus &corpus)
	{
		memset( m_pPefi, 0, sizeof(m_pPefi[0])*(m_pModel->m_nFeatNum) );

		/*
		wbArray<int> a;
		titlePrecent(0, true, corpus.m_nLine, "[OMP] Count empirical");
		
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);

#pragma omp parallel for
			for (int i=0; i<m_pModel->m_nFeatNum; i++) {
				int nFeat = m_pModel->m_aFeatures[i]->nAccept(a, a.GetNum());
				// ʹ����ʵ���ȷֲ���Ȩ������
				m_pPefi[i] += m_aTurLenProb[a.GetNum()] * nFeat / m_aLenCount[a.GetNum()] ;
			}


			titlePrecent(l+1);
		}
		*/
		titlePrecent(0, true, corpus.m_nLine, "Count empirical");
		wbArray<VocabID> aSeq;
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, aSeq);

			int nLen = aSeq.GetNum();
			// wb: 2014-12-15
			//ʹ��Hash���ٲ��ҵ�ǰ���м��������
			//wbLHash<int, int> aCurFeatNum;
			wbArray<int> aFeatures;
			for (int nOrder=1; nOrder<=m_pModel->m_nOrder; nOrder++) {
				for (int h=0; h<=nLen-nOrder; h++) {
					aFeatures.Clean();
					m_pModel->FindFeatures(aFeatures, aSeq.GetBuffer(), nLen, h, nOrder);
					for (int i=0; i<aFeatures.GetNum(); i++) {
						m_pPefi[ aFeatures[i] ] += 1.0 / corpus.m_nLine;
					}
				}
			}

// 			int nFeat = m_pModel->m_aFeatures[i]->nAccept(aSeq, aSeq.GetNum());
// 			// ʹ����ʵ���ȷֲ���Ȩ������
// 			m_pPefi[i] += m_aTurLenProb[aSeq.GetNum()] * nFeat / m_aLenCount[aSeq.GetNum()] ;
				
			titlePrecent();
		}
	}

	void SA::WriteEmpirical(wbFile &file)
	{
		//��������
		file.Print("FeatureNum=%d\n", m_pModel->m_nFeatNum);
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
// 			m_pModel->m_aFeatures[i]->Write(file);
// 			file.Print("\t%lf\n", Prob2LogP(m_pPefi[i]) );
			wbString strType = FeatureType2Str(m_pModel->m_aFeatures[i]->type);
			file.Print("[%s]\t", strType.GetBuffer());
			file.Print( "value=%lf\t", Prob2LogP(m_pPefi[i]) );
			m_pModel->m_aFeatures[i]->Write(file);
			file.Print("\n");
		}
	}
	void SA::ReadEmpirical(wbFile &file)
	{
		//��������
		int nNum = 0;
		fscanf(file, "FeatureNum=%d\n", &nNum);
		lout_assert(nNum == m_pModel->m_nFeatNum);

		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			char *pLine = file.GetLine();
			if ( pLine == NULL ) {
				lout_error("�����empirical��Ŀ��������Ŀ��ͬ");
			}
			char *p = strstr(pLine, "value=");
			lout_assert(p != NULL);
			//m_pModel->m_aFeatures[i]->Read(file);
			double d = atof(p+6);
			//fscanf(file, "\t%lf\n", &d);
			m_pPefi[i] = LogP2Prob(d);
		}
	}

	void SA::EmpiricalVar( Corpus &corpus )
	{
#ifdef Scheme1
		EmpiricalVar_len(corpus);
#else
		m_aLogFeaVar.SetNum(m_pModel->m_nFeatNum);
		m_aLogFeaVar.Fill(0);
		wbArray<int> a;

		if ( m_pPefi==NULL || m_pPefi[0] == 0 ) {
			Empirical(corpus);  //�ȼ�������
		}

		titlePrecent(0, true, corpus.m_nLine, "Count Feature Various");
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);
			int nLen = a.GetNum();
			if ( nLen > m_pModel->m_nMaxLen )
				continue;

			wbLHash<int, int> aFeatNum;
			bool bFound;
			wbArray<int> aFeatures;
			m_pModel->FindFeatures(aFeatures, a.GetBuffer(), nLen);
			for (int i=0; i<aFeatures.GetNum(); i++) {
				int *p = aFeatNum.Insert( aFeatures[i], bFound );
				if ( !bFound ) *p = 0;
				(*p) += 1;
			}
			wbLHashIter<int, int> iter(&aFeatNum);
			int *pCount; 
			int nFeat;
			while ( pCount = iter.Next(nFeat) ) {
				//m_aLogFeaVar[nFeat] += m_pModel->m_aLenProb[nLen] * pow( (*pCount) - aFeatMeanPerLen.Get(nLen, nFeat), 2 ) / m_aLenCount[nLen] ;
				m_aLogFeaVar[nFeat] += pow( (*pCount) - m_pPefi[nFeat] , 2) / corpus.m_nLine;
			}
			titlePrecent(l+1);
		}

		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_aLogFeaVar[i] = Prob2LogP( sqrt(m_aLogFeaVar[i]) );  // �����׼��
		}
#endif
	}

	void SA::EmpiricalVar_len( Corpus &corpus )
	{
		m_aLogFeaVar.SetNum(m_pModel->m_nFeatNum);
		m_aLogFeaVar.Fill(0);
		wbArray<int> a;

		wbArray<double> aExpFeatSqu(m_pModel->m_nFeatNum+1);
		wbArray<double> aExpFeatPerLen(m_pModel->m_nFeatNum+1);

		aExpFeatSqu.Fill(0);
		aExpFeatPerLen.Fill(0);

		/// Count p[f^2]
		titlePrecent(0, true, corpus.m_nLine, "Count p[f^2]");
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);
			int nLen = a.GetNum();
			if ( nLen > m_pModel->m_nMaxLen )
				continue;

			wbLHash<int, int> aFeatNum;
			bool bFound;
			wbArray<int> aFeatures;
			m_pModel->FindFeatures(aFeatures, a.GetBuffer(), nLen);
			for (int i=0; i<aFeatures.GetNum(); i++) {
				int *p = aFeatNum.Insert( aFeatures[i], bFound );
				if ( !bFound ) *p = 0;
				(*p) += 1;
			}
			wbLHashIter<int, int> iter(&aFeatNum);
			int *pCount; 
			int nFeat;
			while ( pCount = iter.Next(nFeat) ) {
				aExpFeatSqu[nFeat] += pow((double)(*pCount), 2) / corpus.m_nLine;
			}

			titlePrecent(l+1);
		}

		/// Count p_l[f]
		/// As save p_l[f] for all the length cost too much memory. So we calculate each p_l[f] separately.
		titlePrecent(0, true, m_pModel->m_nMaxLen, "Count p_l[f]");
		for (int nLen=1; nLen<=m_pModel->m_nMaxLen; nLen++) 
		{
			aExpFeatPerLen.Fill(0);
			int nLenCount = 0;

			for (int l=0; l<corpus.m_nLine; l++) 
			{
				corpus.GetLine(l, a);
				int nSeqLen = a.GetNum();

				if ( nSeqLen != nLen )  {
					continue;
				}
				nLenCount++;
				
				wbLHash<int, int> aFeatNum;
				bool bFound;
				wbArray<int> aFeatures;
				m_pModel->FindFeatures(aFeatures, a.GetBuffer(), nLen);
				for (int i=0; i<aFeatures.GetNum(); i++) {
					aExpFeatPerLen[ aFeatures[i] ] += 1.0;
				}
			}

			for (int i=0; i<m_pModel->m_nFeatNum; i++) 
				aExpFeatPerLen[i] /= nLenCount;   /// calculate expectation

			for (int i=0; i<m_pModel->m_nFeatNum; i++) 
				aExpFeatSqu[i] -= m_pModel->m_aLenProb[nLen] * pow(aExpFeatPerLen[i], 2);  /// calcualte p[f^2] - \pi_l * p_l[f]^2

			titlePrecent(nLen);
		}

		///���� standard variance
		for (int i=0; i<m_pModel->m_nFeatNum; i++) 
			m_aLogFeaVar[i] = Prob2LogP(aExpFeatSqu[i]) / 2;
		

	}

	void SA::WriteFeatVar(wbFile &file)
	{
		//��������
		file.Print("FeatureNum=%d\n", m_pModel->m_nFeatNum);
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
// 			m_pModel->m_aFeatures[i]->Write(file);
// 			file.Print("\t%lf\n", m_aLogFeaVar[i]);
			wbString strType = FeatureType2Str(m_pModel->m_aFeatures[i]->type);
			file.Print("[%s]\t", strType.GetBuffer());
			file.Print( "value=%lf\t", m_aLogFeaVar[i] );
			m_pModel->m_aFeatures[i]->Write(file);
			file.Print("\n");
		}
	}
	void SA::ReadFeatVar(wbFile &file)
	{
		//��������
		int nNum = 0;
		fscanf(file, "FeatureNum=%d\n", &nNum);
		lout_assert(nNum == m_pModel->m_nFeatNum);

		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
// 			m_pModel->m_aFeatures[i]->Read(file);
// 			fscanf(file, "\t%lf\n", &m_aLogFeaVar[i]);
			char *pLine = file.GetLine();
			if ( pLine == NULL ) {
				lout_error("�����empirical��Ŀ��������Ŀ��ͬ");
			}
			char *p = strstr(pLine, "value=");
			lout_assert(p != NULL);
			double d = atof(p+6);
			m_aLogFeaVar[i] = d;
		}
	}

	void SA::GetCorpusInfo(CorpusInfo &info, Corpus &corpus)
	{
		info.Reset(m_nParamNum, m_pModel->m_nMaxLen);

		titlePrecent(0, true, corpus.m_nLine, "Get corpus info");
		wbArray<VocabID> aSeq;
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, aSeq);

			int nLen = aSeq.GetNum();
			wbArray<int> aFeatures;
			m_pModel->FindFeatures(aFeatures, aSeq.GetBuffer(), nLen);
			for (int i=0; i<aFeatures.GetNum(); i++) {
				info.m_aFeatCount[ aFeatures[i] ]++;
			}

			info.m_aLenCount[nLen]++;
			info.m_nTotalWord += aSeq.GetNum();
			titlePrecent();
		}
	}

	void SA::GetCurEmpiricalExp(double *pPefi)
	{
		lout<<"GetCurEmpiricalExp... m_nTrainRandBeg="<<m_nTrainRandBeg<<endl;
		memset(pPefi, 0, sizeof(pPefi[0])*m_nParamNum);

		if ( m_nTrainRandBeg + m_nMinBatch > m_aTrainRandSeq.GetNum() ) {
			RandomPos( m_aTrainRandSeq, m_aTrainRandSeq.GetNum(), m_aTrainRandSeq.GetNum() );
			m_nTrainRandBeg = 0;
		}

		wbArray<VocabID> aSeq;
		for (int pos=m_nTrainRandBeg; pos<m_nTrainRandBeg+m_nMinBatch; pos++)
		{
			m_corpusTrain.GetLine(m_aTrainRandSeq[pos], aSeq);

			int nLen = aSeq.GetNum();
			//ʹ��Hash���ٲ��ҵ�ǰ���м��������
			wbArray<int> aFeatures;
			m_pModel->FindFeatures(aFeatures, aSeq.GetBuffer(), nLen);
			for (int i=0; i<aFeatures.GetNum(); i++) {
				pPefi[ aFeatures[i] ] += 1.0 / m_nMinBatch;
			}
		}

		m_nTrainRandBeg += m_nMinBatch;
	}


	double SA::CaculateLogLikelihood_perlen(Corpus *pCorpus, bool bNorm /*= true*/, double *pPPL /*=NULL*/, wbFile *pfile /*=NULL*/)
	{
		wbArray<double> aValue;
		wbArray<int> aCount; ///< count of each length
		aCount.SetNum(m_pModel->m_nMaxLen+1);
		aValue.SetNum(m_pModel->m_nMaxLen+1);
		aCount.Fill(0);
		aValue.Fill(0);

		double dValue = 0;
		double dPPL = 0;
		wbArray<int> aSeq;
		int nWord = 0;
		for (int i=0; i<pCorpus->m_nLine; i++) {
			pCorpus->GetLine(i, aSeq);
			double d = m_pModel->GetLogProb(aSeq, aSeq.GetNum(), bNorm); 
			dValue += d;
			dPPL += d / log(10.0);
			nWord += aSeq.GetNum() + 1;

			aValue[aSeq.GetNum()] += d;
			aCount[aSeq.GetNum()] ++;
		}
		dValue /= pCorpus->m_nLine;
		dPPL = pow(10, -dPPL / nWord);

		for (int j=1; j<=m_pModel->m_nMaxLen; j++)
			aValue[j] = -aValue[j] / aCount[j];

		//����Perplexity
		if (pPPL) *pPPL = dPPL;

		//����ÿ�����ȵ�log-likelihood
		if (pfile) {
			for (int j=1; j<=m_pModel->m_nMaxLen; j++)
				pfile->Print("%lf ", aValue[j]);
			pfile->Print("\n");
		}

		return -dValue; //������Ȼֵ�Ǳ��ģ���Ҫת��Ϊ��׼��С������
	}
	double SA::CaculateLogLikelihood(Corpus *pCorpus, bool bNorm /* = true */, double *pPPL/* =NULL */)
	{
		//ʹ��ͳ�Ƶ����ϵ�count�����ټ�����Ȼֵ
		double dValue = 0;
		for (int i=0; i<m_nParamNum; i++) {
			dValue += ( m_pModel->m_aValues[i] ) * ( pCorpus->m_info.m_aFeatCount[i] );
		}
		
//		lout_variable(dValue);
		if ( bNorm ) //��һ��ϵ��
		{
			for (int len=1; len<=m_pModel->m_nMaxLen; len++) {
				// ����NormalizeProb(0, len) ���صľ��� -log(Z_l)
				dValue +=  m_pModel->NormalizeProb(0, len) * pCorpus->m_info.m_aLenCount[len];
// 				lout_variable(m_pModel->NormalizeProb(0, len));
// 				Pause();
			}
		}

		dValue /= pCorpus->m_nLine;
		dValue = -dValue;

		if ( pPPL ) {
			*pPPL = exp( dValue * pCorpus->m_nLine / (pCorpus->m_nLine + pCorpus->m_info.m_nTotalWord) );
		}
		return dValue;
	}
}