// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF models, Rosenfeld estimation method
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/** 
 * \file
 * \author wangbin
 * \date 2015-04-28
 * \brief Rosenfeld��whole-sentenceģ�͵�ѵ������
 */
#pragma once
#include "wbJRFSA.h"
using namespace wbJRF;

namespace wbJRF
{
	/** 
	 * \class
	 * \brief Rosenfeld �������ݶȼ��㣬ʹ��importance sampling
	 */
	class ImSamplingFunc : public SA
	{
	public:
		/// ʹ��һ�������ֲ���ͨ��Ϊngramģ�ͣ�������õ�һ������
		int m_nFakesetNum;  ///< ����������Ŀ
		wbArray<LogP> m_aFakesetLogp; ///< ÿ���������ڲ����ֲ��µĸ���
		wbArray<wbArray<VocabID>*> m_aFakesetSeq; ///< ÿ������
	public:
		ImSamplingFunc(int nMinBatch, double dRegular = 0, bool bFast = true) : 
		  SA(nMinBatch, dRegular, bFast)
		{
			m_nFakesetNum = 0;
		}
		~ImSamplingFunc()
		{
			for (int i=0; i<m_aFakesetSeq.GetNum(); i++)
				SAFE_DELETE(m_aFakesetSeq[i]);
		}
		/// ���븨���ֲ������������Ҫ�ڳ�ʼ���׶ε��ã�������������ڼ�����·���
		void LoadFakeset(wbFile &file)
		{
			lout<<"Load Fake Sampling Set..."<<endl;

			m_nFakesetNum = 0;
			m_aFakesetSeq.Clean();
			m_aFakesetLogp.Clean();

			char *pLine = NULL;
			while (pLine = file.GetLine(true)) {
				char *p = NULL;

				if ( (p = strstr(pLine, "logp=")) == NULL ) {
					lout_error("[LoadFakeset] can't find label: logp");
				}
				m_aFakesetLogp.Add() = atof(p+5);

				if ( (p = strstr(pLine, "len=")) == NULL ) {
					lout_error("[LoadFakeset] can't find label: len");
				}
				int nLen = atoi(p+4);

				if ( (p = strstr(pLine, "sent=")) == NULL ) {
					lout_error("[LoadFakeset] can't find label: seq");
				}

				wbArray<VocabID> *pArray = new wbArray<VocabID>(nLen);
				p = strtok(p+5, " ");
				while (p) {
					pArray->Add( atoi(p)-2 ); //������lext�ı�ţ�������ʼ����������RFģ�Ͳ�������ʼ�����������Ҫ��ȥ2
					p = strtok(NULL, " ");
				}
				m_aFakesetSeq.Add(pArray);
				
				m_nFakesetNum++;
			}

			lout_variable(m_nFakesetNum);
		}

		/// ���㵱ǰ�� ģ������ pn[f_i]
		void CalculateExp(double *pExp)
		{
			wbArray<double> aRate;
			double dRateSum = 0;
			for (int i=0; i<m_nFakesetNum; i++) {
				LogP logp = m_pModel->GetLogProb(m_aFakesetSeq[i]->GetBuffer(), m_aFakesetSeq[i]->GetNum(), false);
				double d = LogP2Prob( logp - m_aFakesetLogp[i] );
				aRate[i] = d;
				dRateSum += d;
			}

			//��������
			memset( pExp, 0, sizeof(double) * m_nParamNum );
			for (int nseq=0; nseq<m_nFakesetNum; nseq++) {
				VocabID *pSeq = m_aFakesetSeq[nseq]->GetBuffer();
				int nLen = m_aFakesetSeq[nseq]->GetNum();

				wbArray<int> aFind;
				m_pModel->FindFeatures(aFind, pSeq, nLen); //���Ҽ��������
				for (int i=0; i<aFind.GetNum(); i++) {
					int idx = aFind[i];
					pExp[idx] += aRate[nseq] / dRateSum;
				}
			}
		}

		/// �����ݶȣ�����Rosenfeldʹ��GIS���������������Ǹ��·���
		virtual bool GetGradient(double *pdParams, double *pdGradient)
		{
			//return GetGISDir(pdParams, pdGradient);
			return GetIMGradient(pdParams, pdGradient);
		}

		/// �����ݶȷ���
		bool GetIMGradient(double *pdParams, double *pdGradient)
		{
			if ( pdParams ) {
				m_pModel->SetParams(pdParams, !m_bFastIter);
			}

			//���� p(x) / q(x) ����q(x)�ǻ��Fakeset�ķֲ�
			wbArray<double> aRate;
			double dRateSum = 0;
			for (int i=0; i<m_nFakesetNum; i++) {
				LogP logp = m_pModel->GetLogProb(m_aFakesetSeq[i]->GetBuffer(), m_aFakesetSeq[i]->GetNum(), false);
				double d = LogP2Prob( logp - m_aFakesetLogp[i] );
				aRate[i] = d;
				dRateSum += d;
			}

			//��������
			wbArray<double> aHessian(m_nParamNum);
			aHessian.Fill(0);
			memset( m_pPnfi, 0, sizeof(double) * m_nParamNum );
			for (int nseq=0; nseq<m_nFakesetNum; nseq++) {
				VocabID *pSeq = m_aFakesetSeq[nseq]->GetBuffer();
				int nLen = m_aFakesetSeq[nseq]->GetNum();

				wbLHash<int, int> aCurFeatNum;
				bool bFound;
				wbArray<int> aFind;
				m_pModel->FindFeatures(aFind, pSeq, nLen); //���Ҽ��������
				for (int i=0; i<aFind.GetNum(); i++) { 
					int idx = aFind[i];
					//��feature����һ��hash��
					int *pCount = aCurFeatNum.Insert(idx, bFound);
					if ( !bFound ) *pCount = 0;
					(*pCount) ++;
				}

				//�������hash��
				wbLHashIter<int, int> iter(&aCurFeatNum);
				int nFeat, *pCount;
				while( pCount = iter.Next( nFeat ) ) {
					int nCount = *pCount;
					m_pPnfi[nFeat] += aRate[nseq] * nCount / dRateSum;  //����p[f]
					aHessian[nFeat] += aRate[nseq] * nCount * nCount / dRateSum; // ����p[f*f]
				}
			}

			//����hessian
			for (int i=0; i<m_nParamNum; i++) {
				aHessian[i] -= m_pPnfi[i] * m_pPnfi[i];  //p[f*f] - p[f]*p[f]
				if ( aHessian[i] < 1e-4 )
					aHessian[i] = 1e-4;
			}


			//�����ݶ�
			for (int i=0; i<m_nParamNum; i++) {
				pdGradient[i] = ( m_pPnfi[i] - m_pPefi[i] ) / aHessian[i];
			}


			return true;
		}
		/// GIS ����
		bool GetGISDir(double *pdParams, double *pdGradient)
		{
			if ( pdParams ) {
				m_pModel->SetParams(pdParams, !m_bFastIter);
			}

			int nZeroExp = 0;  //��¼�ж��ٸ�featureû����Fakeset�г���
			wbArray<double> aF(m_nParamNum); ///���� F = 1/K * Sum_x p(x)/q(x) f(x) * sum_i f_i(x) 
			aF.Fill(0);

			//���� p(x) / q(x) ����q(x)�ǻ��Fakeset�ķֲ�
			wbArray<double> aRate; //���� p(x)/q(x)
			double dRateSum = 0;   // sum_x p(x)/q(x)
			for (int i=0; i<m_nFakesetNum; i++) {
				LogP logp = m_pModel->GetLogProb(m_aFakesetSeq[i]->GetBuffer(), m_aFakesetSeq[i]->GetNum(), false);
				double d = LogP2Prob( logp - m_aFakesetLogp[i] );
				aRate[i] = d;
				dRateSum += d;
			}

			//�������� E_p (f_i)
			memset( m_pPnfi, 0, sizeof(double) * m_nParamNum );
			for (int nseq=0; nseq<m_nFakesetNum; nseq++) {
				VocabID *pSeq = m_aFakesetSeq[nseq]->GetBuffer();
				int nLen = m_aFakesetSeq[nseq]->GetNum();

				wbArray<int> aFind;
				m_pModel->FindFeatures(aFind, pSeq, nLen); //���Ҽ��������
				for (int i=0; i<aFind.GetNum(); i++) {
					int idx = aFind[i];
					m_pPnfi[idx] += aRate[nseq]; // Sum_x p(x)/q(x) f(x)

					aF[idx] += aRate[nseq] * aFind.GetNum(); // Sum_x p(x)/q(x) f(x) * sum_i f_i(x) 
				}
			}

			//����m_pPnFi����С��
			double dMin_pnfi = INF;
			for (int i=0; i<m_nParamNum; i++) {
				if ( m_pPnfi[i] != 0 )
					dMin_pnfi = min(dMin_pnfi, m_pPnfi[i]);
			}
			lout_variable(dMin_pnfi);
			double dMin_F = INF;
			for (int i=0; i<m_nParamNum; i++) {
				if ( aF[i] != 0 )
					dMin_F = min(dMin_F, aF[i]);
			}
			lout_variable(dMin_F);

			//����F������p[f_i]
			for (int i=0; i<m_nParamNum; i++) {

				if ( m_pPnfi[i] == 0 ) {
					nZeroExp++;
					m_pPnfi[i] = dMin_pnfi/2;
				}
				if ( aF[i] == 0 )
					aF[i] = dMin_F /2;

				aF[i] /= m_pPnfi[i];
				m_pPnfi[i] /= dRateSum;
			}

			lout_variable_precent(nZeroExp, m_nParamNum);

			// ���㷽��
			for (int i=0; i<m_nParamNum; i++) {
				pdGradient[i] = - 1.0 / aF[i] * log( m_pPefi[i] / m_pPnfi[i] );
				if ( pdGradient[i] < -INF  ) {
					lout_variable(aF[i]);
					lout_variable(m_pPefi[i]);
					lout_variable(m_pPnfi[i]);
					Pause();
				}
			}

// 			wbFile fileDbg("GIS.dbg", "wt");
// 			fileDbg.PrintArray("%.4f\t", aF.GetBuffer(), m_nParamNum);
// 			fileDbg.PrintArray("%.4f\t", m_pPnfi, m_nParamNum);
// 			fileDbg.PrintArray("%.4f\t", m_pPefi, m_nParamNum);
// 			fileDbg.PrintArray("%.4f\t", pdGradient, m_nParamNum);
// 			Pause();
			
			return true;
		}
	};
}