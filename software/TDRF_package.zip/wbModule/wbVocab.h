// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Vocabulary class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.



/**
 * \file 
 * \author wangbin
 * \date 2013-9-23
 * \brief �ۺϴʵ��ļ������������ָ�ʽ�ʵ�Ķ�д
*/

#pragma once
#include "wbSystem.h"

/// Gsp�ֵ�Set
class wbGspWordSet
{
public:
	int nId;
	int nNum; //�����������ݿ��ַ�������
	int nId2; //��������ʲô��˼,��idֵһ��
	wbString strWord;
	wbArray<int> aProun;
	wbArray<wbString> aStrProun; ///< ���ַ���������Ϊ��

	void operator = (wbGspWordSet &wordSet)
	{
		nId = wordSet.nId;
		nNum = wordSet.nNum;
		nId2 = wordSet.nId2;
		strWord = wordSet.strWord;
		aProun.Copy(wordSet.aProun);
		aStrProun.Copy(wordSet.aStrProun);
	}
};
/// gsp�ֵ䣬Txt�ı�
class wbGspVocab
{
public:
	wbArray<wbGspWordSet> m_aWordSet;

	int m_nWordNum;
	int m_nWordInfoSize;
	int m_nTotalZiNum;

public:
	wbGspVocab():m_nWordNum(0),m_nWordInfoSize(0),m_nTotalZiNum(0){}
	void ReadT(const char *path)
	{
		m_aWordSet.Clean();

		wbFile file(path, "rt");
		
		for (int i=0; i<4; i++)
			file.GetLine();
 		sscanf(file.GetLine(), "nWordInfoNum=%d", &m_nWordNum);
		sscanf(file.GetLine(), "nWordInfoSize=%d", &m_nWordInfoSize);
		sscanf(file.GetLine(), "nTotalZiNum=%d", &m_nTotalZiNum);
		
		for (int i=0; i<m_nWordNum; i++)
		{
			char *pLine = file.GetLine();

			wbGspWordSet wordSet;

 			sscanf(strtok(pLine, " \t"), "%d:", &wordSet.nId);
 			sscanf(strtok(NULL, " \t"), "%d", &wordSet.nNum);
 			sscanf(strtok(NULL, " \t"), "[%d]", &wordSet.nId2);
			wordSet.strWord = strtok(NULL, " \t");
 			for (int n=0; n<wordSet.nNum; n++)
 				wordSet.aProun[n] = atoi(strtok(NULL, " \t"));

			wordSet.aStrProun.Clean();
			char *p = strtok(NULL, " \t");
			while (p) {
				wordSet.aStrProun.Add(p);
				p = strtok(NULL, " \t");
			}

			m_aWordSet[i] = wordSet;
		}
	}
	void WriteT(const char *path)
	{
		wbFile file(path, "wt");
		file.Print("nObjNum:1\n\nnObjNo:0\n_chlexicon_WordInforVersion{1}_LexID{3}\n");
		file.Print("nWordInfoNum=%d\nnWordInfoSize=%d\nnTotalZiNum=%d\n", m_nWordNum, m_nWordInfoSize, m_nTotalZiNum);
		for (int i=0; i<m_nWordNum; i++)
		{
			file.Print("%d:\t%d\t[%d]\t%s\t", m_aWordSet[i].nId, m_aWordSet[i].nNum, m_aWordSet[i].nId2, m_aWordSet[i].strWord.GetBuffer());
			for (int n=0; n<m_aWordSet[i].nNum; n++)
				file.Print("%d ", m_aWordSet[i].aProun[n]);
			file.Print("\t");
			for (int n=0; n<m_aWordSet[i].nNum; n++)
				file.Print("%s ", m_aWordSet[i].aStrProun[n].GetBuffer());
			file.Print("\n");
		}
	}
};

/// ��ͨ�ֵ䣬�ʺ��б���ʽ
class wbVocab
{
public:
	wbArray<wbString> aWords;

	void ReadT(const char *path)
	{
		wbFile fileLex(path, "rt");
		char *pLine = NULL;
		while (pLine = fileLex.GetLine()) {
			if (strstr(pLine, "<s>"))
				aWords[0] = pLine;
			else if (strstr(pLine, "</s>"))
				aWords[1] = pLine;
			else {
				int nId = atoi(strtok(pLine, " \t"));
				aWords[nId] = strtok(NULL, " \t");
			}
		}
	}
	void WriteT(const char *path)
	{
		wbFile fileLex(path, "wt");
		
		fileLex.Print("<s>\n</s>\n");
		for (int i=2; i<aWords.GetNum(); i++) {
			fileLex.Print("%d\t%s\n", i, aWords[i].GetBuffer());
		}
	}
};