// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Thread manager class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbThreadManager.h"
#include "wbSystem.h"


wbStdOutMager *wbThreadManager::s_pThreadOutMager = NULL;

wbThreadManager::wbThreadManager(int p_nThreadNum, const char *p_flag)
{
	if (p_nThreadNum <= 0)
		return;


	m_nThreadNum = p_nThreadNum;
	strcpy_s(m_strFlag, TM_FLAG_LEN, p_flag);
// 	m_phThread = new HANDLE[m_nThreadNum];
// 	m_phTaskAllocEvent = new HANDLE[m_nThreadNum];
// 	m_phTaskFinishEvent = new HANDLE[m_nThreadNum];
// 	m_phThreadExitEvent = new HANDLE[m_nThreadNum];
// 	m_ppThreadTask = new wbTaskPack*[m_nThreadNum];
// 	memset(m_ppThreadTask, 0, sizeof(wbTaskPack*)*m_nThreadNum);

	m_pThreadInfo = new wbThreadInfo[m_nThreadNum];
	for (int i=0; i<m_nThreadNum; i++)
	{
		m_pThreadInfo[i].nId = i;
		m_pThreadInfo[i].pTaskPack = NULL;
	}

	m_nTaskCurNum = 0;
	m_nTaskTotalNum = 0;
	m_pTaskHead = new wbTPNode;
	m_pTaskTail = new wbTPNode;
	m_pTaskHead->pNext = m_pTaskTail;
	m_pTaskTail->pPrev = m_pTaskHead;
	
	//StdOutBlock
	int nCol = 1;
	if (p_nThreadNum >= 4) nCol = 2;
	if (p_nThreadNum >= 9) nCol = 3;
	if (p_nThreadNum >= 16) nCol = 4;
	wbThreadManager::s_pThreadOutMager = new wbStdOutMager(m_nThreadNum/nCol, nCol, 5, 40, true);
}


wbThreadManager::~wbThreadManager(void)
{
// 	SAFE_DELETE_ARRAY(m_phThread);
// 	SAFE_DELETE_ARRAY(m_phTaskAllocEvent);
// 	SAFE_DELETE_ARRAY(m_phTaskFinishEvent);
// 	SAFE_DELETE_ARRAY(m_phThreadExitEvent);
	SAFE_DELETE_ARRAY(m_pThreadInfo);

	wbTPNode *pCur = m_pTaskHead;
	while (pCur != NULL)
	{
		m_pTaskHead = m_pTaskHead->pNext;
		delete pCur;
		pCur = m_pTaskHead;
	}

	SAFE_DELETE(wbThreadManager::s_pThreadOutMager);
}


bool wbThreadManager::AddTask(wbTaskPack *pTask)
{
	if (pTask == NULL)
		return false;

	wbTPNode *pNode = new wbTPNode();
	pNode->pTask = pTask;
	pNode->nId = m_nTaskTotalNum;
	pNode->pPrev = m_pTaskTail->pPrev;
	pNode->pNext = m_pTaskTail;
	pNode->bEnd = false;

	m_pTaskTail->pPrev->pNext = pNode;
	m_pTaskTail->pPrev = pNode;
	
	m_nTaskCurNum++;
	m_nTaskTotalNum++;
	return true;
}

bool wbThreadManager::AddTaskEnd()
{
	wbTPNode *pNode = new wbTPNode();
	pNode->pTask = NULL;
	pNode->pPrev = m_pTaskTail->pPrev;
	pNode->pNext = m_pTaskTail;
	pNode->bEnd = true;

	m_pTaskTail->pPrev->pNext = pNode;
	m_pTaskTail->pPrev = pNode;
	return true;
}

bool wbThreadManager::DeleteTask(wbTPNode *pTaskNode)
{
	if (pTaskNode == NULL)
		return false;

	wbTPNode *p = pTaskNode->pPrev;
	p->pNext = pTaskNode->pNext;
	pTaskNode->pNext->pPrev = p;

	pTaskNode->pTask->Release();
	delete pTaskNode;

	m_nTaskCurNum--;
	return true;
}

bool wbThreadManager::StartThread()
{
	for (int i=0; i<m_nThreadNum; i++)
	{
		m_pThreadInfo[i].phTaskAllockEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			FALSE,  // initial state is nonsignaled
			NULL);  // unnamed object
		if (m_pThreadInfo[i].phTaskAllockEvent == NULL)
		{
			cout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phTaskAllockEvent"<<endl;
			return false;
		}

		m_pThreadInfo[i].phTaskFinishEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			TRUE,  // *******initial state is signaled******************
			NULL);  // unnamed object
		if (m_pThreadInfo[i].phTaskFinishEvent == NULL)
		{
			cout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phTaskFinishEvent"<<endl;
			return false;
		}

		m_pThreadInfo[i].phThreadExitEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			FALSE,  // initial state is nonsignaled
			NULL);  // unnamed object
		if (m_pThreadInfo[i].phThreadExitEvent == NULL)
		{
			cout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phThreadExitEvent"<<endl;
			return false;
		}
	}


	//Create Thread...
	for (int i=0; i<m_nThreadNum; i++)
	{
		DWORD dwThreadID;

		m_pThreadInfo[i].phThread = CreateThread( 
			NULL,         // default security attributes
			0,            // default stack size
			(LPTHREAD_START_ROUTINE)wbThreadManager::ThreadProc, 
			m_pThreadInfo+i,     // thread function arguments
			0,            // default creation flags
			&dwThreadID); // receive thread identifier

		if (m_pThreadInfo[i].phThread == NULL)
		{
			cout<<"CreateThread failed m_pThreadInfo["<<i<<"].phThread"<<endl;
			return false;
		}
	}

	return true;
}

bool wbThreadManager::Run()
{
	int nTaskFinishNum = 0;
	char titleLabel[200];
	sprintf(titleLabel, "%s[Task=%d]", m_strFlag, m_nTaskTotalNum);
	titlePrecent(nTaskFinishNum, true, m_nTaskCurNum, titleLabel);

	HANDLE *phTaskFinishEvent = new HANDLE[m_nThreadNum];
	for (int i=0; i<m_nThreadNum; i++)
		phTaskFinishEvent[i] = m_pThreadInfo[i].phTaskFinishEvent;

	wbTPNode *pTaskCur = m_pTaskHead->pNext;
	while (!pTaskCur->bEnd && pTaskCur != m_pTaskTail)
	{
		DWORD dwWaitResult = WaitForMultipleObjects( 
			m_nThreadNum, // number of objects in array
			phTaskFinishEvent,     // array of objects
			FALSE,       // wait for any object
			INFINITE);   // indefinite wait

		if (dwWaitResult >= WAIT_OBJECT_0 && dwWaitResult < WAIT_OBJECT_0+m_nThreadNum)
		{
			//ɾ�������¼
			if (m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].pTaskPack != NULL) //��ʼ����ΪNULL
			{
				DeleteTask(m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].pTaskPack);
				titlePrecent(++nTaskFinishNum);
			}

			//��������
			m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].pTaskPack = pTaskCur;
			if ( !SetEvent(m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].phTaskAllockEvent) )
			{
				cout<<"SetEvent error m_phTaskAllocEvent["<<dwWaitResult-WAIT_OBJECT_0<<"]"<<endl;
				return false;
			}
		}
		else
		{
			cout<<"WaitForMultipleObjects[FALSE] error"<<endl;
			return false;
		}

		pTaskCur = pTaskCur->pNext;
	}

	DWORD dwWaitResult = WaitForMultipleObjects( 
		m_nThreadNum, // number of objects in array
		phTaskFinishEvent,     // array of objects
		TRUE,       // wait all object 
		INFINITE);   // indefinite wait

	if (dwWaitResult == WAIT_OBJECT_0)
	{
		for (int i=0; i<m_nThreadNum; i++)
		{
			if ( !SetEvent(m_pThreadInfo[i].phThreadExitEvent) )
			{
				cout<<"SetEvent failed m_phThreadExitEvent["<<i<<"]"<<endl;
				return false;
			}
		}
	}
	else
	{
		cout<<"WaitForMultipleObjects[TRUE] error"<<endl;
		return false;
	}
	return true;
}

DWORD WINAPI wbThreadManager::ThreadProc(LPVOID lpThreadParameter)
{
	wbThreadInfo *pThreadInfo = (wbThreadInfo*)lpThreadParameter;

	HANDLE hEvent[2];
	hEvent[0] = pThreadInfo->phTaskAllockEvent;
	hEvent[1] = pThreadInfo->phThreadExitEvent;
	while(true)
	{
		DWORD dwWaitResult = WaitForMultipleObjects(
			2,
			hEvent,
			FALSE,
			INFINITE);
		switch(dwWaitResult)
		{
		case WAIT_OBJECT_0 + 0:
			ThreadPrintf(pThreadInfo->nId, "[Task %d] process...\n", pThreadInfo->pTaskPack->nId);
			//cout<<"Thread["<<pThreadInfo->nId<<"]\t"<<"[Task "<<pThreadInfo->pTaskPack->nId<<"]Process..."<<endl;
			if (pThreadInfo->pTaskPack != NULL)
				pThreadInfo->pTaskPack->pTask->Process(pThreadInfo->nId);
			ThreadPrintf(pThreadInfo->nId, "[Task %d] finished\n", pThreadInfo->pTaskPack->nId);
			if ( !SetEvent(pThreadInfo->phTaskFinishEvent) )
			{
				ThreadPrintf(pThreadInfo->nId, "SetEvent Failed\n");
				return 0;
			}
			break;
		case WAIT_OBJECT_0 + 1:
			//cout<<"Thread["<<pThreadInfo->nId<<"]\t"<<"Exit"<<endl;
			ThreadPrintf(pThreadInfo->nId, "Exit\n");
			return 0;
		default:
			//cout<<"Thread["<<pThreadInfo->nId<<"]\t"<<"WaitForMultipleObjects error!"<<endl;
			ThreadPrintf(pThreadInfo->nId, "WaitForMultipleObjects error!\n");
			ExitThread(0);
		}
	}

	return 0;
}


void wbThreadManager::ThreadPrintf(int nThreadId, const char* pFormat, ...)
{
	char strBuffer[TS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,pFormat);

	sprintf(strBuffer, "Thread[%d] ", nThreadId);
	_vsnprintf(strBuffer+strlen(strBuffer),TS_SENTENCE_LEN,pFormat,vaParams);

	s_pThreadOutMager->m_pStdOutBlock[nThreadId+1]->Puts(strBuffer);
}

void wbThreadManager::MainPrintf(const char* pFormat,...)
{
	char strBuffer[TS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,pFormat);

	sprintf(strBuffer, "[Main] ");
	_vsnprintf(strBuffer+strlen(strBuffer),TS_SENTENCE_LEN,pFormat,vaParams);

	s_pThreadOutMager->m_pStdOutBlock[0]->Puts(strBuffer);
}

void tprintf(int nThreadId, const char* pFormat, ...)
{
	char strBuffer[TS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,pFormat);

	sprintf(strBuffer, "Thread[%d] ", nThreadId);
	_vsnprintf(strBuffer+strlen(strBuffer),TS_SENTENCE_LEN,pFormat,vaParams);

	wbThreadManager::s_pThreadOutMager->m_pStdOutBlock[nThreadId+1]->Puts(strBuffer);
}

void mprintf(const char* pFormat, ...)
{
	char strBuffer[TS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,pFormat);

	sprintf(strBuffer, "[Main] ");
	_vsnprintf(strBuffer+strlen(strBuffer),TS_SENTENCE_LEN,pFormat,vaParams);

	wbThreadManager::s_pThreadOutMager->m_pStdOutBlock[0]->Puts(strBuffer);
}

void tprecent(int nThreadId, size_t n, bool bNew, size_t nTotal, const char* title)
{
	static size_t snLastPrecent = 0;
	static size_t snTotal = 100;
	if (bNew)
	{
		if (nTotal > 0)
			snTotal = nTotal;
		snLastPrecent = n * 100 / snTotal;

		char str[5];
		sprintf(str, "%3d%%", snLastPrecent);
		wbThreadManager::s_pThreadOutMager->m_pStdOutBlock[nThreadId+1]->Printf("%s:%s", title, str);
	}
	else
	{
		int nNew = (int)(1.0*n/snTotal*100);
		if ( nNew > snLastPrecent )
		{
			snLastPrecent = nNew;
			
			char str[5];
			sprintf(str, "%3d%%", snLastPrecent);
			wbThreadManager::s_pThreadOutMager->m_pStdOutBlock[nThreadId+1]->Printf("\b\b\b\b%s", str);
		}
	}
}
void tprecent(int nThreadId, FILE *fp, bool bNew /* = false */, const char* title /* = "Process" */)
{
	if (bNew)
	{
		fseek(fp, 0, SEEK_END);
		tprecent(nThreadId, 0 , true, ftell(fp), title);
		fseek(fp, 0, SEEK_SET);
	}
	else
	{
		tprecent(nThreadId, ftell(fp));
	}
}