// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Line Hash class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/**
 * \file 
 * \author wangbin
 * \date 2013-9-23
 * \brief wbLHash�����Թ�ϣ��
*/

#ifndef _WB_LHASH_H_
#define _WB_LHASH_H_


#include "wbLog.h"
#include "wbMap.h"

#define lhash_error(x) lout_error("[wbLHash] "<<x)
#define lhash_assert(b) { if(!(b)) lhash_error("[assert] "<<#b) }

#define LHASH_UNITS_NEW(p, size) {p = new wbMapUnit<KeyT, DataT> [size];}
#define LHASH_UNITS_DELETE(p) { if (p) {delete [] (p); p = NULL; } }
#define Bit2Size(bits) ( (unsigned)(1<<(bits)) )

#define wbLHash_maxBitLimit 31		//���ƿ��ٵ��ڴ��bit�����ܳ���31


template <class KeyT, class DataT> class wbLHash;
template <class KeyT, class DataT> class wbLHashIter;


const unsigned c_nMinHashBits = 3; //С�ڴ˱�������ʱ�򣬲�����������
const float c_fFillRatio = 0.8f; //����ʣ����Լ����ϣ����Ҫ�Ŀռ�


/// ���Թ�ϣ��
template <class KeyT, class DataT>
class wbLHash
{
	friend class wbLHashIter<KeyT, DataT>;

public:
	wbLHash(unsigned nSize = 0):m_nMaxBits(0),m_pUnit(NULL),m_nUnitNum(0)
	{
		if (nSize > 0)
			Alloc(RoundSize(nSize));
	}
	~wbLHash()
	{
		Release();
	}

	/**
	�������
	*/
	unsigned GetNum() const { return m_nUnitNum; }
	unsigned GetSize() const { return Bit2Size(m_nMaxBits); }

	/**
	���ô�С�������ڴ�
	*/
	void SetSize(unsigned nSize)
	{
		if (nSize > 0)
			Alloc(RoundSize(nSize));
	}
	/**
	������Ҫ���ٵ��ڴ�ռ���
	*/
	unsigned RoundSize(unsigned nSize)
	{
		if (nSize < Bit2Size(c_nMinHashBits))
			return nSize;
		
		return (unsigned)( (nSize+1)/c_fFillRatio );
	}
	/**
	�����ڴ�ռ�
	*/
	void Alloc(unsigned nSize)
	{
		unsigned maxBits, maxUnits;

		//���㣬��Ҫ����nSize����Ҫ���ڴ�ռ��bits��
		maxBits = 1; //maxBits��СΪ1
		while (Bit2Size(maxBits) < nSize) {
			lhash_assert(maxBits < wbLHash_maxBitLimit);
			++maxBits;
		}

		maxUnits = Bit2Size(maxBits);
		if (m_pUnit)
			LHASH_UNITS_DELETE(m_pUnit);
		LHASH_UNITS_NEW(m_pUnit, maxUnits);
		lhash_assert(m_pUnit);

		m_nMaxBits = maxBits;
		m_nUnitNum = 0;

		//�����е�ֵ������ΪnoKey
		for (unsigned i=0; i<maxUnits; i++)
			wbMap_noKey(m_pUnit[i].key);
	}

	/**
	�ͷſռ�
	*/
	void Release()
	{
		if (m_pUnit)
		{
			unsigned maxUnits = Bit2Size(m_nMaxBits);
			for (unsigned int i=0; i<maxUnits; i++){
				if (! wbMap_noKeyP(m_pUnit[i].key) ) {
					wbMap_freeKey(m_pUnit[i].key);
				}
			}

			LHASH_UNITS_DELETE(m_pUnit);
		}
		m_nUnitNum = 0;
		m_nMaxBits = 0;
	}
	/**
	���¿����ڴ�
	*/
	void Reset(unsigned nSize)
	{
		Release();
		if (nSize > 0)
			Alloc(RoundSize(nSize));
	}

	/**
	������ݣ������ͷ��ڴ�
	*/
	void Clean()
	{
		if (m_pUnit) {
			int nMaxUnit = Bit2Size(m_nMaxBits);
			for (int i=0; i<nMaxUnit; i++) {
				if (! wbMap_noKeyP(m_pUnit[i].key))
					wbMap_noKey(m_pUnit[i].key);
			}

			m_nUnitNum = 0;
		}
	}
	/**
	�������
	*/
	void Fill(DataT d)
	{
		if (m_pUnit) {
			int nMaxUnit = Bit2Size(m_nMaxBits);
			for (int i=0; i<nMaxUnit; i++) {
				if (! wbMap_noKeyP(m_pUnit[i].key))
					m_pUnit[i].value = d;
			}
		}
	}

	/**
	����Key���ҵ�����, �����Ƿ��ҵ�
	*/
	inline bool Locate(KeyT key, unsigned &index) const
	{
		lhash_assert(!wbMap_noKeyP(key));

		if (!m_pUnit)
			return false;

		
		if (m_nMaxBits < c_nMinHashBits) 
		{
			//���Բ���
			for (unsigned int i=0; i<m_nUnitNum; i++) {
				if (wbMap_equalKey(key, m_pUnit[i].key)) {
					index = i;
					return true;
				}
			}
			
			index = m_nUnitNum;
			return false;
		} 
		else 
		{
#if _DEBUG
			int nStep = 1;
#endif
			//��ϣ����
			bool bFound = false;
			unsigned nHash = wbLHash_hashKey(key, m_nMaxBits);
			for (int i=nHash; ;i=(i+1)%Bit2Size(m_nMaxBits)) {
				if (wbMap_noKeyP(m_pUnit[i].key)) {
					index = i;
					bFound = false;
					break;
				}
				else if (wbMap_equalKey(key, m_pUnit[i].key)) {
					index = i;
					bFound = true;
					break;
				}
#if _DEBUG
				nStep++;
#endif
			}

#if _DEBUG
			//��¼���д���
			wbLHash<KeyT,DataT>::fLocateStep = 
				wbLHash<KeyT,DataT>::fLocateStep * wbLHash<KeyT,DataT>::nLocateNum / (wbLHash<KeyT,DataT>::nLocateNum + 1) + 
				1.0 * nStep / (wbLHash<KeyT,DataT>::nLocateNum + 1);
			wbLHash<KeyT,DataT>::nLocateNum++;
#endif

			return bFound;
		}

		return false;
	}

	/**
	����
	*/
	DataT *Find(KeyT key, bool &bFound = bFound )
	{
		unsigned int index;
		if ( (bFound = Locate(key, index)) ) {
			return &( m_pUnit[index].value );
		} else {
			return NULL;
		}
	}

	/**
	����
	*/
	DataT *Insert(KeyT key, bool &bFound = bFound )
	{
		unsigned int index;

		if (!m_pUnit)
			Alloc(1);

		if ( (bFound = Locate(key, index)) ) {
			return &(m_pUnit[index].value);
		} else {
			unsigned nNewSize = RoundSize(m_nUnitNum + 1);

			if (nNewSize > Bit2Size(m_nMaxBits)) { //��Ҫ���¿����ڴ�
				wbMapUnit<KeyT, DataT> *pOldUnit = m_pUnit;
				unsigned nOldUnitNum = m_nUnitNum;
				unsigned nOldMaxUnit = Bit2Size(m_nMaxBits);

				m_pUnit = NULL;  //��Ҫ���ָ�룬�������Alloc���ͷŵ��ڴ�
				Alloc(nNewSize); //�����ڴ�
				m_nUnitNum = nOldUnitNum;

				if (m_nMaxBits < c_nMinHashBits) {
					//ֻ������copy��������
					memcpy( m_pUnit, pOldUnit, sizeof(pOldUnit[0])*nOldUnitNum);
				} else {
					// rehash
					for (unsigned i=0; i<nOldMaxUnit; i++) {
						KeyT curKey = pOldUnit[i].key;
						if ( !wbMap_noKeyP(curKey) ) {
							Locate(curKey, index);
							memcpy( &(m_pUnit[index]), &(pOldUnit[i]), sizeof(pOldUnit[i]) );
						}
					}
				}

				LHASH_UNITS_DELETE(pOldUnit);
				
				//����Locate
				Locate(key, index);
			}
			
			m_pUnit[index].key = wbMap_copyKey(key);
			memset(&(m_pUnit[index].value), 0, sizeof(m_pUnit[index].value));
			new (&(m_pUnit[index].value)) DataT; //���ù��캯��

			m_nUnitNum++;
			return &(m_pUnit[index].value);
		}
	}

	/*
	void Remove(KeyT key, bool &bFound = bFound)
	{
		//***����������***
		unsigned index;
		if ( (bFound = Locate(key, index) ) ) {
			wbMap_freeKey(m_pUnit[index].key);
			wbMap_noKey(m_pUnit[index].key);
			m_nUnitNum--;
		}
	}
	*/

	/// ����
	void Copy(wbLHash<KeyT, DataT> &other)
	{
		if (&other == this)
			return;

		if (other.m_pUnit) {
			unsigned maxSize = Bit2Size(other.m_nMaxBits);
			Alloc(maxSize);
			for (int i=0; i<maxSize; i++) {
				KeyT thisKey = other.m_pUnit[i].key;

				if (!wbMap_noKeyP(thisKey)) {
					m_pUnit[i].key = wbMap_copyKey(thisKey);

					new (&(m_pUnit[i].value)) DataT;

					m_pUnit[i].value = other.m_pUnit[i].value;
				}
			}
			m_nUnitNum = other.m_nUnitNum;
		} else {
// 			if (m_pUnit)
// 				cout<<"!!!!!"<<endl;
			Clean();
		}
	}

protected:
	unsigned m_nMaxBits; ///< �������ڴ�ı�������2^maxBits Ϊ�ڴ�ռ��С
	unsigned m_nUnitNum; ///< ��ǰ����ĵ�Ԫ����

	wbMapUnit<KeyT, DataT> *m_pUnit; ///< ����buffer

public:
	static bool bFound;
#ifdef _DEBUG
	static int nLocateNum;	  ///< ���Ҵ���
	static double fLocateStep;  ///< ƽ�����в���
#endif
};

template <class KeyT, class DataT>
bool wbLHash<KeyT, DataT>::bFound = false;

#ifdef _DEBUG
template <class KeyT, class DataT>
int wbLHash<KeyT, DataT>::nLocateNum = 0;
template <class KeyT, class DataT>
double wbLHash<KeyT, DataT>::fLocateStep = 0;
#endif


///HashIter��LHash������
template <class KeyT, class DataT>
class wbLHashIter
{
private:
	wbLHash<KeyT, DataT> *m_pHash;
	unsigned m_nCurIndex;

	bool (*m_sortFun)(KeyT, KeyT); ///< ������, ��ʾ������Ϊ����f(x1,x2)����true����x1��x2����ȷ��˳��
	KeyT *m_pSortedKey;   ///< �����ź����key
public:
	wbLHashIter(wbLHash<KeyT, DataT> *pHash, bool (*sort)(KeyT, KeyT) = 0) 
	{ 
		m_pHash = pHash; 
		m_nCurIndex = 0; 
		m_sortFun = sort; 
		m_pSortedKey = NULL;

		Init();
	}
	~wbLHashIter()
	{
		if (m_pSortedKey)
			delete [] m_pSortedKey;
		m_pSortedKey = NULL;
	}
	
	void Init() 
	{ 
		m_nCurIndex = 0; 

		if (m_sortFun) {
			//��Key����
			if (m_pSortedKey)
				delete [] m_pSortedKey;
			m_pSortedKey = NULL;

			m_pSortedKey = new KeyT[m_pHash->GetNum()];
			int curKey = 0;

			int maxSize = Bit2Size(m_pHash->m_nMaxBits);
			for (int i=0; i<maxSize; i++) {
				if (!wbMap_noKeyP(m_pHash->m_pUnit[i].key)) {
					m_pSortedKey[curKey] = m_pHash->m_pUnit[i].key;
					curKey++;
				}
			}

			//����
			for (int i=0; i<curKey-1; i++) {
				for (int j=i+1; j<curKey; j++) {
					if ( !m_sortFun(m_pSortedKey[i], m_pSortedKey[j]) ) {
						KeyT t = m_pSortedKey[i];
						m_pSortedKey[i] = m_pSortedKey[j];
						m_pSortedKey[j] = t;
					}
				}
			}
		}
	}
	DataT* Next(KeyT &key)
	{
		if (m_pHash->m_pUnit == NULL || m_pHash->m_nUnitNum == 0)
			return NULL;
		
		if (m_sortFun)
		{
			//����
			if (m_nCurIndex == m_pHash->GetNum())
				return NULL;

			return m_pHash->Find(m_pSortedKey[m_nCurIndex++]);
		}
		else
		{
			for (; m_nCurIndex < Bit2Size(m_pHash->m_nMaxBits); m_nCurIndex++) {
				key = m_pHash->m_pUnit[m_nCurIndex].key;
				if ( !wbMap_noKeyP(key) ) {
					return &(m_pHash->m_pUnit[m_nCurIndex++].value);
				}
			}
		}
		
		return NULL;
	}
};

/**
 * Hashing functions
 * (We provide versions for integral types and char strings;
 * user has to add more specialized definitions.)
 */
 #define hashMask(nbits) (~((~0L)<<(nbits)))
					/* bitmask used to compute hash
					 * code modulo maxEntries */ 
inline unsigned long
wbLHash_hashKey(unsigned long key, unsigned maxBits)
{
    return (((key * 1103515245 + 12345) >> (30-maxBits)) & hashMask(maxBits));
}

// �Դ�ָ��
template <class KeyT>
inline unsigned long
wbLHash_hashKey(KeyT *key, unsigned maxBits)
{
	return wbLHash_hashKey((unsigned long)key, maxBits);
}

//�Դ�int
inline unsigned long
	wbLHash_hashKey(int key, unsigned maxBits)
{
	return wbLHash_hashKey((unsigned long)key, maxBits);
}

//�Դ�����
inline unsigned long
	wbLHash_hashKey(float key, unsigned maxBits)
{
	return wbLHash_hashKey((unsigned long)(100*key), maxBits);
}
inline unsigned long
	wbLHash_hashKey(double key, unsigned maxBits)
{
	return wbLHash_hashKey((unsigned long)(100*key), maxBits);
}

//�ַ���
inline unsigned long
wbLHash_hashKey(const char *key, unsigned maxBits)
{
    /*
     * The string hash function was borrowed from the Tcl libary, by 
     * John Ousterhout.  This is what he wrote:
     * 
     * I tried a zillion different hash functions and asked many other
     * people for advice.  Many people had their own favorite functions,
     * all different, but no-one had much idea why they were good ones.
     * I chose the one below (multiply by 9 and add new character)
     * because of the following reasons:
     *
     * 1. Multiplying by 10 is perfect for keys that are decimal strings,
     *    and multiplying by 9 is just about as good.
     * 2. Times-9 is (shift-left-3) plus (old).  This means that each
     *    character's bits hang around in the low-order bits of the
     *    hash value for ever, plus they spread fairly rapidly up to
     *    the high-order bits to fill out the hash value.  This seems
     *    works well both for decimal and non-decimal strings.
     */

    unsigned long i = 0;

    for (; *key; key++) {
	i += (i << 3) + *key;
    }
    return wbLHash_hashKey(i, maxBits);
}


/*
������
*/
template <class KeyT>
inline bool LHash_IncSort(KeyT k1, KeyT k2) { return k1<=k2;}
inline bool LHash_IncSort(const char *p1, const char *p2) { return strcmp(p2, p1)<=0; }


#endif