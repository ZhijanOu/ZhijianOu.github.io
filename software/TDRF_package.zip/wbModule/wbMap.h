// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Mapping defination. used by "wbLHash" and "wbTrie"
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#ifndef _WB_MAP_H_
#define _WB_MAP_H_



#ifndef WBMAP_NBBY
#define WBMAP_NBBY	8
#endif

template <class KeyT, class DataT>
class wbMapUnit{
public:
	KeyT key;
	DataT value;
};

/*
Key Copy; ���ڶ����ַ�����Key����Ҫ���ٺ��ͷ��ڴ�
*/
template <class KeyT>
inline KeyT wbMap_copyKey(KeyT key) { return key; }
template <class KeyT>
inline void wbMap_freeKey(KeyT key) {};

//�ַ�������Ҫ���ٺ�ʾ���ڴ�
inline const char *wbMap_copyKey(const char *key) { return strdup(key); }
inline void wbMap_freeKey(const char *key) { free((void*)key); }


/*
����Ϊ��������һ����ʼֵ�������жϴ��ڴ��Ƿ񱻸���ֵ
*/
//����ָ������� ���丳ֵΪ0
template <class KeyT>
inline void wbMap_noKey(KeyT *&key) { key = 0; }
template <class KeyT>
inline bool wbMap_noKeyP(KeyT *key) { return key == 0; }

//�������������丳ֵΪ��С�ĸ���
const short c_ShortNokeyValue = (short)(1u<<(sizeof(short)*WBMAP_NBBY-1));
const int c_IntNokeyValue = (int)(1u<<(sizeof(int)*WBMAP_NBBY-1));
const long c_LongNokeyValue = (long)(1uL<<(sizeof(long)*WBMAP_NBBY-1));

inline void wbMap_noKey(int &key) { key = c_IntNokeyValue; }
inline bool wbMap_noKeyP(int key) { return key == c_IntNokeyValue; }
inline void wbMap_noKey(short int &key) { key = c_ShortNokeyValue; }
inline bool wbMap_noKeyP(short int key) { return key == c_ShortNokeyValue; }
inline void wbMap_noKey(long int &key) { key = c_LongNokeyValue; }
inline bool wbMap_noKeyP(long int key) { return key == c_LongNokeyValue; }

//����unsigned���������丳ֵΪ������
const short unsigned c_UShortNokeyValue = ~(short unsigned)0;
const unsigned c_UIntNokeyValue = ~(unsigned)0;
const long unsigned c_ULongNokeyValue = ~(long unsigned)0;

inline void wbMap_noKey(unsigned &key) { key = c_UIntNokeyValue; }
inline bool wbMap_noKeyP(unsigned key) { return key == c_UIntNokeyValue; }
inline void wbMap_noKey(short unsigned &key) { key = c_UShortNokeyValue; }
inline bool wbMap_noKeyP(short unsigned key) { return key == c_UShortNokeyValue; }
inline void wbMap_noKey(long unsigned &key) { key = c_ULongNokeyValue; }
inline bool wbMap_noKeyP(long unsigned key) { return key == c_ULongNokeyValue; }

//���ڸ����������丳ֵΪһ���㹻�����
const float c_floatNokeyValue = 1e15;
const double c_doubleNokeyValue = 1e20;
inline void wbMap_noKey(float &key) { key = c_floatNokeyValue; }
inline bool wbMap_noKeyP(float key) { return key==c_floatNokeyValue; }
inline void wbMap_noKey(double &key) { key = c_doubleNokeyValue; }
inline bool wbMap_noKeyP(double &key) { return key==c_doubleNokeyValue; }

/*
�Ƚ�Key
*/
template <class KeyT>
inline bool wbMap_equalKey(KeyT key1, KeyT key2) { return (key1 == key2); }
inline bool wbMap_equalKey(float key1, float key2) { return fabs(key1-key2)<1e-2; }
inline bool wbMap_equalKey(double key1, double key2) { return fabs(key1-key2)<1e-15; }
inline bool wbMap_equalKey(const char *pStr1, const char *pStr2) { return strcmp(pStr1, pStr2)==0; }

/*
Keyת��
*/
template <class KeyT>
inline void wbMap_transKey(KeyT srcKey, KeyT &desKey) { desKey = srcKey; }
inline void wbMap_transKey(const char *pSrcStr, int &desKey) { desKey = atoi(pSrcStr); }
inline void wbMap_transKey(const char *pSrcStr, float &desKey) { desKey = atof(pSrcStr); }

/*
WriteB
*/
template <class KeyT>
inline void wbMap_writeB(KeyT key, FILE *fp) { fwrite(&key, sizeof(key), 1, fp); }
inline void wbMap_writeB(const char *pStr, FILE *fp) {
	unsigned nLen = strlen(pStr);
	fwrite(&nLen, sizeof(nLen), 1, fp);
	fwrite(pStr, sizeof(char), nLen, fp);
}

/*
ReadB
*/
template <class KeyT>
inline void wbMap_readB(KeyT &key, FILE *fp) { fread(&key, sizeof(key), 1, fp); }
inline void wbMap_readB(char *pStr, FILE *fp) {
	unsigned nLen;
	fread(&nLen, sizeof(nLen), 1, fp);
	fread(pStr, sizeof(char), nLen, fp);
}

#endif