// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF model, base class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/** 
 * \file
 * \author wangbin
 * \date 2014-02-27
 * \brief JRFģ��
 */
#pragma once
#include "wbJRFfeature.h"

namespace wbJRF
{
	/** 
	 * \class
	 * \brief JRFģ��, ȫ�ֹ�һ����ģ��, scheme2
	 */
	class model
	{
	public:
// 		wbArray<Feature*> m_aFeatures; ///< ������
// 		wbArray<double> m_aValues; ///< ��������,���������е��������Ӧ
		Feature**	m_aFeatures;	///< ����
		double*		m_aValues;		///< ����
		int			m_nFeatNum;		///< ����������Ҳ�ǲ�������

		int m_nMaxLen; ///< ģ����������󳤶ȣ����Դﵽ��,��������ʼ������
		Vocab *m_pVocab; ///< �ֵ�

		LogP m_logNormalizationFactor; ///< ������һ��ϵ��

	public:
		model(Vocab *pVocab, int nMaxLen = 10):
		  m_pVocab(pVocab), m_nMaxLen(nMaxLen),
		  m_logNormalizationFactor(0) {
			  m_aFeatures = NULL;
			  m_aValues = NULL;
			  m_nFeatNum = 0;
		};
		~model() {
			CleanFeatures();
		};

		/// ���Featrue, �ͷ�Feature���ٵ��ڴ�
		virtual void CleanFeatures() {
			for (int i=0; i<m_nFeatNum; i++)
				SAFE_DELETE(m_aFeatures[i]);
			SAFE_DELETE_ARRAY(m_aFeatures);
			SAFE_DELETE_ARRAY(m_aValues);
		}
		/// ����һ������
		virtual void AddFeature(Feature *pf, double dValue = 0) {
			lout_assert(m_aFeatures);
			lout_assert(m_aValues);

			m_aFeatures[m_nFeatNum] = pf;
			m_aValues[m_nFeatNum] = dValue;
			m_nFeatNum++;
		}
		/// ����������еĸ���,δ��һ��
		/** 
		 * \param [in] pSeq ����������
		 */
		virtual LogP GetLogProb(VocabID *pSeq, int nLen, bool bNorm = true){
			double dSum = 0;
			for (int i=0; i<m_nFeatNum; i++) { //ÿ������
				dSum += m_aValues[i] * m_aFeatures[i]->nAccept(pSeq, nLen);
			}
			return (bNorm)? dSum-m_logNormalizationFactor: dSum; /// ��һ��
		}
		
		/// ���ò���ֵ
		void SetParams(double *pdParams)
		{
			memcpy(m_aValues, pdParams, sizeof(double)*m_nFeatNum);
		}

		/// Write Features
		virtual void WriteFeatures(wbFile &file)
		{
			file.Print("FeatureNum=%d\n", m_nFeatNum);
			for (int i=0; i<m_nFeatNum; i++) 
			{
				wbString strType = FeatureType2Str(m_aFeatures[i]->type);
				file.Print("[%s]\t", strType.GetBuffer());
				file.Print("value=%lf\t", m_aValues[i]);
				m_aFeatures[i]->Write(file);
				file.Print("\n");
			}
		}
		/// Read Features
		virtual void ReadFeatures(wbFile &file)
		{
			int nNum = 0;
			fscanf(file, "FeatureNum=%d\n", &nNum);

			SAFE_NEW_ARRAY(m_aFeatures, Feature*, nNum);
			SAFE_NEW_ARRAY(m_aValues, double, nNum);

			wbString strType(100);
			double fValue;
			Feature *pFeature;
			for (int i=0; i<nNum; i++) {
				fscanf(file, "[%s\t", strType.GetBuffer());
				*strType.End() = '\0';
				
				FType t = FeatureStr2Type(strType);
				Feature* pFeature = FeatureCreate(t, *m_pVocab);

				fscanf(file, "value=%lf\t", &fValue);
				pFeature->Read(file);
				fscanf(file, "\n");

				AddFeature(pFeature, fValue);
			}
		}
		/// Write
		virtual void WriteT(wbFile &file)
		{
			file.Print("MaxLen=%d\nNorm=%lf\n", m_nMaxLen, m_logNormalizationFactor);
			WriteFeatures(file);
		}
		/// Read
		virtual void ReadT(wbFile &file)
		{
			fscanf(file, "MaxLen=%d\nNorm=%lf\n", &m_nMaxLen, &m_logNormalizationFactor);

			ReadFeatures(file);
		}
		/// ����PPL����Ȼֵ
		virtual void PPL( const char *path, double &dPerplexity, double &dLogLikelihood, wbFile *pOut = NULL)
		{
			wbFile file(path, "rt");

			if ( pOut )
				pOut->Print("length\t-logprob\n");

			dPerplexity = 0;
			dLogLikelihood = 0;
			int nWord = 0;
			int nLine = 0;

			char *pLine;
			while (pLine = file.GetLine(true))
			{
				if ( strlen(pLine) == 0 )
					continue;

				wbArray<VocabID> aSeq;

				char *p = strtok(pLine, " \t");
				while(p) {
					aSeq.Add(atoi(p));
					p = strtok(NULL, " \t");
				}

				double d = GetLogProb(aSeq.GetBuffer(), aSeq.GetNum());
				dPerplexity += d / log(10.0);
				dLogLikelihood += d;
				nWord += aSeq.GetNum()+1; //���Ͻ�����
				nLine++;

				if (pOut) {
					pOut->Print("%d\t%lf\n", aSeq.GetNum(), -d);
				}
			}
			dLogLikelihood = - dLogLikelihood / nLine;
			dPerplexity = pow(10, -dPerplexity/nWord);
			lout<<"word="<<nWord-nLine<<" sent="<<nLine<<endl;
		}
	};
}



