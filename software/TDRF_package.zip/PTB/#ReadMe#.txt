
Note : This toolkit is for Windows x64 system. More than 8G memory is needed.

Usage:
[corpus] 
1. Copy the training/test/valid corpus into the folder 'corpus/', named as
	ptb.train.txt
	ptb.test.txt
	ptb.valid.txt
  NOTE: the existing corpus in 'corpus/' just examples, containing only 10 sentences in each files.
2. Generate the vocabulary into the folder 'corpus/':
	wsj.lext	:	the vocabulary containing the begin/end tokens <s> </s>;
	wsj.list	:	the vocabulary not containing the begin/end tokens, numbered from 0; This is used in our RF models. For each word, the number in 'wsj.list' should be the number in 'wsj.lest' minus 2.
	wsj_c200.vocab	:	the vocabulary containing the hard-class information. This vocabulary is corresponding to 'wsj.list'. Each line denotes 'word-id  word-id  class-id'. The total class number is 200.
	NOTE: There are examples for the three files in "corpus\examples".
	
[Train random field models]
1. Go into "corpus\"
        Run "#getCorpusID.bat", tu get the vocalulary, and translate the corpus into id and binary style.
		Run "#cluster_c200.bat". Wait the program end and get the class result. Get the new "wsj_c200.vocab".

2. Run '#2_features_c200.bat'	:	Generate the features files used in RF models. 
	Generate '*.feat' text files.
	
3.	Go into the folder 'models', run the bat to training the RF models.	

4.  Go into the folder 'rescore', rum the bat to rescore n-best list.



















