// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Chinese corpus processing
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbChTxt.h"

namespace wbChTxt
{

	wbString Number2Word(char *pStrNum, int nLen)
	{
		wbString word = "";

		
		bool bAddZero = false;

		for (int i=0; i<nLen; i++) {

			int nNum = pStrNum[i] - '0';

			lout_assert(nNum >= 0);
			lout_assert(nNum <= 9);

			if (nNum == 0) {
				bAddZero = true;
				continue;
			}

			
			wbString strUnit( &c_units[2*(nLen-i-1)], 2 );
			wbString strNum( &c_nums[2*nNum], 2 );

			if (bAddZero)
				word += wbString( &c_nums[0], 2 );
			word += strNum;
			if ( nLen-i > 1) //��λ��λ����Ҫ
				word += strUnit;

			bAddZero = false;
		}

		//����Щ�򵥵Ĵ���
		wbString resWord(word);
		//��ֹ���֡�һʮ���������
		if (strstr(word, "һʮ") == word.GetBuffer()) {
			resWord = word.GetBuffer() + 2;
		}
		//����ֻ��0�����
		if (resWord == "") {
			resWord = Year2Word(pStrNum, nLen);
		}

		return resWord;
	}
	wbString Year2Word(char *pStrNum, int nLen)
	{
		wbString word;
		for (char *p=pStrNum; p<pStrNum+nLen && *p!='\0'; p++) {
			int nNum = *p - '0';
			lout_assert(nNum>=0);
			lout_assert(nNum<=9);
			word += wbString( &c_nums[2*nNum], 2 );
		}
		return word;
	}
	wbString Decimals2Word(char *pStrNum, int nLen)
	{
		char *pDot = strchr(pStrNum, '.');
		if ( !pDot || pDot >= pStrNum+nLen )
			return Number2Word(pStrNum, nLen);
		
		wbString word;
		int nIntLen = strlen(pStrNum) - strlen(pDot);

		word = Number2Word(pStrNum, nIntLen);
		word += "��";
		for (char *p=pDot+1; p<pStrNum+nLen && *p!='\0'; p++) {
			int nNum = *p - '0';
			lout_assert(nNum>=0);
			lout_assert(nNum<=9);
			word += wbString( &c_nums[2*nNum], 2 );
		}

		return word;
	}
	wbString Fraction2Word(char *pStrNum)
	{
		char *pSeg = strchr(pStrNum, '/');
		if (!pSeg)
			return Number2Word(pStrNum, strlen(pStrNum));

		wbString word;
		int nLen1 = strlen(pSeg+1);
		int nLen2 = strlen(pStrNum) - nLen1 - 1;
		word += Number2Word(pSeg+1, strlen(pSeg+1));
		word += "��֮";
		word += Number2Word(pStrNum, nLen2);
		return word;
	}
	wbString Precent2Word(char *pStrNum)
	{
		int nLen = strlen(pStrNum);
		if ( pStrNum[nLen-1] != '%' )
			return Decimals2Word(pStrNum, nLen);

		wbString word("�ٷ�֮");
		word += Decimals2Word(pStrNum, nLen-1);
		return word;
	}

	bool bSentContentSymbols(char *pStr)
	{
		char c[3];
		wbCharIter iter(pStr);
		while (iter.Next(c)){
			if ( strlen(c) == 1 || bChSymbol(c) )
				return true;
		}
		return false;
	}


	void TxtFilter::LoadRules(wbFile &file)
	{
		//���ӵ��������������opt �����ַ���field2 ���޳�
		//field1: һ�����ַ���������һ���ֽڣ�Ҳ�����������ֽ�
		//opt���̶������ֽ�
		//field2: ���볤��
		char *pLine;
		int nNum=0;
		while (pLine = file.GetLine())
		{
			int nLen = strlen(pLine);
			
			if (nLen < 4)
				lout_error("line="<<file.nLine<<"illegal rules! nLen="<<nLen);

			m_aRules[nNum].field1 = GetSym1(pLine);
			m_aRules[nNum].opt = wbString(pLine, 2);
			pLine += 2;
			m_aRules[nNum].field2 = wbString(pLine);

			*m_ruleHash.Insert(m_aRules[nNum].field1) = nNum;

			nNum++;
		}
	}
	wbString TxtFilter::GetSym1( char *&p )
	{
		if (*p & 0x80) {
			p+=2;
			return wbString(p-2, 2);
		}
		return wbString(p++, 1);
	}

	void TxtFilter::PerformRules()
	{
		wbString strNewLine(strlen(m_pSent)*2);

		char c[3];
		wbCharIter iter(m_pSent);
		while (iter.Next(c)) 
		{
			int *pRuleId = m_ruleHash.Find(c);
			if (pRuleId)
			{
				//��¼���������ַ�
				bool bFound;
				m_processedSyms.Insert(c, bFound);

				if ( m_aRules[*pRuleId].opt == c_opt_rep ) {
					//�滻
					strNewLine += m_aRules[*pRuleId].field2;

					if (!bFound)
						lout_rule<<c<<" => "<<m_aRules[*pRuleId].field2<<endl;

				} else if ( m_aRules[*pRuleId].opt == c_opt_del ) { 
					//ɾ��
					if (!bFound)
						lout_rule<<"c"<<" del"<<endl;
				}
			}
			else
			{
				strNewLine += c;
			}
		}

		strcpy(m_pSent, strNewLine);
	}

	void TxtFilter::SegmentSentence()
	{
		char c[3];
		wbCharIter iter(m_pSent);
		while (iter.Next(c)) 
		{
			if ( bSentEnd(c) ) {
				*(iter.m_pCur-1) = ' ';
			}
		}
	}

	void TxtFilter::RemoveMarks()
	{
		wbString strNewSent;

		char c[3];
		wbCharIter iter(m_pSent);
		while (iter.Next(c)) 
		{
			if ( bEnSymbol(c) && !bSentEnd(c) && !bEnLetter(c) && c[0]!=' ' ) { //�����ո�
				//��㣬����
			} else {
				strNewSent += c;
			}
		}

		strcpy(m_pSent, strNewSent);
	}

	void TxtFilter::RemoveSymbolSegment()
	{
		wbString strNewSent(strlen(m_pSent));

		char *p = strtok(m_pSent, " ");
		while (p) {
			if (bContentChZi(p)) {
				strNewSent += p;
				strNewSent += " ";
			} else {
				lout_rm<<p<<endl;
			}
			p = strtok(NULL, " ");
		}

		strcpy(m_pSent, strNewSent);
	}

	void TxtFilter::RemovePNote()
	{
		wbString strNewSent(strlen(m_pSent));

		char *pBeg = NULL;
		char c[3];
		wbCharIter iter(m_pSent);
		while (iter.Next(c))
		{
			if ( bEnSymbol(c) && c[0] == '(' )
				pBeg = iter.m_pCur;
			else if (bEnSymbol(c) && c[0] == ')') {
				if (pBeg) {
					wbString strNote(pBeg, iter.m_pCur-1-pBeg);
					if ( !bContentSymbol(strNote) )
						strNewSent += strNote;
					else
						lout_rm<<"("<<strNote<<")"<<endl;

					pBeg = NULL;
				}
				
			} else {
				if (!pBeg)
					strNewSent += c;
			}
		}

		strcpy(m_pSent, strNewSent);
	}

	void TxtFilter::ProcessNumbers()
	{
		wbString strNewSent;

		wbString strNum;
		char c[3];
		wbCharIter iter(m_pSent);
		while (iter.Next(c)) {
			if ( bEnSymbol(c) ) {
				if ( bNumber(c) ) {
					strNum += c;
				} else if (strNum!="") {
					strNum += c;
				} else
					strNewSent += c;
			} else {
				if (strNum == "")
					strNewSent += c;
				else
				{
					wbString chNum = TransNumber(strNum, c);

					if (strNum != chNum) {
						lout_num<<"Succeed "<<strNum<<c<<" -> "<<chNum<<c<<endl;
					}else {
						lout_num<<"Failed "<<strNum<<c<<endl;
					}

					
					strNewSent += chNum;
					strNewSent += c;
					strNum = ""; //���
				}
			}
		}

		strcpy(m_pSent, strNewSent);
	}
	wbString TxtFilter::TransNumber( wbString &strNum, const char *nextChar )
	{
		wbArray<char> aEnSyms;
		int nLen = strNum.GetLength();
		for (int i=0; i<nLen; i++) {
			if ( strNum[i] > '9' || strNum[i] < '0' ) {
				aEnSyms.Add(strNum[i]);
			}
		}

		if ( aEnSyms.GetNum()==0 ) {  //˵��������

			int nNum = atoi(strNum);
			if ( nextChar[0] == c_ch_year[0] && nextChar[1] == c_ch_year[1] &&
				nNum < 3000 ) {//��
					return Year2Word(strNum, nLen);
			} else {
				return Number2Word(strNum, nLen);
			}
		} else if ( aEnSyms.GetNum() == 1 ) { //������������ķ���
			if (aEnSyms[0] == '.') //С��
				return Decimals2Word(strNum, nLen);
			else if (aEnSyms[0] == '/') //����
				return Fraction2Word(strNum);
			else if (strNum[nLen-1] == '%') //�ٷֱ�
				return Precent2Word(strNum);
		}

		return strNum;
	}
}
