// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Lexcion class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbLexcion.h"

wbLexcion::wbLexcion(int size):m_wordArray(size)
{
	nWordInfoSize = 16;
	nWordInfoNum = 0;
	nTotalZiNum = 0;
}

wbLexcion::~wbLexcion()
{
	for (int i=0; i<nWordInfoNum; i++)
		SAFE_DELETE(m_wordArray[i]);
}

void wbLexcion::LoadGspLext(FILE *fp)
{
	if (fp == NULL)
		return;

	const int maxLineLength = 1000;

	char strLine[maxLineLength];
	
	for (int i=0; i<4; i++)
		fgets(strLine, maxLineLength, fp);

	fscanf(fp, "nWordInfoNum=%d\n", &nWordInfoNum);
	fscanf(fp, "nWordInfoSize=%d\n", &nWordInfoSize);
	fscanf(fp, "nTotalZiNum=%d\n", &nTotalZiNum);

	int nLineNum;
	int nId, nNum, nId2;
	char word[100];
	char cTemp;
	for (nLineNum=0; nLineNum<nWordInfoNum; nLineNum++)
	{
		fgets(strLine, maxLineLength, fp);

		stringstream str(strLine);
		
		str>>nId>>cTemp>>nNum>>cTemp>>nId2>>cTemp>>word;

		wbWordSet *pWordSet = new wbWordSet(strlen(word), nNum);
		pWordSet->nId = nId;
		pWordSet->nId2 = nId2;
		pWordSet->nNum = nNum;
		strcpy(pWordSet->pChar, word);
		for (int i=0; i<nNum; i++)
			str>>pWordSet->pProun[i];

		m_wordArray[nLineNum] = pWordSet;
	}
}


void wbLexcion::WriteGspLext(FILE *fp)
{
	if (fp == NULL)
		return;

	fprintf(fp, "nObjNum:1\n\n");
	fprintf(fp, "nObjNo:0\n_chlexicon_WordInforVersion{1}_LexID{3}\n");
	fprintf(fp, "nWordInfoNum=%d\n", nWordInfoNum);
	fprintf(fp, "nWordInfoSize=%d\n", nWordInfoSize);
	fprintf(fp, "nTotalZiNum=%d\n", nTotalZiNum);

	for (int i=0; i<nWordInfoNum; i++)
	{
		wbWordSet *pSet = m_wordArray[i];
		fprintf(fp, "%d:\t%d\t[%d]\t%s\t", pSet->nId, pSet->nNum, pSet->nId2, pSet->pChar);
		for(int n=0; n<pSet->nNum; n++)
			fprintf(fp, "%d ", pSet->pProun[n]);
		fprintf(fp, "\t\n");
	}
}

void wbLexcion::SortAndReID(bool bSorted)
{
	if (bSorted) {
		lout<<"Lext Sorted..."<<endl;
		titlePrecent(0, true, m_wordArray.GetNum()-1, "Lext Sort");
		for (int i=0; i<m_wordArray.GetNum()-1; i++){
			for (int j=i+1; j<m_wordArray.GetNum(); j++) {
				if ( m_wordArray[i]->nNum > m_wordArray[j]->nNum || 
					(m_wordArray[i]->nNum == m_wordArray[j]->nNum && strcmp(m_wordArray[i]->pChar, m_wordArray[j]->pChar) > 0 )
					)
				{
					wbWordSet *t = m_wordArray[i];
					m_wordArray[i] = m_wordArray[j];
					m_wordArray[j] = t;
				}
			}

			titlePrecent(i);
		}
	}

	for (int i=0; i<m_wordArray.GetNum(); i++)
	{
		m_wordArray[i]->nId = i;
		m_wordArray[i]->nId2 = i;
	}
}


