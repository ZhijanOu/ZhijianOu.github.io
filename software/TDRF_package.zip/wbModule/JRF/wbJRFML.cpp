// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF model estimation. Exact estimation.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFML.h"

namespace wbJRF
{

	void MLfunc::Empirical(Corpus &corpus)
	{
//		int nMaxLine = 0;	/// ���Ӹ���
//		int nUseLine = 0;	/// ʹ�õľ�����
//		int nMaxLength = 0; /// ͳ����󳤶�
		m_aFeaExpe.SetNum(m_pModel->m_nFeatNum);
		m_aFeaExpe.Fill(0);


		wbArray<int> a;
		titlePrecent(0, true, corpus.m_nLine, "[OMP] Count empirical");
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);

			
			if (a.GetNum() <= m_pModel->m_nMaxLen) {
#pragma omp parallel for
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					int nFeat = m_pModel->m_aFeatures[i]->nAccept(a, a.GetNum());
					m_aFeaExpe[i] += m_pModel->m_aLenProb[a.GetNum()] * nFeat / m_aLenCount[a.GetNum()] ;
				}
			}

			titlePrecent(l+1);
		}

// 		lout_variable(nUseLine);
// 		lout_variable(nMaxLine);
// 		lout_variable(nMaxLength);

		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_aFeaExpe[i] = Prob2LogP(m_aFeaExpe[i]) /*- Prob2LogP(nUseLine)*/;
		}
	}

	void MLfunc::EmpiricalVar( Corpus &corpus )
	{
		m_aFeaVar.SetNum(m_pModel->m_nFeatNum);
		m_aFeaVar.Fill(0);
		wbDArray<double> aFeatMeanPerLen(m_pModel->m_nMaxLen+1, m_pModel->m_nFeatNum);
		aFeatMeanPerLen.Fill(0);

		wbArray<int> a;
		titlePrecent(0, true, corpus.m_nLine, "Count Feature Mean Per Length");
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);
			int nLen = a.GetNum();
			if (a.GetNum() <= m_pModel->m_nMaxLen) {
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					int nFeat = m_pModel->m_aFeatures[i]->nAccept(a, a.GetNum());
					aFeatMeanPerLen.Get(a.GetNum(), i) += nFeat / m_aLenCount[a.GetNum()];  //��¼ÿ�����ȵľ�ֵ
				}
			}
			titlePrecent(l+1);
		}


		titlePrecent(0, true, corpus.m_nLine, "Count Feature Various");
		for (int l=0; l<corpus.m_nLine; l++)
		{
			corpus.GetLine(l, a);
			int nLen = a.GetNum();

			if (a.GetNum() <= m_pModel->m_nMaxLen) {
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					int nFeat = m_pModel->m_aFeatures[i]->nAccept(a, a.GetNum());
					m_aFeaVar[i] += m_pModel->m_aLenProb[nLen] * pow(nFeat-aFeatMeanPerLen.Get(nLen,i)/*LogP2Prob(m_aFeaExpe[i])*/, 2) / m_aLenCount[nLen] ;
				}
			}
			titlePrecent(l+1);
		}

// 		lout_variable(nUseLine);
// 		lout_variable(nMaxLine);
// 		lout_variable(nMaxLength);

		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_aFeaVar[i] = Prob2LogP( sqrt(m_aFeaVar[i]) );  // �����׼��
		}
	}



	double MLfunc::GetValue(double *pdParams)
	{
		if (pdParams)
			m_pModel->SetParams(pdParams);

		double dValue = 0;
		wbArray<int> a;
		for (int i=0; i<m_corpusTrain.m_nLine; i++) {
			m_corpusTrain.GetLine(i, a);
			int nLen = a.GetNum();
			double d = m_pModel->GetLogProb(a, a.GetNum());
			dValue += m_pModel->m_aLenProb[nLen] * d / m_aLenCount[nLen]; 
		}
		//dValue /= m_aTrainSeqs.GetNum();
		dValue = -dValue;  //������Ȼֵ�Ǳ��ģ���Ҫת��Ϊ��׼��С������

		if ( m_reg_l2 > 0 ) {
			double d = 0;
			for (int i=0; i<m_nParamNum; i++) {
// #ifdef _FeatNorm
// 				d += pow( pdParams[i]/LogP2Prob(m_aFeaVar[i]), 2 );
// #else
				d += pow(pdParams[i], 2);
//#endif
			}
			//lout_variable(d);
			dValue += (m_reg_l2 /2 * d);
		}
		if ( m_reg_l1 > 0 ) {
			double d = 0;
			for (int i=0; i<m_nParamNum; i++) {
				d += fabs(pdParams[i]);
			}
			dValue += m_reg_l1 * d;
		}

		return dValue; 
	}

	bool MLfunc::GetGradient(double *pdParams, double *pdGradient)
	{
		if (pdParams)
			m_pModel->SetParams(pdParams);

		wbArray<LogP> aExpt(m_nParamNum);

		m_pModel->LogExpectation(aExpt);

		for (int i=0; i<m_nParamNum; i++) {
			pdGradient[i] = -( LogP2Prob(m_aFeaExpe[i]) - LogP2Prob(aExpt[i]) );
			
			
#ifdef _FeatNorm
			pdGradient[i] /= LogP2Prob(m_aFeaVar[i]);
#endif
			pdGradient[i] += (m_reg_l2 * pdParams[i]);
			if (m_reg_l1 > 0) {
				if ( fabs(pdParams[i]) > 1e-10 ) {
					if ( pdParams[i] > 0 )
						pdGradient[i] += m_reg_l1;
					else 
						pdGradient[i] -= m_reg_l1;
				}
			}
		}

// 		for (int i=26; i<27; i++)
// 			lout<<LogP2Prob(m_aFeaExpe[i])<<" "<<LogP2Prob(aExpt[i])<<endl;
// 		Pause();

		return true;
	}

	int MLfunc::GetExtraValues(double *pdParams, double *pdValues)
	{
		if (pdParams)
			m_pModel->SetParams(pdParams);

		wbArray<double> aSaveLenProb;
		aSaveLenProb.Copy(m_pModel->m_aLenProb);

		//ʹ�þ���ĳ��ȷֲ���������Ȼֵ
		for (int i=1; i<=m_pModel->m_nMaxLen; i++) { //Ϊ���ȷֲ���ֵ
			m_pModel->m_aLenProb[i] = 1.0 * m_aLenCount[i] / m_corpusTrain.m_nLine;
		}

		pdValues[0] = CaculateLogLikelihood(&m_corpusTrain, true);
		pdValues[1] = CaculateLogLikelihood(&m_corpusTest, true, &pdValues[2]);

		m_pModel->m_aLenProb.Copy(aSaveLenProb);

		return 3;
	}

	double MLfunc::GetGradient(double *pdParams, int i)
	{
		if (pdParams)
			m_pModel->SetParams(pdParams);

		double dExpt = Logp_Zero;
		for (int nLen=1; nLen<=m_pModel->m_nMaxLen; nLen++)
		{
			m_pModel->ForwardBackward(nLen);
			dExpt = Log_Sum(dExpt, m_pModel->LogExpectation(nLen, i));
		}

		return -( LogP2Prob(m_aFeaExpe[i]) - LogP2Prob(dExpt) );

	}
	bool MLfunc::GetHession(double *pdParams, double *pdHession, wbFile &file)
	{
		double eps = 0.001;
		wbArray<double> aGradient1(m_nParamNum);
		wbArray<double> aGradient2(m_nParamNum);
		GetGradient(pdParams, aGradient2);
// 		for (int i=0; i<m_nParamNum; i++)
// 			lout<<aGradient2[i]<<"\t"<<GetGradient(NULL, i)<<endl;

		titlePrecent(0, true, m_nParamNum, "Hession: ");
		for (int i=0; i<m_nParamNum; i++)
		{
			double dSave = pdParams[i];
			pdParams[i] += eps;
//			GetGradient(pdParams, aGradient1);
			double dGrad = GetGradient(pdParams, i);
			pdParams[i] = dSave;

			
			pdHession[i] = (dGrad - aGradient2[i]) / eps;

			file.Print("%lf\n", pdHession[i]);
			titlePrecent(i+1);
		}

		return true;
	}

	void MLfunc::WriteEmpirical(wbFile &file)
	{
		//��������
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_pModel->m_aFeatures[i]->Write(file);
			file.Print("\t%lf\n", m_aFeaExpe[i]);
		}
	}
	void MLfunc::ReadEmpirical(wbFile &file)
	{
		//��������
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_pModel->m_aFeatures[i]->Read(file);
			fscanf(file, "\t%lf\n", &m_aFeaExpe[i]);
		}
	}
	void MLfunc::WriteFeatVar(wbFile &file)
	{
		//��������
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_pModel->m_aFeatures[i]->Write(file);
			file.Print("\t%lf\n", m_aFeaVar[i]);
		}
	}
	void MLfunc::ReadFeatVar(wbFile &file)
	{
		//��������
		for (int i=0; i<m_pModel->m_nFeatNum; i++) {
			m_pModel->m_aFeatures[i]->Read(file);
			fscanf(file, "\t%lf\n", &m_aFeaVar[i]);
		}
	}

	double MPLfunc::GetValue(double *pdParams)
	{
		if (pdParams)
			m_pModel->SetParams(pdParams, false);

		return CaculatePseudoLogLikelihood(&m_corpusTrain);
	}

	bool MPLfunc::GetGradient_norm(double *pdParams, double *pdGradient)
	{

		if (pdParams)
			m_pModel->SetParams(pdParams, false);

		//��ʼ��
		memset( pdGradient, 0, sizeof(pdGradient[0])*m_nParamNum );
		
		//�����ݶ�
		titlePrecent(0, true, m_corpusTrain.m_nLine, "Pseudo Gradient: ");
		for (int nLine=0; nLine<m_corpusTrain.m_nLine; nLine++)
		{
			//lout<<"nLine="<<nLine<<endl;
			wbArray<LogP> aLogP( m_pModel->m_pVocab->nSize );
			wbArray<VocabID> aSeq;
			m_corpusTrain.GetLine(nLine, aSeq);

			for (int h=0; h<aSeq.GetNum(); h++) //position
			{
				int nSave = aSeq[h];

				GetConditionalDistribution(aLogP, aSeq, aSeq.GetNum(), h); //���������ֲ�

				
				for (int i=0; i<m_nParamNum; i++) {
					
					double dExp = 0;
					for (int x=0; x<m_pModel->m_pVocab->nSize; x++) {
						aSeq[h] = x;
						dExp += m_pModel->m_aFeatures[i]->nAccept(aSeq, aSeq.GetNum()) * LogP2Prob(aLogP[x]);
					}
					aSeq[h] = nSave;
					double d = m_pModel->m_aFeatures[i]->nAccept(aSeq, aSeq.GetNum()) - dExp;


					pdGradient[i] += d;
				}
			}

			titlePrecent(nLine+1);
		}

		for (int i=0; i<m_nParamNum; i++)
			pdGradient[i] = -pdGradient[i] / m_corpusTrain.m_nLine;

		return true;
	}

#ifdef _OPENMP
	bool MPLfunc::GetGradient_omp(double *pdParams, double *pdGradient)
	{

		if (pdParams)
			m_pModel->SetParams(pdParams, false);

		//��ʼ��
		omp_lock_t lout_lock;
		omp_lock_t precent_lock;
		omp_lock_t file_lock;
		omp_init_lock(&precent_lock);
		omp_init_lock(&file_lock);
		omp_init_lock(&lout_lock);

		if (!m_pParallelGradient){
			SAFE_NEW_DARRAY(m_pParallelGradient, double, omp_get_max_threads(), m_nParamNum);
		}
		for (int t=0; t<omp_get_max_threads(); t++)
			memset( m_pParallelGradient[t], 0, sizeof(double)*m_nParamNum );
		memset( pdGradient, 0, sizeof(pdGradient[0])*m_nParamNum );

		wbArray<LogP> aProb( m_pModel->m_pVocab->nSize ); //������������
		wbArray<VocabID> aSeq;
		wbArray<int> aFeatNumBuffer( 2 * m_nParamNum ); //buffer
		wbArray<double> aConditionalFeatExp( m_nParamNum );
		//�����ݶ�
		titlePrecent(0, true, m_corpusTrain.m_nLine, "[OMP] Pseudo Gradient: ");
#pragma omp parallel for firstprivate(aProb, aSeq, aFeatNumBuffer, aConditionalFeatExp)
		for (int nLine=0; nLine<m_corpusTrain.m_nLine; nLine++)
		{
// 			omp_set_lock(&lout_lock);
// 			lout<<"[thread "<<omp_get_thread_num()<<"] "<<nLine<<endl;
// 			omp_unset_lock(&lout_lock);

			omp_set_lock(&file_lock);
			m_corpusTrain.GetLine(nLine, aSeq);
			omp_unset_lock(&file_lock);


			int nLen = aSeq.GetNum();
			VocabID *pSeq = aSeq.GetBuffer(); //��߷����ٶ�
			
			int *pFeatNum = aFeatNumBuffer.GetBuffer();			//����f(x)
			int *pOtherFeatNum = pFeatNum+m_nParamNum; //���治�䲿�ֵ���������
			double *pConditionalFeatExp = aConditionalFeatExp.GetBuffer(); //��������
			

// 			omp_set_lock(&lout_lock);
// 			lout<<"[thread "<<omp_get_thread_num()<<"] Read"<<endl;
// 			omp_unset_lock(&lout_lock);

			for (int h=0; h<aSeq.GetNum(); h++) //position
			{
				int nSave = aSeq[h];
				

				GetConditionalDistribution(aProb, aSeq, nLen, h); //���������ֲ�
				double *pProb = aProb.GetBuffer();

				//��log����ת��Ϊ����
				for (int x=0; x<m_pModel->m_pVocab->nSize; x++)
					pProb[x] = LogP2Prob(pProb[x]);

				//ͳ�Ƴ�����������
				memset(pFeatNum, 0, sizeof(pOtherFeatNum[0])*2*m_nParamNum);
				

				wbArray<int> aFeats;
				//���䲿������ �������ִ���ͳ��
				int nOrder = m_pModel->m_nOrder;
				for (int order=1; order<=nOrder; order++)
				{
					aFeats.Clean();
					for (int pos=0; pos<=h-order; pos++) {
						m_pModel->FindFeatures(aFeats, pSeq, nLen, pos, order);
					}
					for (int pos=nLen-order; pos>=h+1; pos--) {
						m_pModel->FindFeatures(aFeats, pSeq, nLen, pos, order);
					}
					for (int i=0; i<aFeats.GetNum(); i++)
						pOtherFeatNum[aFeats[i]] ++;
				}
				//�仯���֣��������ִ���
				for (int i=0; i<m_nParamNum; i++)
					pConditionalFeatExp[i] = pOtherFeatNum[i];
				//�����仯���֣�
				for (int x=0; x<m_pModel->m_pVocab->nSize; x++) 
				{
					pSeq[h] = x;

					aFeats.Clean();
					for (int order=1; order<=nOrder; order++)
					{
						for (int pos=max(0, h-order+1); pos<=min(h, nLen-order); pos++) {
							m_pModel->FindFeatures(aFeats, pSeq, nLen, pos, order);
						}
					}

					//ͳ��ÿ���������ִ��������ڷ��ص�aFeat�п��ܻ����ظ��ģ������Ҫ����
					bool bFound;
					wbLHash<int, int> aHash(aFeats.GetNum());
					for (int i=0; i<aFeats.GetNum(); i++)
						*aHash.Insert(aFeats[i], bFound) += 1;
					

					int *pCount;
					int nFeat;
					wbLHashIter<int, int> iter(&aHash);
					while ( pCount = iter.Next(nFeat) ) {
						pConditionalFeatExp[nFeat] += pProb[x] * (*pCount);
					}

					if (x == nSave) {
						for (int i=0; i<aFeats.GetNum(); i++)
							pFeatNum[aFeats[i]]++;
					}
				}

				pSeq[h] = nSave; ///** �滻��ȥ

				for (int i=0; i<m_nParamNum; i++) {
					double d = pFeatNum[i] + pOtherFeatNum[i] - pConditionalFeatExp[i];
					m_pParallelGradient[omp_get_thread_num()][i] += d;
// 					if ( i== 0)
// 					{
// 						lout<<"fast = "<<pFeatNum[i] + pOtherFeatNum[i]<<" "<<pConditionalFeatExp[i]<<" "<<d<<endl;
// 					}
				}

				


// 				for (int i=0; i<m_nParamNum; i++) {
// 					int nAcceptTimesSaved = 0;
// 					double dExp = 0;
// 					for (int x=0; x<m_pModel->m_pVocab->nSize; x++) {
// 						pSeq[h] = x;
// 						int n = m_pModel->m_aFeatures[i]->nAccept(pSeq, nLen);
// 						dExp += n * pProb[x];
// 						if ( x==nSave )
// 							nAcceptTimesSaved = n;
// 					}
// 					pSeq[h] = nSave;
// 					double d = nAcceptTimesSaved - dExp;
// 					
// 					
// 					if ( i== 0)
// 					{
// 						lout<<"slow = "<<nAcceptTimesSaved<<" "<<dExp<<" "<<d<<endl;
// 					}
// 					//lout<<m_pParallelGradient[omp_get_thread_num()][i]<<" "<<d<<endl;
// 					m_pParallelGradient[omp_get_thread_num()][i] += d;
// 					//Pause();
// 
// 					
// 				}
// 

			}


			omp_set_lock(&precent_lock);
			titlePrecent();
			omp_unset_lock(&precent_lock);
		}


		for (int t=0; t<omp_get_max_threads(); t++) {
			for (int i=0; i<m_nParamNum; i++)
				pdGradient[i] += m_pParallelGradient[t][i];
		}
		


		for (int i=0; i<m_nParamNum; i++)
			pdGradient[i] = -pdGradient[i] / m_corpusTrain.m_nLine;

		omp_destroy_lock(&precent_lock);
		omp_destroy_lock(&file_lock);
		omp_destroy_lock(&lout_lock);

		return true;
	}
#endif //_OPENMP

	int MPLfunc::GetExtraValues(double *pdParams, double *pdValues)
	{
		if ( m_bFast )
			return 0;

		int nNum = MLfunc::GetExtraValues(pdParams, pdValues);

		pdValues[nNum++] = CaculatePseudoLogLikelihood(&m_corpusTrain);
		pdValues[nNum++] = CaculatePseudoLogLikelihood(&m_corpusTest);

		return nNum;
	}
}