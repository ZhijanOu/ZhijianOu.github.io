// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF models, including sampling algorithms.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFCDmodel.h"

namespace wbJRF
{
	

	void CDmodel::Sampling(VocabID *pSeq, int &nLen, int nTimes /* = 1 */)
	{
		for (int i=0; i<nTimes; i++) {
#ifdef _SamplingEx
			OneSamplingEx(pSeq, nLen);
#else
			OneSampling(pSeq, nLen);
#endif
		}
	}

	void CDmodel::OneSampling(VocabID *pSeq, int &nLen)
	{
		/*
		static variables, to count the acceptance frequence.
		*/
		static unsigned int s_total = 0;
		static unsigned int s_accept = 0;
#ifdef _OutAccFre
		static wbFile s_file("SampleAcceptance.fre", "wt");
#endif

		/// Local Jump
		int nNextLen = LineSampling(m_pLenJumpProb[nLen], m_nMaxLen+1);
		if (nNextLen > nLen) {
			LogP p1 = GetLogProb(pSeq, nLen);
			LogP g = g_Sampling(pSeq, nLen, nNextLen-nLen);
			LogP p2 = GetLogProb(pSeq, nNextLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p2-p1-g ); 

			if (Acceptable(accProb)) {
				nLen = nNextLen;
				s_accept++;
			}
		} else if (nNextLen < nLen) {
			LogP p1 = GetLogProb(pSeq, nLen);
			LogP g = g_LogProb(pSeq, nNextLen, nLen-nNextLen);
			LogP p2 = GetLogProb(pSeq, nNextLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p2+g-p1 ); 

			if (Acceptable(accProb)) {
				nLen = nNextLen;
				s_accept++;
			}
		}
		s_total++;
#ifdef _OutAccFre
		if (s_total % 1000 == 0)
			s_file.Print("%d\t%d\t%f\n", s_total, s_accept, 1.0*s_accept/s_total);
#endif

	
		/// Gibbs Sampling
		GibbsSample(pSeq, nLen);
	}
	LogP CDmodel::g_LogProb(VocabID *pSeq, int nLen, int nDim)
	{
		LogP totalLogP = 0;
		//wbArray<Prob> aProbs(m_pVocab->nSize); //����������ķֲ�

		for (int i=0; i<nDim; i++) 
		{
//			VocabID nSaveID = pSeq[nLen+i]; //�����λ��ֵ������������Ҫ���������
//
//			//��һά�ֲ�
// 			for (int x=0; x<m_pVocab->nSize; x++) {
// 				pSeq[nLen+i] = x;
// 				//aProbs[x] = LogP2Prob( GetLogProb(pSeq, nLen+i+1) );
// 				aProbs[x] = GetWeightSum(pSeq, nLen+i+1, nLen+i);
// 			}
// 			LogLineNormalize(aProbs, m_pVocab->nSize);
// 
// 			pSeq[nLen+i] = nSaveID;
// 
// 			LogP logProb = aProbs[nSaveID] ;
			LogP logProb = GibbsSample(pSeq, nLen+i+1, nLen+i, false);
			totalLogP += logProb;
		}

		return totalLogP;
	}
	LogP CDmodel::g_Sampling(VocabID *pSeq, int nLen, int nDim)
	{
		LogP totalLogP = 0;
//		wbArray<LogP> aProbs(m_pVocab->nSize); //����������ķֲ�

		for (int i=0; i<nDim; i++) 
		{
			//��������ֲ�
// 			for (int x=0; x<m_pVocab->nSize; x++) {
// 				pSeq[nLen+i] = x;
// 				//aProbs[x] = GetLogProb(pSeq, nLen+i+1);
// 				aProbs[x] = GetWeightSum(pSeq, nLen+i+1, nLen+i);
// 			}
// 
// 			LogLineNormalize(aProbs, m_pVocab->nSize);
// 			VocabID nSampledX = LogLineSampling(aProbs, m_pVocab->nSize);
// 			pSeq[nLen+i] = nSampledX; ///������ֵ
// 
// 			LogP logProb = aProbs[nSampledX];
			LogP logProb = GibbsSample(pSeq, nLen+i+1, nLen+i, true);
			totalLogP += logProb;
		}

		return totalLogP;
	}

	void CDmodel::OneSamplingEx(VocabID *pSeq, int &nLen)
	{
		/*
		static variables, to count the acceptance frequence.
		*/
		static unsigned int s_total = 0;
		static unsigned int s_accept = 0;
#ifdef _OutAccFre
		static wbFile s_file("SampleAcceptance.fre", "wt");
#endif

		/// Local Jump
		int nNextLen = LineSampling(m_pLenJumpProb[nLen], m_nMaxLen+1);
		if ( abs( nNextLen - nLen ) != 1 ) {
			// As this sampling onle supports form k to k+1/k-1
			lout_error("OneSamplingEx: Can only jump to +-1 !!");
		}
		if ( nNextLen > nLen ) {
			/// sample position 0 - nNextLen-1
			int sampled_pos = rand() % nNextLen;
			wbArray<VocabID> aNextSeq(nNextLen+1);
			g_SeqExtend(aNextSeq, pSeq, nLen, sampled_pos);

			LogP prob_marginal = g_MarginalProb(aNextSeq, nNextLen, sampled_pos);
			LogP prob_cur = GetLogProb(pSeq, nLen); 
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( prob_marginal-prob_cur ); 
			if (Acceptable(accProb)) {

				memcpy(pSeq, aNextSeq.GetBuffer(), sizeof(VocabID)*nNextLen);
				nLen = nNextLen;
				GibbsSample(pSeq, nLen, sampled_pos); //���²����λ�ý���һ�β���

				s_accept++;
			}
		} else if ( nNextLen < nLen ) {
			/// sample position 0 - nLen-1
			int sampled_pos = rand() % nLen;
			wbArray<VocabID> aNextSeq(nNextLen+1);
			g_SeqCut(aNextSeq, pSeq, nLen, sampled_pos);

			LogP prob_next = GetLogProb(aNextSeq, nNextLen);
			LogP prob_marginal = g_MarginalProb(pSeq, nLen, sampled_pos);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( prob_next-prob_marginal ); 
			if (Acceptable(accProb)) {
				memcpy(pSeq, aNextSeq.GetBuffer(), sizeof(VocabID)*nNextLen);
				nLen = nNextLen;
				s_accept++;
			}
		}
		s_total++;
		
#ifdef _OutAccFre
		if (s_total % 1000 == 0)
			s_file.Print("%d\t%d\t%f\n", s_total, s_accept, 1.0*s_accept/s_total);
#endif

		/// Gibbs Sampling
		GibbsSample(pSeq, nLen);
		

	}

	void CDmodel::OneSamplingEx2(VocabID *pSeq, int &nLen)
	{
		/*
		static variables, to count the acceptance frequence.
		*/
		static unsigned int s_total = 0;
		static unsigned int s_accept = 0;
#ifdef _OutAccFre
		static wbFile s_file("SampleAcceptance.fre", "wt");
#endif

		/// Local Jump
		int nNextLen = LineSampling(m_pLenJumpProb[nLen], m_nMaxLen+1);
		if ( abs( nNextLen - nLen ) != 1 ) {
			// As this sampling onle supports form k to k+1/k-1
			lout_error("OneSamplingEx: Can only jump to +-1 !!");
		}

		if ( nNextLen > nLen ) {
			/// sample position 0 - nNextLen-1
			int sampled_pos = rand() % nNextLen;
			wbArray<VocabID> aNextSeq(nNextLen+1);
			g_SeqExtend(aNextSeq, pSeq, nLen, sampled_pos);
			LogP g = GibbsSample(aNextSeq, nNextLen, sampled_pos);
			LogP p_next = GetLogProb(aNextSeq, nNextLen);
			LogP p_cur = GetLogProb(pSeq, nLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p_next-p_cur-g ); 
			if (Acceptable(accProb)) {
				memcpy(pSeq, aNextSeq.GetBuffer(), sizeof(VocabID)*nNextLen);
				nLen = nNextLen;
				s_accept++;
			}
		} else if ( nNextLen < nLen ) {
			/// sample position 0 - nLen-1
			int sampled_pos = rand() % nLen;
			wbArray<VocabID> aNextSeq(nNextLen+1);
			g_SeqCut(aNextSeq, pSeq, nLen, sampled_pos);
			LogP g = GibbsSample(pSeq, nLen, sampled_pos, false);
			LogP p_next = GetLogProb(aNextSeq, nNextLen);
			LogP p_cur = GetLogProb(pSeq, nLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p_next+g-p_cur ); 
			if (Acceptable(accProb)) {
				memcpy(pSeq, aNextSeq.GetBuffer(), sizeof(VocabID)*nNextLen);
				nLen = nNextLen;
				s_accept++;
			}
		}
		GibbsSample(pSeq, nLen);

		s_total++;
#ifdef _OutAccFre
		if (s_total % 1000 == 0)
			s_file.Print("%d\t%d\t%f\n", s_total, s_accept, 1.0*s_accept/s_total);
#endif	
	}

	void CDmodel::g_SeqExtend(VocabID *pNew, VocabID *pSeq, int nLen, int new_pos, VocabID new_value/* =0 */)
	{
		for (int i=0; i<new_pos; i++)
			pNew[i] = pSeq[i];
		pNew[new_pos] = new_value;
		for (int i=new_pos+1; i<nLen+1; i++)
			pNew[i] = pSeq[i-1];
	}
	void CDmodel::g_SeqCut(VocabID *pNew, VocabID *pSeq, int nLen, int pos)
	{
		for (int i=0; i<pos; i++)
			pNew[i] = pSeq[i];
		for (int i=pos+1; i<nLen; i++)
			pNew[i-1] = pSeq[i];
	}
	LogP CDmodel::g_MarginalProb(VocabID *pSeq, int nLen, int pos)
	{
		VocabID nSave = pSeq[pos];
		LogP logSum = Logp_Zero;
		for (int x=0; x<m_pVocab->nSize; x++) {
			pSeq[pos] = x;
			LogP lprob = GetLogProb(pSeq, nLen);
			logSum = Log_Sum(logSum, lprob);
		}
		pSeq[pos] = nSave;
		return logSum;
	}
	LogP CDmodel::GibbsSample(VocabID *pSeq, int nLen, int pos, bool bSample )
	{
		wbArray<LogP> aProbs(m_pVocab->nSize); //����һά�ֲ�
		VocabID nSave = pSeq[pos]; //����
		for (int x=0; x<m_pVocab->nSize; x++) {
			pSeq[pos] = x;
			double d =  GetWeightSum(pSeq, nLen, pos);
			aProbs[x] =  d ;
		}
		LogLineNormalize(aProbs, m_pVocab->nSize);
		pSeq[pos] = nSave;  //��ԭ
		
		if (bSample) {
			int sx = LogLineSampling(aProbs, m_pVocab->nSize);
			pSeq[pos] = sx;
		}
		return aProbs[ pSeq[pos] ];
	}
	void CDmodel::GibbsSample(VocabID *pSeq, int nLen)
	{
		wbArray<Prob> aProbs(m_pVocab->nSize); //����һά�ֲ�
		wbArray<int> aPos(nLen+1); ///��¼������λ��
		for (int i=0; i<nLen; i++)
			aPos[i] = i;
		int nPos = (m_opt_samplePos>=0)? min(m_opt_samplePos, nLen): nLen;

		if (nPos < nLen) { //���������λ��
			RandomPos(aPos, nLen, nPos );
		} 

		//����Ҫ��λ�ý���һ��GibbsSampling
		for (int n=0; n<nPos; n++) {
			int h = aPos[n];
			for (int x=0; x<m_pVocab->nSize; x++) {
				pSeq[h] = x;
				double d =  GetWeightSum(pSeq, nLen, h);
				aProbs[x] =  d ;
			}
			LogLineNormalize(aProbs, m_pVocab->nSize);
			int sx = LogLineSampling(aProbs, m_pVocab->nSize);
			pSeq[h] = sx;
		}
	}

// 	LogP CDmodel::GetWeightSum(VocabID *pSeq, int nLen, int nPos)
// 	{
// 		//������ngram���������ֻ��Ҫ����h����������
// 		LogP logprob = 0;
// 		wbArray<int> aFeatrues;
// 
// 		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
// 			for (int h=max(nPos-nOrder+1,0); h<=min(nPos,nLen-nOrder); h++) {
// 
// 				FindFeatures(aFeatrues, pSeq, nLen, h, nOrder);
// 				for (int i=0; i<aFeatrues.GetNum(); i++) {
// 					logprob += m_aValues[aFeatrues[i]];
// 				}
// 
// 			}
// 		}
// 		return logprob;
// 	}

	void CDmodel::ExactNormalization()
	{
		Normalization(true);
	}
	void CDmodel::ApproxNormalization(int nSampleNum /* = 10000 */, int nHotNum /* = 3000 */, int nStep /*=1*/)
	{
		wbFile file("CD_approx_norm.dbg", "wt");

		wbArray<int> aLenNum(m_nMaxLen+10); /// ͳ��ÿ�����ȳ��ֵĸ���
		aLenNum.Fill(0);

		LogP q = Logp_Zero;
		for (VocabID x=0; x<m_pVocab->nSize; x++)
			q = Log_Sum(q, GetLogProb(&x, 1, false)); ///���㳤��Ϊ1�����еĸ���

		//����
		VocabID *pSeq = new VocabID[m_nMaxLen+10];
		int nLen = 1;
		pSeq[0] = 0;

		lout<<"Hot..."<<endl;
		titlePrecent(0, true, nHotNum, "hot");
		for (int i=0; i<nHotNum; i++) {
			Sampling(pSeq, nLen, 1);
			titlePrecent(i+1);
		}

		lout<<"Sampling..."<<endl;
		int n = 0;
		titlePrecent(0, true, nSampleNum, "Sampling");
		for (int i=0; i<nSampleNum; i++) {
			Sampling(pSeq, nLen, nStep);

			aLenNum[nLen]++;
			if (nLen == 1)
				n++;

			if (n>0 && i%100==0) { //ÿ100����ӡһ��
				file.Print("%d\t%lf\t", n, q + log((double)nSampleNum) - log((double)n));
				for (int l=0; l<nLen; l++)
					file.Print("%c", pSeq[l]+'a');
				file.Print("\n");
			}

			titlePrecent(i+1);
		}

		//����Z
		m_logNormalizationFactor = q + log((double)nSampleNum) - log((double)n);
		lout<<"Observed = "<<n<<endl;
		lout<<"total = "<<nSampleNum<<endl;
		lout<<"frequence = "<<1.0*n/nSampleNum<<endl;
		lout<<"unnormalized Q = "<<q<<endl;
		lout_variable(m_logNormalizationFactor);

		lout<<"length number: "<<endl;
		for (int i=1; i<=m_nMaxLen; i++)
			lout<<"["<<i<<"]\t"<<aLenNum[i]<<endl;

		SAFE_DELETE_ARRAY(pSeq);
	}
}