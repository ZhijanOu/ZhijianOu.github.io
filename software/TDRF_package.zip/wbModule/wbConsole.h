// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// control the CMD window
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#ifndef _WB_CONSOLE_H_
#define _WB_CONSOLE_H_

#include <windows.h>

#define TS_SENTENCE_LEN	32*1024 // 5000

#define CHAR_SPACE ' '
#define CHAR_FRAME_VERTICAL '|'
#define CHAR_SPACE_HORIZONTAL '-'

class wbSmallRect: public SMALL_RECT
{
public:
	wbSmallRect();
	wbSmallRect(short l, short t, short r, short b);
	wbSmallRect(COORD coord, short width, short height);
	wbSmallRect(SMALL_RECT &rect);

	short Width() const {return Right-Left; }
	short Height() const {return Bottom-Top; }
	int Area() const {return Width()*Height();}
};

struct wbCell
{
	const char *pStr;
	unsigned short nLen;
	wbCell *pNext;
};

class wbStdOutBlock
{
public:
	HANDLE m_hStdOut;
	wbSmallRect m_rect;

	COORD m_cursor; //<���λ��>,��ǰ���λ��
	char *m_pBuffer;

	wbCell *m_pCellListHead;
	wbCell *m_pCellListTail;

	WORD m_wAttribute;
public:
	wbStdOutBlock(HANDLE h, wbSmallRect *rect);
	~wbStdOutBlock();

	void Printf(const char *format, ...);
	void Puts(const char *pStr);
	
	void FillAttribute();  //Fill֮��Ż���Ч��
	void FillChar(char c);
	void DisplayBuffer();

public:
	void PushLine(int nLineNum = 1); //ȷ��buffer�а���m_cursor�����У���nLineNum�пɹ�ʹ�á�
	char* BufferLocation(short row, short col = 0);
	bool StrProcess(const char *pStr);  //���ַ����ֶΣ�ʹ��ָ��ͳ��ȱ�ǣ��������ַ���\n \t������ȡ����

private: //CellList operations, like queue
	void CellListClean();
	void CellListIn(const char *pStr, unsigned short snLen);
	bool CellListOut(const char *&pStr, unsigned short &snLen);
};

const int cSTDOUT_ATTRIBUTES_NUM = 6;
const WORD cSTDOUT_ATTRIBUTE_ARRAY[cSTDOUT_ATTRIBUTES_NUM] = {
	BACKGROUND_GREEN | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
	BACKGROUND_BLUE | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
	BACKGROUND_BLUE | BACKGROUND_GREEN | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
	BACKGROUND_BLUE | BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
	
	BACKGROUND_RED | BACKGROUND_GREEN | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
	FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE
};

class wbStdOutMager
{
public:
	wbStdOutBlock **m_pStdOutBlock;
	int m_nNum;

	wbStdOutMager(int nRow, int nCol, int nRowWidth, int nColWidth, bool bMain = false); //�Ƿ��������߳�����
	~wbStdOutMager();
};

#endif
