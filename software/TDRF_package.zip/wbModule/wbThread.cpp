// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Thread class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.



#include "wbThread.h"

HANDLE wbThreadManager::hLoutFinishedEvent = NULL;

wbThreadManager::wbThreadManager(int p_nThreadNum, const char *p_flag/* ="" */)
{
	if (p_nThreadNum <= 0)
		return;

	m_nThreadNum = p_nThreadNum;
	strcpy_s(m_strFlag, TM_FLAG_LEN, p_flag);

	m_pThreadInfo = new wbThreadInfo[m_nThreadNum];
	for (int i=0; i<m_nThreadNum; i++)
	{
		m_pThreadInfo[i].nId = i;
		m_pThreadInfo[i].pTaskPack = NULL;
	}


	m_pTaskBuffer = new wbHeap<wbTaskPack*, int>(HEAPMODE_MINHEAP); //��С��
	m_nCurTaskId = 0;
	m_nTaskNum = 0;

	Printf_Init();
}

wbThreadManager::~wbThreadManager()
{
// 	SAFE_DELETE_ARRAY(m_pThreadInfo);
// 	SAFE_DELETE(m_pTaskBuffer);
	ReleaseThread();

	Printf_Release();
}

wbTaskPack *wbThreadManager::CreateTask()
{
	if (m_nTaskNum == 10)  ///���Ѿ�������10���������ֹ����������
		return NULL;
	return new wbTaskPack(m_nTaskNum++);
}
void wbThreadManager::FinishTask( wbTaskPack *&pTask )
{
	wbThreadManager::Printf( -1, "[task %d] finished!\n", pTask->nId );
}

bool wbThreadManager::StartThread()
{
	
	Reset();

	for (int i=0; i<m_nThreadNum; i++)
	{
		m_pThreadInfo[i].pTaskPack = NULL;
		m_pThreadInfo[i].nSeed = rand(); //��ʼ���������

		m_pThreadInfo[i].hTaskAllockEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			FALSE,  // initial state is nonsignaled
			NULL);  // unnamed object
		if (m_pThreadInfo[i].hTaskAllockEvent == NULL)
		{
			lout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phTaskAllockEvent"<<endl;
			return false;
		}

		m_pThreadInfo[i].hTaskFinishEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			TRUE,  // *******initial state is signaled******************
			NULL);  // unnamed object
		if (m_pThreadInfo[i].hTaskFinishEvent == NULL)
		{
			lout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phTaskFinishEvent"<<endl;
			return false;
		}

		m_pThreadInfo[i].hThreadExitEvent = CreateEvent( 
			NULL,   // default security attributes
			FALSE,  // auto-reset event object
			FALSE,  // initial state is nonsignaled
			NULL);  // unnamed object
		if (m_pThreadInfo[i].hThreadExitEvent == NULL)
		{
			lout<<"CreateEvent failed m_pThreadInfo["<<i<<"].phThreadExitEvent"<<endl;
			return false;
		}
	}

	//Create Thread...
	for (int i=0; i<m_nThreadNum; i++)
	{
		DWORD dwThreadID;

		m_pThreadInfo[i].hThread = CreateThread( 
			NULL,         // default security attributes
			0,            // default stack size
			(LPTHREAD_START_ROUTINE)wbThreadManager::ThreadProc, 
			m_pThreadInfo+i,     // thread function arguments
			0,            // default creation flags
			&dwThreadID); // receive thread identifier

		if (m_pThreadInfo[i].hThread == NULL)
		{
			lout<<"CreateThread failed m_pThreadInfo["<<i<<"].phThread"<<endl;
			return false;
		}
	}

	return true;
}

bool wbThreadManager::Run()
{
	HANDLE *phTaskFinishEvent = new HANDLE[m_nThreadNum];
	for (int i=0; i<m_nThreadNum; i++)
		phTaskFinishEvent[i] = m_pThreadInfo[i].hTaskFinishEvent;

	
	while (1)
	{
		wbTaskPack *pTask = CreateTask(); //��������
		if (!pTask)
			break;

		DWORD dwWaitResult = WaitForMultipleObjects( 
			m_nThreadNum, // number of objects in array
			phTaskFinishEvent,     // array of objects
			FALSE,       // wait for any object
			INFINITE);   // indefinite wait

		if ( dwWaitResult >= WAIT_OBJECT_0 && dwWaitResult < WAIT_OBJECT_0+m_nThreadNum)
		{
			//��Ϊδ���״̬,Ϊ�������
			ResetEvent(m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].hTaskFinishEvent);

			//���������������뻺��
			BufferTask( m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].pTaskPack );

			//�����µ�����
			m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].pTaskPack = pTask;
			if ( !SetEvent(m_pThreadInfo[dwWaitResult-WAIT_OBJECT_0].hTaskAllockEvent) )
			{
				wbThreadManager::Printf(-1, "SetEvent for m_phTaskAllocEvent[%d] Failed!\n", dwWaitResult-WAIT_OBJECT_0);
				return false;
			}
		}
		else
		{
			wbThreadManager::Printf(-1, "WaitForMultipleObjects[FALSE] Failed!\n");
			return false;
		}
	}

	DWORD dwWaitResult = WaitForMultipleObjects( 
		m_nThreadNum, // number of objects in array
		phTaskFinishEvent,     // array of objects
		TRUE,       // wait all object 
		INFINITE);   // indefinite wait

	if (dwWaitResult == WAIT_OBJECT_0)
	{
		
		for (int i=0; i<m_nThreadNum; i++)
		{
			BufferTask( m_pThreadInfo[i].pTaskPack );
			m_pThreadInfo[i].pTaskPack = NULL;

			//ֻ�趨Ϊ��������������˳��߳�
			if ( !SetEvent(m_pThreadInfo[i].hTaskFinishEvent) )
			{
				wbThreadManager::Printf(-1, "SetEvent for m_phTaskAllocEvent[%d] Failed!\n", i);
				return false;
			}
		}
	}
	else
	{
		wbThreadManager::Printf(-1, "WaitForMultipleObjects[FALSE] Failed!\n");
		return false;
	}

	
	delete [] phTaskFinishEvent;
	phTaskFinishEvent = NULL;

	return true;

}

bool wbThreadManager::EndThread()
{
	HANDLE *phTaskFinishEvent = new HANDLE[m_nThreadNum];
	for (int i=0; i<m_nThreadNum; i++)
		phTaskFinishEvent[i] = m_pThreadInfo[i].hTaskFinishEvent;

	DWORD dwWaitResult = WaitForMultipleObjects( 
		m_nThreadNum, // number of objects in array
		phTaskFinishEvent,     // array of objects
		TRUE,       // wait all object 
		INFINITE);   // indefinite wait

	if (dwWaitResult == WAIT_OBJECT_0)
	{
		for (int i=0; i<m_nThreadNum; i++)
		{
			BufferTask( m_pThreadInfo[i].pTaskPack );

			if ( !SetEvent(m_pThreadInfo[i].hThreadExitEvent) )
			{
				wbThreadManager::Printf(-1, "SetEvent for m_phTaskAllocEvent[%d] Failed!\n", i);
				return false;
			}
		}
	}
	else
	{
		wbThreadManager::Printf(-1, "WaitForMultipleObjects[FALSE] Failed!\n");
		return false;
	}


	delete [] phTaskFinishEvent;
	phTaskFinishEvent = NULL;
	
	//�ر����е�handle
	for (int i=0; i<m_nThreadNum; i++) {
		CloseHandle( m_pThreadInfo[i].hTaskAllockEvent );
		CloseHandle( m_pThreadInfo[i].hTaskFinishEvent );
		CloseHandle( m_pThreadInfo[i].hThreadExitEvent );
		CloseHandle( m_pThreadInfo[i].hThread );
	}

	return true;
}

void wbThreadManager::ReleaseThread()
{
	SAFE_DELETE_ARRAY(m_pThreadInfo);
	SAFE_DELETE(m_pTaskBuffer);
}

bool wbThreadManager::BufferTask( wbTaskPack *pTask )
{
	if (!pTask)
		return false;

#ifdef _wbTHREAD_PRINT_INFO
	wbThreadManager::Printf(-1, "Buffer Task %d\n", pTask->nId);
#endif // _wbTHREAD_PRINT_INFO

	m_pTaskBuffer->Insert(pTask, pTask->nId);

	wbTaskPack *pTopTask;
	int nTopId;
	while (m_pTaskBuffer->GetTop( pTopTask, nTopId ))
	{
		if ( nTopId == m_nCurTaskId ) {
			m_pTaskBuffer->OutTop( pTopTask, nTopId ); //ɾ���Ѷ�
			FinishTask( pTopTask );
			SAFE_DELETE(pTopTask);
			m_nCurTaskId++;
		} else {
			break;
		}
	}

	return true;
}

DWORD WINAPI wbThreadManager::ThreadProc(LPVOID lpThreadParameter)
{
	wbThreadInfo *pThreadInfo = (wbThreadInfo*)lpThreadParameter;
	srand(pThreadInfo->nSeed); ///��ʼ���������

	HANDLE hEvent[2];
	hEvent[0] = pThreadInfo->hTaskAllockEvent;
	hEvent[1] = pThreadInfo->hThreadExitEvent;
	while(true)
	{
		DWORD dwWaitResult = WaitForMultipleObjects(
			2,
			hEvent,
			FALSE,
			INFINITE);
		switch(dwWaitResult)
		{
		case WAIT_OBJECT_0 + 0:
#ifdef _wbTHREAD_PRINT_INFO
			wbThreadManager::Printf(pThreadInfo->nId, "[Task %d] process...\n", pThreadInfo->pTaskPack->nId);
#endif
			if (pThreadInfo->pTaskPack != NULL)
				pThreadInfo->pTaskPack->Process(pThreadInfo->nId);
			if ( !SetEvent(pThreadInfo->hTaskFinishEvent) )
			{
				wbThreadManager::Printf(pThreadInfo->nId, "SetEvent Failed\n");
				return 0;
			}
			break;
		case WAIT_OBJECT_0 + 1:
#ifdef _wbTHREAD_PRINT_INFO
			wbThreadManager::Printf(pThreadInfo->nId, "Exit\n");
#endif
			return 0;
		default:
			wbThreadManager::Printf(pThreadInfo->nId, "WaitForMultipleObjects Failed\n");
			ExitThread(0);
		}
	}

	return 0;
}

void wbThreadManager::Printf_Init()
{
	if (hLoutFinishedEvent)
		return;

	hLoutFinishedEvent = CreateEvent( 
		NULL,   // default security attributes
		FALSE,  // auto-reset event object
		TRUE,  // initial state is nonsignaled
		NULL);  // unnamed object
	if (!hLoutFinishedEvent) {
		lout_error("CreateEvent in Printf_Init Failed");
	}
}
void wbThreadManager::Printf_Release()
{
	CloseHandle( hLoutFinishedEvent );
	hLoutFinishedEvent = NULL;
}
void wbThreadManager::Print_Beg()
{
	WaitForSingleObject( 
		hLoutFinishedEvent,     // array of objects
		INFINITE);   // indefinite wait
}
void wbThreadManager::Print_End()
{
	lout_assert( SetEvent(hLoutFinishedEvent) );
}
void wbThreadManager::Printf(int nThreadId, const char* pFormat, ...)
{
	char strBuffer[GS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,pFormat);

	if (nThreadId >= 0)
		sprintf(strBuffer, "[Thread %d] ", nThreadId);
	else
		sprintf(strBuffer, "[Main]");
	_vsnprintf(strBuffer+strlen(strBuffer),GS_SENTENCE_LEN,pFormat,vaParams);


	Print_Beg();
	lout<<strBuffer;
	Print_End();
}
