// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Joint SA estimation
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.



/** 
 * \file
 * \author wangbin
 * \date 2014-03-17
 * \brief JRFģ��, SAѵ���㷨
 */
#pragma once
#include "wbJRFCD.h"
#include "wbJRFClassModel.h"
using namespace wbJRF;
#include "wbThread.h"
//#include "wbTrie.h"

namespace wbJRF
{
	/** 
	 * \class
	 * \brief ��ֹ�о���
	 */
	class ValueDet
	{
	public:
		wbArray<double> m_aValueBuf;  ///< ����value
		int m_nValueWidth;
		int m_nValueStep; ///< ����
		int m_nValueCur;
		wbArray<double> m_aDiffBuf; ///< ����ƽ����ı仯��
		int m_nDiffWidth;
		int m_nDiffCur;

		int m_t; ///< �����ǰ�ܸ���
		double m_dPreAvgValue; ///< ��һ��ƽ��value
		double m_dCurAvgValue; ///< ��ǰƽ��value
		int m_nSignSum; ///< ���浱ǰ�ķ��ź�
	public:
		ValueDet(int nValueWidth = 10, int nDiffWidth = 10)
		{
			Init(nValueWidth, nDiffWidth);
		}
		int AddValue(double dValue)
		{
			m_t++;
			
			m_aValueBuf[m_nValueCur] = dValue;
			m_nValueCur = (m_nValueCur+1)%m_nValueWidth;

			if ( m_t % m_nValueStep == 0 )  //������Ϊ10
			{
				int n = min(m_t, m_nValueWidth);
				m_dCurAvgValue = 0; //��ǰ��ֵ
				for (int i=0; i<n; i++)
					m_dCurAvgValue += m_aValueBuf[i];
				m_dCurAvgValue /= n;
			
			

				if ( m_t > m_nValueStep ) {
					//����diff
					double dDiff = m_dPreAvgValue - m_dCurAvgValue; //�½���
					m_aDiffBuf[m_nDiffCur] = (dDiff>0)? 1: -1;
					m_nDiffCur = (m_nDiffCur+1) % m_nDiffWidth;

					//������ź�
					m_nSignSum = 0;
					for (int i=0; i<m_nDiffWidth; i++)
						m_nSignSum += m_aDiffBuf[i];
				}

				m_dPreAvgValue = m_dCurAvgValue;
			}

			return m_nSignSum;
		}
		void Init(int nValueWidth, int nDiffWidth)
		{
			m_aValueBuf.SetNum(nValueWidth);
			m_aValueBuf.Fill(0);
			m_nValueWidth = nValueWidth;
			m_nValueStep = 10;
			m_nValueCur = 0;

			m_aDiffBuf.SetNum(nDiffWidth);
			m_aDiffBuf.Fill(0);
			m_nDiffWidth = nDiffWidth;
			m_nDiffCur = 0;

			m_t = 0;
			m_dPreAvgValue = 0;
			m_nSignSum = 0;

			lout<<"[ValueDet] ";
			lout_variable(nValueWidth);
			lout<<"[ValueDet] ";
			lout_variable(nDiffWidth);
		}
		bool bTerminate(double rate = 0)
		{
			if ( m_t /m_nValueStep-1 < m_nDiffWidth )
				return false;
			return m_nSignSum<=rate * m_nDiffWidth;
		}
	};

	/**
	 * \class
	 * \brief ʹ�ö��߳�������ÿ��������ͳ����������
	 */
	class SATaskPack : public wbTaskPack
	{
	public:
		VocabID *m_pSeqBuf;  ///< ��������buff
		int *m_pnSeqLen; ///< �������г���(����Ҫ���س���ֵ�������ָ��)
		

		int m_nSampleNum; ///< ��Ҫ���������
		short m_nSampleStep; ///< ����step

		int *m_pFeatCount; ///< �������ִ���
		int *m_pLenCount; ///< ���ȼ���

		wbTrie<int, int> *m_pLenFeatTrie; ///< ��¼��ͬ���ȵ���������

#ifdef Hessian
		//wbDArray<int> *m_pDArrayCount; ///< ��¼ÿ�����ȵ�ÿ�������ĳ��ִ���
		int *m_pFeatSquareCount; ///< ��¼ÿ������ƽ���ĸ���
#endif
#ifdef _LBFGS
		const double *m_pVectorS; ///< ����������� s
		double *m_pWeightedFeatCount; ///< p[ F * F^T * s ] 
		double *m_pLenWeightedCount; ///< p_j[ F^T * s ]
#endif
#ifdef _Class
		wbTrie<int, int> *m_pClassCount; ///< ��¼��ͬ����ÿ��λ�ô���Class���ִ���
#endif


		CDmodel *m_pModel; ///< ģ��

		SATaskPack(int nId):wbTaskPack(nId) { m_nSampleStep = 1; };
		virtual bool Process(int nThreadId);
	};

	/**
	 * \class
	 * \brief ���̹�����
	 */
	class SAThreadMager : public wbThreadManager
	{
	public:
		CDmodel *m_pModel;  ///< ģ��ָ��
		int m_nMinBatch;	///< ��Ҫ��������Ŀ
		int m_nSampleStep; ///< sample step

		int **m_ppFeatCount; ///< ÿ���̵߳���������
		int **m_ppLenCount; ///< ÿ���̵߳ĳ��ȼ���
		wbTrie<int,int> *m_pLenFeatTries; ///< ÿ���̣߳���¼��ͬ���ȵ���������
		
#ifdef Hessian
		//wbDArray<int> **m_ppLenFeatCount; ///< ÿ���̣߳���¼��ͬ���ȵ���������
		int **m_ppFeatSquareCount; ///< ÿ���̣߳���¼ÿ������ƽ���ĸ�����Ϊ���� p[f_k^2]
#endif
#ifdef _LBFGS
		const double *m_pVectorS; ///< ��������s
		double **m_ppWeightedFeatCount; ///< ÿ���̣߳���¼ p[ F * F^T * s ] 
		double **m_ppLenWeightCount; ///< ÿ���̣߳���¼p_j[F^T * s]
#endif
#ifdef _Class
		wbTrie<int,int> *m_pClassCount; ///< ÿ���̣߳���¼��ͬλ�ô�class�ֲ�
#endif

		VocabID **m_ppSeqBuf; ///< ÿ���̵߳�����buf
		int *m_pSeqLen; ///< ÿ���̵߳����г���

		int *m_pSampleNum; ///< ÿ��������Ҫ�ɼ���������
		//int m_nCurTask; ///< ��ǰ����

		SAThreadMager(int nThreadNum, CDmodel *pMode, int nMinBatch, int nSampleStep = 1): wbThreadManager(nThreadNum)
		{
			m_pModel = pMode;
			m_nMinBatch = nMinBatch;
			m_nSampleStep = nSampleStep;

			//���ٿռ�
			SAFE_NEW_DARRAY(m_ppFeatCount, int, nThreadNum, m_pModel->m_nFeatNum);
			SAFE_NEW_DARRAY(m_ppLenCount, int, nThreadNum, m_pModel->m_nMaxLen+1);
			SAFE_NEW_DARRAY(m_ppSeqBuf, VocabID, nThreadNum, m_pModel->m_nMaxLen + 10);
			SAFE_NEW_ARRAY(m_pSeqLen, VocabID, nThreadNum);
			m_pLenFeatTries = new wbTrie<int, int>[nThreadNum];
			
#ifdef Hessian
// 			m_ppLenFeatCount = new wbDArray<int> *[nThreadNum];
// 			for (int i=0; i<nThreadNum; i++)
// 				m_ppLenFeatCount[i] = new wbDArray<int>(m_pModel->m_nMaxLen+1, m_pModel->m_nFeatNum);
			SAFE_NEW_DARRAY(m_ppFeatSquareCount, int, nThreadNum, m_pModel->m_nFeatNum);
#endif
#ifdef _LBFGS
			SAFE_NEW_DARRAY(m_ppWeightedFeatCount, double, nThreadNum, m_pModel->m_nFeatNum);
			SAFE_NEW_DARRAY(m_ppLenWeightCount, double, nThreadNum, m_pModel->m_nMaxLen+1);
			m_pVectorS = NULL;
#endif
#ifdef _Class
			m_pClassCount = new wbTrie<int,int>[nThreadNum];
#endif

			
			//m_nCurTask = 0;
			SAFE_NEW_ARRAY(m_pSampleNum, VocabID, nThreadNum);
			SetMinBatch(nMinBatch);

			//��ʼ����������
			for (int i=0; i<nThreadNum; i++)
			{
				int nLen = LineSampling(m_pModel->m_aLenProb, m_pModel->m_nMaxLen+1);
				lout_assert(nLen>0);
				double dProb = m_pModel->m_aLenProb[nLen];
				lout<<"[InitSequence] len="<<nLen<<" prob="<<dProb<<endl;
				m_pSeqLen[i] = nLen;
				memset(m_ppSeqBuf[i], 0, sizeof(m_ppSeqBuf[i][0])*nLen);
			}
// 			wbHeap<int, double> heap(HEAPMODE_MAXHEAP); ///< Ϊ���ȷֲ������ҵ�����ܳ��ֵļ�������
// 			for (int i=1; i<=m_pModel->m_nMaxLen; i++)
// 				heap.Insert(i, m_pModel->m_aLenProb[i]);
// 			for (int i=0; i<nThreadNum; i++) {
// 				int nLen;
// 				double dProb;
// 				heap.OutTop(nLen, dProb);
// 				lout<<"[InitSequence] len="<<nLen<<" prob="<<dProb<<endl;
// 				m_pSeqLen[i] = nLen;
// 				memset(m_ppSeqBuf[i], 0, sizeof(m_ppSeqBuf[i][0])*nLen);
// 			}
		}
		~SAThreadMager()
		{
			SAFE_DELETE_DARRAY(m_ppFeatCount, m_nThreadNum);
			SAFE_DELETE_DARRAY(m_ppLenCount, m_nThreadNum);
			SAFE_DELETE_DARRAY(m_ppSeqBuf, m_nThreadNum);

			SAFE_DELETE_ARRAY(m_pSeqLen);
			SAFE_DELETE_ARRAY(m_pSampleNum);
			SAFE_DELETE_ARRAY(m_pLenFeatTries);

#ifdef Hessian
// 			for (int i=0; i<m_nTaskNum; i++)
// 				SAFE_DELETE(m_ppLenFeatCount[i]);
// 			SAFE_DELETE_ARRAY(m_ppLenFeatCount);
			SAFE_DELETE_DARRAY(m_ppFeatSquareCount, m_nThreadNum);
#endif
#ifdef _LBFGS
			SAFE_DELETE_DARRAY(m_ppWeightedFeatCount, m_nThreadNum);
			SAFE_DELETE_DARRAY(m_ppLenWeightCount, m_nThreadNum);
#endif
#ifdef _Class
			SAFE_DELETE_ARRAY(m_pClassCount);
#endif
		}
		void Save(wbFile &file);
		void Load(wbFile &file);
		/// ͳ������ÿ���̵߳Ľ��
		void GetResult(double *pPnfi, wbDArray<double> *pLenFeatExp = NULL); 
		/// ͳ�Ƴ��ȷֲ�
		void GetResult_lenProb(double *pLenProbs);
		/// ���ò�������
		void SetMinBatch(int n)
		{
			m_nMinBatch = n;

			memset(m_pSampleNum, 0, sizeof(m_pSampleNum[0])*m_nThreadNum);

			for (int i=0; i<m_nMinBatch; i++)
				m_pSampleNum[i % m_nThreadNum]++;
		}
#ifdef Hessian
		/// ͳ�����Ϻ�Hessian������صĽ��
		/* pFeatSquareExp ���� p[f_k^2] ,  pLenFeatExp ���� p_j[f_k] */
		void GetResult_Hessian(double *pFeatSquareExp = NULL, wbDArray<double> *pLenFeatExp = NULL);
		/// ͳ�����Ϻ�Hessian������صĽ��
		/* pFeatSquareExp ���� p[f_k^2] ,  pLenFeatExp ���� p_j[f_k] */
		void GetResult_Hessian( double *pFeatSquareExp = NULL, wbTrie<int, double> *pLenFeatExp = NULL );
#endif
#ifdef _LBFGS
		void GetResult_LBFGS(double *pWeightedFeatExp = NULL, double *pLenWeightExp = NULL, wbTrie<int, double> *pLenFeatExp = NULL);
#endif
#ifdef _Class
		/// ͳ��Class�ֲ�
		void GetClassDistribution(wbDArray<wbArray<double>*> &aClassProbs);
#endif
		virtual wbTaskPack* CreateTask();
		virtual void FinishTask( wbTaskPack *&pTask ) {
			//wbThreadManager::Printf( -1, "[task %d] finished!\n", pTask->nId );
			delete (SATaskPack*)pTask; //����������ͷ��ڴ�
			pTask = NULL;
		};
	};

	/** 
	 * \class
	 * \brief SA�����㷨
	 */
	class SA : public wbFunc
	{
	public:
		double *m_pPefi; ///< ��¼ÿ�������ľ����ֵp~[f_i]
		double *m_pPnfi; ///< ����ÿ�μ����ݶ�ʱ��pn[fi]
		//wbDArray<double> *m_pLenFeatExp; ///< ����ÿ�����ȵĲ�ͬ����������

		wbArray<LogP> m_aLogFeaVar; ///< ����ÿ�������ı�׼�� �Ķ���

#ifdef Hessian
		wbArray<double> m_aFeatSquareExp; ///< ��������ƽ�������� p[f_k^2] 
		wbArray<double> m_aHessianDiag; ///< ����hession�Խ�Ԫ��
#endif
#ifdef _Class
		wbDArray<wbArray<double>*> m_aClassProb; ///< ����Class����
#endif

		//��������
		Corpus m_corpusTrain;
		Corpus m_corpusValid;
		Corpus m_corpusTest;
		int m_nSeqMaxLen;		///< ������������󳤶�
		int m_nSeqNum;			///< ѵ�����Ͼ�����
		
		
		wbArray<int> m_aLenCount; ///< ÿ�����ȵĸ���
		wbArray<double> m_aSampleLenProb; ///< �����ĳ��ȷֲ�
		wbArray<double> m_aTurLenProb; ///< ѵ�����еĳ��ȷֲ�

		CDmodel *m_pModel; ///< ģ��

		bool m_bFastIter;  ///< �Ƿ���п��ٵ�����������ʵ��ģ�ͣ���ȥ����Ҫ�Ķ������

		VocabID *m_pSeqBuf; ///< ���浱ǰ�Ĳ�������
		int m_nSeqLen; ///< ���浱ǰ�������г���

		int m_nMinBatch; ///< min-batch
		int m_nSampleStep; ///< sample step;

		wbArray<int> m_aTrainRandSeq; ///<  wb 2015-1-12����ѵ����������Ľ��
		int m_nTrainRandBeg; ///< wb 2015-1-12����ǰ��Ҫ�Ӱ�����˳��ȡ�Ŀ�ʼλ��

		double m_dRegular; ///< L2����ϵ��
		double m_dL1Reg; ///< L1����ϵ��
		wbArray<short> m_aL1Orthant; ///< L1������Ҫ����һ������Լ��

		SAThreadMager *m_pThreadMger;


		wbFile *m_pFileBeakDownLL;
		
// 		int t; ///< �����������������ݶȵĴ���
// 		int t0; ///< ������²�����t0
// 		double pi_min; ///< ���ȸ��ʵ���Сֵ
// 		wbFile fileDbg; ///< ������ӡÿ�ε����Ĺ�һ��ϵ��
		

	public:
		SA(int nMinBatch, double dRegular = 0, bool bFast = true): 
		  m_nMinBatch(nMinBatch), m_dRegular(dRegular), m_bFastIter(bFast), 
			  m_pModel(NULL),
			m_pPefi(NULL), m_pPnfi(NULL),
			m_nSeqMaxLen(0), m_nSeqNum(0),
			m_pFileBeakDownLL(NULL)
		{
			m_pSeqBuf = NULL;
			m_nSeqLen = 0;

			m_pThreadMger = NULL;
		}
		~SA()
		{
			SAFE_DELETE_ARRAY(m_pPefi);
			SAFE_DELETE_ARRAY(m_pPnfi);
			//SAFE_DELETE(m_pLenFeatExp);
			SAFE_DELETE_ARRAY(m_pSeqBuf);


			m_pThreadMger->EndThread();
			SAFE_DELETE(m_pThreadMger);

			SAFE_DELETE(m_pFileBeakDownLL);

#ifdef _Class
			for (int len=1; len<=m_pModel->m_nMaxLen; len++)
				for (int h=0; h<len; h++) {
					SAFE_DELETE( m_aClassProb.Get(len, h) );
				}
#endif
		}

		
		//�ı�min-batch
		void SetMinBatch(int nMinBatch)
		{
			m_nMinBatch = nMinBatch;
			if (m_pThreadMger)
				m_pThreadMger->SetMinBatch(nMinBatch);
		}

		/// ѵ��׼������
		virtual void Prepare(int nThreadNum, CDmodel *pModel, const char *pathTrain, const char *pathValid, const char *pathTest = NULL, 
			const char *pathEmpirical = NULL, const char *pathVar=NULL, bool bUniformSample = false);

		/// ͳ��feature�ľ�������
		void Empirical(Corpus &corpus);
		void WriteEmpirical(wbFile &file);
		void ReadEmpirical(wbFile &file);
		/// ͳ�������ķ���,ʹ�� E{(x-E(x))^2}
		void EmpiricalVar( Corpus &corpus );
		///  ͳ���������ʹ�� E{x^2} - SUM_l \pi_l E_l{x}^2
		void EmpiricalVar_len( Corpus &corpus );
		void WriteFeatVar(wbFile &file);
		void ReadFeatVar(wbFile &file);
		/// ͳ��corpus��ÿ�������ĳ��ִ�������ÿ�����ȵĳ��ִ���
		void GetCorpusInfo(CorpusInfo &info, Corpus &corpus);

		/// ͳ�Ƶ�ǰblock�е�ѵ���������ľ�����������pPefi
		void GetCurEmpiricalExp(double *pPefi);
		
		/// ����ѵ��������֤���ϵ���Ȼֵ, pFile ���ӡÿ�����ȵ���Ȼֵ
		double CaculateLogLikelihood_perlen(Corpus *pCorpus, bool bNorm = true, double *pPPL=NULL, wbFile *pFile = NULL);
		double CaculateLogLikelihood(Corpus *pCorpus, bool bNorm = true, double *pPPL=NULL);

		/// ���㺯��ֵ
		virtual double GetValue(double *pdParams)
		{
 #ifdef Scheme1
 			return 0;
 #else
			if (pdParams)
				m_pModel->SetParams(pdParams, !m_bFastIter);

			return CaculateLogLikelihood(&m_corpusValid); //���ڴ�ʱ����ѵ�����ϵ���Ȼ�Ѿ�û��ʲô�ô��ˣ���˼�����Լ��ϵ���Ȼ����������ѧϰ����
#endif
		}

		virtual bool GetGradient(double *pdParams, double *pdGradient)
		{
			return GetGradient_t(pdParams, pdGradient);
		}

#ifdef Hessian
		/// ����hessian�Խ�Ԫ�ز���ӡ
		void MonitorHessian(  )
		{
			//��ӡÿ��������������������
// 			wbFile fileFeatExp("FeatExp.dbg", "wt");
// 			for (int i=0; i<m_pModel->m_nFeatNum; i++) {
// 				fileFeatExp.Print("%lf %lf\n", m_pPefi[i], m_pPnfi[i]);
// 			}

			//��ӡHessian����
			//wbFile file("Hessian.dbg", "wt");

			int nZeros = 0;
			int nZeros_lengthFeaturesExp = 0;
			int nZeros_featSquareExp = 0;
			//wbDArray<double> *pTempLenFeatExp = new wbDArray<double>(m_pModel->m_nMaxLen+1, m_pModel->m_nFeatNum);
			//m_pThreadMger->GetResult_Hessian(m_aFeatSquareExp, pTempLenFeatExp);
// 			
// 
// 
// 			for (int l = 0; l<m_pModel->m_nFeatNum; l++) {
// 				double dSum = 0;
// 				for (int j=1; j<=m_pModel->m_nMaxLen; j++) {
// 					double d = pTempLenFeatExp->Get(j, l);
// 					dSum += m_pModel->m_aLenProb[j] * d * d;
// 				}
// 
// 				double dHessian = m_aFeatSquareExp[l] - dSum;
// #ifdef _FeatNorm
// 				m_aHessianDiag[l] = dHessian / LogP2Prob(m_aLogFeaVar[l]*2);
// #else
// 				m_aHessianDiag[l] = dHessian;
// #endif
// 				//file.Print("%.10lf ", dHessian);
// 
// 				if (m_aFeatSquareExp[l] == 0)
// 					nZeros_featSquareExp++;
// 
// 				if (dSum==0)
// 					nZeros_lengthFeaturesExp++;
// 
// 				if (dHessian == 0)
// 					nZeros++;
// 			}
			
			wbTrie<int, double> *pTempLenFeatExp = new wbTrie<int, double>;
			pTempLenFeatExp->TrieHash.SetSize(m_pModel->m_nMaxLen+1);
			m_pThreadMger->GetResult_Hessian(m_aFeatSquareExp, pTempLenFeatExp);

			m_aHessianDiag.Copy(m_aFeatSquareExp);

#ifdef Scheme1  
			//��ÿ�����ȹ�һ���������
			//   p[f_i^2] - \sum_l \pi_l p_l[f_i]^2
			int idx[3];
			wbTrieIter2<int, double> iter(*pTempLenFeatExp, idx, 2);
			wbTrie<int, double> *pSub;
			while (pSub = iter.Next()) {
				double d = *pSub->GetData();
				double temp = m_pModel->m_aLenProb[ idx[0] ] * d * d;
				m_aHessianDiag[ idx[1] ] -= temp;
			}
#else
			// ��ȫ�ֹ�һ���������
			//    p[f_i^2] - p[f_i]^2
			for (int i=0; i<m_nParamNum; i++)
				m_aHessianDiag[i] -= m_pPnfi[i] * m_pPnfi[i];
#endif

#ifdef _FeatNorm
			for (int i=0; i<m_nParamNum; i++)
				m_aHessianDiag[i] /= LogP2Prob(m_aLogFeaVar[i]*2);
#endif

			if ( m_dRegular > 0 ) {
				for (int i=0; i<m_nParamNum; i++)
					m_aHessianDiag[i] += m_dRegular;
			}

			//file.Print("\n");

// 			lout_variable_precent(nZeros, m_pModel->m_nFeatNum);
// 			lout_variable_precent(nZeros_featSquareExp, m_pModel->m_nFeatNum);
// 			lout_variable_precent(nZeros_lengthFeaturesExp, m_pModel->m_nFeatNum);

// 			wbFile fileLenFeatExp("LenFeatExp.txt", "wt");
// 			for (int l = 0; l<m_pModel->m_nFeatNum; l++) {
// 				for (int j=1; j<=m_pModel->m_nMaxLen; j++) {
// 					double d = pTempLenFeatExp->Get(j, l);
// 					double d1 = m_pLenFeatExp->Get(j, l);
// 					fileLenFeatExp.Print("%lf\t%lf\n", d, d1);
// 					lout_assert(fabs(d-d1)<1e-10);
// 				}
// 			}

			SAFE_DELETE(pTempLenFeatExp);
		}
#endif

#ifdef _LBFGS
		void GetGradientDiff(double *pDiff)
		{
			wbArray<double> m_aWeightedFeatExp(m_nParamNum);
			wbArray<double> m_aLenWeightExp(m_pModel->m_nMaxLen+1);
			wbTrie<int, double> *pTempLenFeatExp = new wbTrie<int, double>;
			pTempLenFeatExp->TrieHash.SetSize(m_pModel->m_nMaxLen+1);
			m_pThreadMger->GetResult_LBFGS(m_aWeightedFeatExp, m_aLenWeightExp, pTempLenFeatExp);

			for (int i=0; i<m_nParamNum; i++)
				pDiff[i] = m_aWeightedFeatExp[i];

			int idx[3];
			wbTrieIter2<int, double> iter(*pTempLenFeatExp, idx, 2);
			wbTrie<int, double> *pSub;
			while (pSub = iter.Next()) {
				double d = *pSub->GetData();
				double temp = m_pModel->m_aLenProb[ idx[0] ] * d * m_aLenWeightExp[ idx[0] ];
				pDiff[ idx[1] ] -= temp;
			}
		}
#endif
#ifdef _Class
		void UpdateClassProb( double dgain )
		{
			int nMaxLen = m_pModel->m_nMaxLen;
			int nClassNum = m_pModel->m_pVocab->nClassIdTop;
			wbDArray<wbArray<double>*> aCurProbs(nMaxLen+1, nMaxLen+1);
			aCurProbs.Fill(NULL);

			m_pThreadMger->GetClassDistribution(aCurProbs);
			for (int len=1; len<=nMaxLen; len++) {
				for (int h=0; h<len; h++) {
					if ( aCurProbs.Get(len, h)==NULL  )
						continue;
					wbArray<double> *pProbs = m_aClassProb.Get(len, h);
					wbArray<double> *pCur = aCurProbs.Get(len, h);
					for ( int c=0; c<nClassNum; c++ ) {
						(*pProbs)[c] += dgain * ( (*pCur)[c] - (*pProbs)[c] );
					}
					LineNormalize(pProbs->GetBuffer(), nClassNum);
				}
			}
		}
#endif

		/// ʹ��L1���������Լ���Բ���ͶӰ
		void L1Projection(double *pdParams)
		{
			if ( pdParams && m_dL1Reg > 0 ) {
				int n=0;
				int nzero = 0;
				for (int i=0; i<m_nParamNum; i++) {
					short sig = 0;
					if (pdParams[i] > 0 ) sig = 1;
					else if ( pdParams[i] < 0 ) sig = -1;
					else sig = 0;

					if ( sig != m_aL1Orthant[i] ) {
						pdParams[i] = 0;
						n++;
					}

					if (pdParams[i] == 0) {
						nzero++;
					}
				}
				lout<<"[L1-Projection] times="<<n<<"("<<100.0*n/m_nParamNum<<"%)  ";
				lout<<"non-zero="<<m_nParamNum-nzero<<"("<<100.0*(m_nParamNum-nzero)/m_nParamNum<<"%)"<<endl;
			}
		}

		/// �����ݶȡ���thread
		bool GetGradient_t(double *pdParams, double *pdGradient)
		{
			if (pdParams) {
#ifdef NotEstimateZeta  //ʹ����ʵ��Zeta�������Ҫ��һ��
				m_pModel->SetParams(pdParams, true);
#else
				m_pModel->SetParams(pdParams, false);
#endif
			}

#ifdef _Class
			((ClassModel_len*)m_pModel)->m_pClassProb = &m_aClassProb;
#endif
			titlePrecent( 0, true, m_nMinBatch, "GetGradient:" );
			m_pThreadMger->Reset();
			//m_pThreadMger->StartThread();
			m_pThreadMger->Run();
			m_pThreadMger->GetResult(m_pPnfi/*, m_pLenFeatExp*/);

#ifdef Hessian
			MonitorHessian();
#endif

#ifdef _ClassModel
			ClassModel_len *pM = (ClassModel_len*)m_pModel;
			lout<<"[ClassModel] Jump["
				<<100.0*pM->m_nJumpAccept/pM->m_nJumpTotal<<"%] Class["
				<<100.0*pM->m_nClassAccept/pM->m_nClassTotal<<"%]"<<endl;
#endif

#ifdef Scheme1
			//�޸�Pn[fi]�ļ���
// 			memset(m_pPnfi, 0, sizeof(m_pPnfi[0])*m_nParamNum);
// 			for (int i=0; i<m_nParamNum; i++) {
// 				for (int j=1; j<=m_pModel->m_nMaxLen; j++) {
// 					//lout<<j<<" "<<m_pModel->m_aLenProb[j]<<endl;
// 					//ʹ����ʵ�ֲ���Ȩ������
// 					m_pPnfi[i] += /*m_pModel->m_aLenProb*/m_aTurLenProb[j] / m_aSampleLenProb[j] * m_pLenFeatExp->Get(j, i);
// 				}
// 			}
#endif


#ifdef _MinBatch
			/*
			min-batch on training set.
			otherwise using the empirical expectation on the whole training set. 
			*/
			//���㾭��ֲ�
			GetCurEmpiricalExp(m_pPefi);
#endif _MinBatch

			//�����ݶ�
			for (int i=0; i<m_nParamNum; i++) {
				pdGradient[i] =  m_pPnfi[i] - m_pPefi[i] ;
			}

			//������
			if (pdParams && m_dRegular > 0) {
				for (int i=0; i<m_nParamNum; i++)
					pdGradient[i] += m_dRegular * pdParams[i];
			}
			if ( pdParams && m_dL1Reg > 0 ) {
				double dSqrtM = sqrt((double)(m_corpusTrain.m_nLine));
				for (int i=0; i<m_nParamNum; i++) {
					
					double dPenalty = m_dL1Reg * LogP2Prob(m_aLogFeaVar[i]) / dSqrtM;

					if ( pdParams[i] > 0 )
						pdGradient[i] += dPenalty;
					else if ( pdParams[i] < 0 )
						pdGradient[i] -= dPenalty;
					else {// == 0
						double dPluss = pdGradient[i] + dPenalty;
						double dMinus = pdGradient[i] - dPenalty;
						if ( dMinus > 0 )
							pdGradient[i] = dMinus;
						else if ( dPluss < 0 )
							pdGradient[i] = dPluss;
						else
							pdGradient[i] = 0;
					}
				}

				//��������Լ��
				m_aL1Orthant.SetNum(m_nParamNum);
				for (int i=0; i<m_nParamNum; i++) {
					if ( pdParams[i] > 0 )
						m_aL1Orthant[i] = 1;
					else if ( pdParams[i] < 0 )
						m_aL1Orthant[i] = -1;
					else {
						if ( pdGradient[i] > 0 )
							m_aL1Orthant[i] = -1;
						else if ( pdGradient[i] < 0 )
							m_aL1Orthant[i] = 1;
						else
							m_aL1Orthant[i] = 0;
					}
				}
			}


			return true;
		}

		/// �����ݶ�
		bool GetGradient_norm(double *pdParams, double *pdGradient)
		{
			//wbFile test("testThread_s.dbg", "wt");


			if (pdParams) {
#ifdef NotEstimateZeta  //ʹ����ʵ��Zeta�������Ҫ��һ��
				m_pModel->SetParams(pdParams, true);
#else
				m_pModel->SetParams(pdParams, false);
#endif
			}

			int nFeatrueNum = m_pModel->m_nFeatNum;
			
	

			memset(m_pPnfi, 0, sizeof(m_pPnfi[0])*nFeatrueNum);

			titlePrecent(0, true, m_nMinBatch, "GetGradientNorm: ");
			for (int n=0; n<m_nMinBatch; n++) {

// 				for (int i=0; i<m_nSeqLen; i++)
// 					test.Print("%c", m_pSeqBuf[i]+'a');
// 				test.Print("\t");

				//����
				m_pModel->Sampling(m_pSeqBuf, m_nSeqLen);

// 				for (int i=0; i<m_nSeqLen; i++)
// 					test.Print("%c", m_pSeqBuf[i]+'a');
// 				test.Print("\n");

				//ͳ��ÿ�������ĸ���
				for (int i=0; i<m_pModel->m_nFeatNum; i++) {
					int temp = m_pModel->m_aFeatures[i]->nAccept(m_pSeqBuf, m_nSeqLen);
					m_pPnfi[i] = m_pPnfi[i] + 1.0/(n+1) * (temp - m_pPnfi[i]);
				}

				titlePrecent(n+1);
			
			}
			

			//�����ݶ�
			for (int i=0; i<m_nParamNum; i++) {
				pdGradient[i] = m_pPnfi[i] - m_pPefi[i];
			}

			//������
			if (pdParams) {
				for (int i=0; i<m_nParamNum; i++)
					pdGradient[i] += m_dRegular * pdParams[i];
			}


			return true;
		}

		/// ������Ϣ
		virtual int GetExtraValues(double *pdParams, double *pdValues)
		{
// #ifdef _DEBUG
// 			return 0;
// #endif
			static int t = -1;
			t++;

			int nNum = 0;

			///< ������ӡbreak-down���log-likelihood
			/* < �ļ���ʽΪ��
					train set log-likelihood + \zeta*
					test set log-likelihood + \zeta*
					train set log-likelihood + true \zeta
					test set log-likelihood + true \zeta
			*/	



			if (pdParams) {
				m_pModel->SetParams(pdParams, !m_bFastIter);
			}

			//ѵ������Ȼֵ
			pdValues[0] = CaculateLogLikelihood(&m_corpusTrain, true, NULL);

			//��֤����Ȼֵ
			pdValues[1] = CaculateLogLikelihood(&m_corpusValid, true);

			//���Լ���Ȼֵ, ��PPL
			pdValues[2] = CaculateLogLikelihood(&m_corpusTest, true, &pdValues[3]);

			nNum+=4;

#ifdef Scheme1
			if (!m_bFastIter)
			{
				//ʹ�þ�ȷ�Ĺ�һ��ϵ��������Ȼֵ
				CDmodel_len *pModel = (CDmodel_len*)m_pModel;

				wbArray<double> aSave(m_pModel->m_nMaxLen+1); //����zeta
				aSave.Copy(pModel->m_aApproxLogNormFactors);
			
				for (int i=1; i<=m_pModel->m_nMaxLen; i++) {
					pModel->m_aApproxLogNormFactors[i] = pModel->m_aLogNormFactors[i] - pModel->m_aLogNormFactors[pModel->j_zero];
				}

			
				pdValues[4] = CaculateLogLikelihood(&m_corpusTrain, true, NULL); //ѵ��������Ȼֵ
				pdValues[5] = CaculateLogLikelihood(&m_corpusValid, true);
				pdValues[6] = CaculateLogLikelihood(&m_corpusTest, true, &pdValues[7]);//���Լ���Ȼֵ, ��PPL

				pModel->m_aApproxLogNormFactors.Copy(aSave);

				nNum+=4;
			}

			

			//�滻�᳤�ȷֲ�
// 			m_pModel->m_aLenProb.Copy(m_aSampleLenProb);

			if (m_pFileBeakDownLL) {
				m_pFileBeakDownLL->Print("\n");
			}

			return nNum;
#else
			return nNum;
#endif
		}
	};

	
	/** 
	 * \class
	 * \brief SA��������������CD�������еĲ����趨
	 */
	class SAIter : public CDIter
	{
		/*
		ѧϰ��¼���㹫ʽ
		\gamma = 1.0 / (1+t*r)^beta_lambda
		*/
	public:

		const char *m_pPathModel; ///< ���ģ���ļ�

		int m_nMinBatch_Init;  ///< min-batch�ĳ�ֵ
		double m_nMinBatch_Step;  ///< min-batch�ĵ�����

		int m_tconstant; ///< ����˥��ϵ���Ķ��ⳣ��
		int m_b0;

		///< �ݶȵ�Threshold��û��ʹ�ã�
		double m_dHardThreshold; 
		double m_dSoftThreshold; 

		ValueDet m_valueDet; ///< ��ֹ�о���
		double m_dTerminalRate; ///< ��ֹ����
		int m_nValuePerIteration; ///< ÿ�����ٲ�����һ��valid-set�ϵ���Ȼֵ
		

		wbFile *m_pfdbg_hessian;
		wbFile *m_pfdbg_curHessian; 
		wbFile *m_pfdbg_diffGradient;
		wbFile * m_pfdbg_scaledG;
		wbFile * m_pfdbg_zeta;
		wbFile *m_pfdbg_class;
		
		double m_dHessianGap;
#ifdef Hessian
		wbArray<double> m_aHessianDiag; ///< ����Hessian�Խ�
		wbArray<double> m_aRescaledGradientAvg; ///< ����Rescaled�ݶȣ���ʷƽ��
#endif
#ifdef _LBFGS
		int m_nLBFGS_avgNum; ///< ƽ��ÿ���ٴμ���һ�� diff-gradient
		int m_nLBFGS_curNum; ///< LBFGS�ĵ�ǰ������������ʵ���� m_nIterNum / m_nLBFGS_avgNum
		wbArray<double> m_aPrevAvgParams; ///< ������һ��set��ƽ������
		wbArray<double> m_aCurAvgParams; ///< ���浱ǰset��ƽ������
		wbArray<double> m_aParamDiff; ///< ����diff-params
		wbArray<double> m_aGradientDiff; ///< ���� diff-gradient
		double m_dSYprod_avg; ///< save the average of s*y
		wbCirQueue<double> m_aSYprod_wind; 
#endif
		//�����ڹ�һ���Ĺ���
		double m_dNormAutoRate; ///< ����һ�����жϺ�ʱ��ֹ
		double m_dCurPiDiffRate; ///< ����һ�������浱ǰ�� max{ pi-true_pi / true_pi }
	public:
		SAIter(wbFunc *pfunc, double p_beta_lambda, double p_beta_zeta, double p_t0, 
			double p_beta_lambda2 = 1, double p_beta_zeta2 = 1, double p_r_lambda=1, double p_r_zeta=1): 
		CDIter(pfunc, p_beta_lambda, p_beta_zeta, p_t0, p_beta_lambda2, p_beta_zeta2, p_r_lambda, p_r_zeta)
		{
			m_pPathModel = NULL;
			m_dHardThreshold = 0;
			m_dSoftThreshold = 0;
			m_tconstant = 0;
			m_b0 = 0;

			m_valueDet.Init(1000, 100);
			m_dTerminalRate = 0.1;
			m_nValuePerIteration = 1;

			m_pfdbg_hessian = NULL;
			m_pfdbg_curHessian = NULL;
			m_pfdbg_diffGradient = NULL;
			m_pfdbg_scaledG = NULL;
			m_pfdbg_zeta = NULL;
			m_pfdbg_class = NULL;
#ifdef Hessian
			m_aHessianDiag.SetNum(pfunc->m_nParamNum+10);
			m_aHessianDiag.Fill(1);
			m_aRescaledGradientAvg.SetNum(pfunc->m_nParamNum+10);
			m_aRescaledGradientAvg.Fill(0);
#endif
#ifdef _LBFGS
			m_nLBFGS_avgNum = 1;
			m_nLBFGS_curNum = 0;
			//lout_variable(m_nLBFGS_avgNum);
			m_dSYprod_avg = 0;
#endif
			m_dNormAutoRate = 0;
			m_dCurPiDiffRate = 1;
		}
		~SAIter() 
		{
			SAFE_DELETE(m_pfdbg_hessian);
			SAFE_DELETE(m_pfdbg_curHessian);
			SAFE_DELETE(m_pfdbg_diffGradient);
			SAFE_DELETE(m_pfdbg_zeta);
			SAFE_DELETE(m_pfdbg_scaledG);
			SAFE_DELETE(m_pfdbg_curHessian);
		}

		virtual void ComputeDir(int k, double *pdGradient, double *pdAlpha, double *pdDir)
		{
			int nVecLen = m_pFunc->m_nParamNum;

			int t = m_nIterNum+1; //��1��ʼ
			//����ѧϰ����
			if (t <= t0) {
				gamma_lambda = a0_lambda / (m_tconstant + pow( ( 1 +t*r_lambda), beta_lambda ) );
				gamma_zeta = a0_zeta / ( /*m_tconstant +*/ pow( 1+t*r_zeta, beta_zeta ) );
			} else {
				//�ڶ�����Ҫ����ͳ��zeta������lambda�Ĺ���
				gamma_lambda = a0_lambda / ( m_tconstant + pow( ((t-t0)*r_lambda), beta_lambda2) + pow( (1+t0*r_lambda), beta_lambda) );
				gamma_zeta = a0_zeta / ( /*m_tconstant +*/ pow( ((t-t0)*r_zeta), beta_zeta2) + pow( (1+t0*r_zeta), beta_zeta) );
				//gamma_zeta = a0_zeta / ( /*m_tconstant +*/ pow( 1+t*r_zeta, beta_zeta ) );
			}


#ifdef _LBFGS
			lout<<"[LBFGS Rescale] ";
			lout_variable(m_nLBFGS_curNum);
			///< ʹ��LBFGS���㷽��
			wbLBFGS::ComputeDir(m_nLBFGS_curNum, pdGradient, pdAlpha, pdDir);

			for (int n=0; n<nVecLen; n++) {
				pdDir[n] *= gamma_lambda;
			}

// 			for (int n=0; n<nVecLen; n++) {
// 				m_aParamDiff[n] = pdDir[n];
// 			}

			return;
#endif


			

			if ( m_dHardThreshold > 0 ) {
				int iHardThreshold = 0;
				for (int n=0; n<nVecLen; n++) {
					if ( fabs(pdGradient[n]) < m_dHardThreshold ) {
						pdGradient[n] = 0;
						iHardThreshold++;
					}
				}
				lout_variable_precent(iHardThreshold, nVecLen);
			} else if ( m_dSoftThreshold > 0 ) {
				int iSoftThreshold = 0;
				for (int n=0; n<nVecLen; n++) {
					if ( fabs(pdGradient[n]) < m_dSoftThreshold ) {
						pdGradient[n] = 0;
						iSoftThreshold++;
					} else
						pdGradient[n] -= m_dSoftThreshold;
				}
				lout_variable_precent(iSoftThreshold, nVecLen);
			}

#ifdef Hessian
			double gamma_hessian = gamma_lambda;

			double *pHessianDiag = ( (SA*)m_pFunc)->m_aHessianDiag.GetBuffer();
			if ( k== 0 )  {
				for (int n=0; n<nVecLen; n++)
					m_aHessianDiag[n] = pHessianDiag[n];
			} else {
				for (int n=0; n<nVecLen; n++)
					m_aHessianDiag[n] += gamma_hessian * ( pHessianDiag[n] - m_aHessianDiag[n] );
			}
			
			
			if ( k >= m_b0 ) {
				lout<<"[Hessian Rescale] gamma="<<gamma_hessian<<" ";
				int nOverGap = 0;
				for (int n=0; n<nVecLen; n++) {


					if ( m_aHessianDiag[n] >= m_dHessianGap ) {
						pdGradient[n] /= m_aHessianDiag[n]; 
						nOverGap++;
					} else {
						if ( m_dHessianGap > 0 ) {
							pdGradient[n] /= m_dHessianGap;
						}
					}
				}
				lout_variable_precent(nOverGap, nVecLen);
			}

			//�����ݶȵ���ʷƽ��
			for (int i=0; i<nVecLen; i++) {
				m_aRescaledGradientAvg[i] += 1.0 / t * ( pdGradient[i] - m_aRescaledGradientAvg[i] );
			}
#endif

#ifdef _Var
			LogP *pVar = ( (SA*)m_pFunc )->m_aLogFeaVar.GetBuffer();

			if ( k >= m_b0 ) {
				int nOverGap = 0;
				for (int n=0; n<nVecLen; n++) {
					double d = LogP2Prob(pVar[n]*2);  //��׼��ת��Ϊ����
					if ( d >= m_dHessianGap ) {
						pdGradient[n] /= d; 
						nOverGap++;
					} else {
						if ( m_dHessianGap > 0 ) {
							pdGradient[n] /= m_dHessianGap;
						}
					}
				}
				lout_variable_precent(nOverGap, nVecLen);
			}

#endif //_Var

#ifdef _Class
			( (SA*)m_pFunc )->UpdateClassProb(gamma_lambda);
#endif
#ifdef _QNSG
			/// write file: monitor hessian
			if (m_pfdbg_hessian) {
				for (int n=0; n<nVecLen; n++) m_pfdbg_hessian->Print("%f ", m_aHessianDiag[n]);
				m_pfdbg_hessian->Print("\n");
			}
			wbFile fileCurH("curHessian.dbg", "wt");
			for (int n=0; n<nVecLen; n++) fileCurH.Print("%f ", m_aHessianDiag[n]);
			fileCurH.Print("\n");
			fileCurH.Close();

			lout<<"<< Hessian formulation >>"<<endl;
			for (int n=0; n<nVecLen; n++) {
				if ( m_aHessianDiag[n] != 0 )
					pdGradient[n] /= m_aHessianDiag[n];
			}
#endif

			


			if (k == 0) {
				for (int n=0; n<nVecLen; n++)
					pdDir[n] = gamma_lambda * ( -pdGradient[n] );  //������Ҫȡ��
			} else {
				for (int n=0; n<nVecLen; n++)
					pdDir[n] = gamma_lambda * ( -pdGradient[n]  ) + fMomentum * pdDir[n]; ///�����������ʷ����
			}
		}

		virtual double LineSearch(double *pdDir, double dValue, double *pdGradient, double *pdCurParam, double *pdNextParam)
		{
			int t = m_nIterNum+1; //��1��ʼ
			//m_opt_dFixedStep = m_dStepInit / (1 + m_dr * m_nIterNum);
			//m_opt_dFixedStep = pow(m_nIterNum+1, -beta);

			if ( bAutoTermate && t<t0 && t%m_nValuePerIteration==0 ) //����ƽ����Ȼ������ֹ����
			{
				SA * pSA = (SA*) m_pFunc;
				dValue = pSA->CaculateLogLikelihood( &(pSA->m_corpusValid) );
				m_valueDet.AddValue(dValue);
				//lout_variable(m_valueDet.m_nSignSum);
				if ( /*t > 5000 &&*/ m_valueDet.bTerminate( m_dTerminalRate ) ) {
					int nTemp = m_opt_nMaxIterNum - t0;
					t0 = t;
					m_opt_nMaxIterNum = t0 + nTemp;
					lout<<"[SAIter] AutoTermate flag="<<m_valueDet.m_nSignSum<<" t0="<<t0<<" tmax="<<m_opt_nMaxIterNum<<endl;
				}
			}
			

			//����ѧϰ����
// 			if (t <= t0) {
// 				gamma_lambda = a0_lambda / pow( (1+t*r_lambda), beta_lambda );
// 				gamma_zeta = a0_zeta / pow( (1+t*r_zeta), beta_zeta );
// 			} else {
// 				//�ڶ�����Ҫ����ͳ��zeta������lambda�Ĺ���
// 				gamma_lambda = 0; // a0_lambda / ( pow( ((t-t0)*r_lambda), beta_lambda2) + pow( (1+t0*r_lambda), beta_lambda) );
// 				gamma_zeta = a0_zeta / ( pow( ((t-t0)*r_zeta), beta_zeta2) + pow( (1+t0*r_zeta), beta_zeta) );
// 			}

			lout<<"[SAIter ";
			if ( t<=t0 ) lout<<"I"; else lout<<"II";
			lout<<"] [t0="<<t0<<" tmax="<<m_opt_nMaxIterNum<<"] t="<<t<<" g_lambda="<<gamma_lambda<<" g_zeta="<<gamma_zeta<<endl;

			//���²���
			//���²��������ò���ƽ������һ���ģ���ͬ���ǣ�ƽ���Ļ������ս��ȡƽ����Ĳ�������������Ȼʱ���õ�ƽ��
			for (int i=0; i<m_pFunc->m_nParamNum; i++) {
				pdNextParam[i] = pdCurParam[i] + /*gamma_lambda **/ pdDir[i]; //���ڼ���dirʱ�Ѿ���Ȩ��ѧϰ����
			}
			if ( bAverage_lambda ) //����ƽ��ֵ
			{ 
				/*
					ƽ��ֵ�����ڶ����buf��=>pAvgLambda
					����ǰ��������Ҫ����ƽ������pAvgLambda�м�¼����pdNextParam�е�ֵ������ͳһ����
				*/
				if ( t > nAverageBeg && t <= nAverageEnd ) 
				{  
					lout<<"[SA average-lambda]"<<endl;
					//����ƽ��
					for (int i=0; i<m_pFunc->m_nParamNum; i++) { //����ƽ��
						pAvgLambda[i] += 1.0 / (t-nAverageBeg+1) * (pdNextParam[i] - pAvgLambda[i]);
					}
					if ( t== nAverageEnd ) {  //ƽ������ʱ,��Ҫ����ƽ������
						memcpy( pdNextParam, pAvgLambda, sizeof(pdNextParam[0])*(m_pFunc->m_nParamNum) );
					}
				} 
				else //������������pAvgLambda,����ͳһ����
				{
					memcpy( pAvgLambda, pdNextParam, sizeof(pdNextParam[0]) * (m_pFunc->m_nParamNum) );
				}
				
			}

			
			///< ����L1����Ĵ��ڣ�ÿ�ε��²�����Ҫ����ͶӰ
			( (SA*)m_pFunc )->L1Projection( pdNextParam );
			
			

#ifdef _LBFGS
			//�ۼӲ�����������ƽ��
			for (int i=0; i<m_pFunc->m_nParamNum; i++)
				m_aCurAvgParams[i] += pdNextParam[i];
#endif
				

			//�����淶��
			// wb : 2014/6/27
// 			double d = pdNextParam[0];
// 			for (int i=0; i<m_pFunc->m_nParamNum; i++) {
// 				pdNextParam[i] -= d;
// 			}
			
// 			if ((m_nIterNum+1)%m_opt_nPrintPerIter==0) {
// 				//��ӡ����
// 				for (int i=0; i<min(2000,m_pFunc->m_nParamNum); i++) {
// 					fileParamDbg.Print("%.2lf ", pdNextParam[i]);
// 				}
// 				fileParamDbg.Print("\n");
// 			}


#ifdef Scheme1
			CDmodel_len *pModel = (CDmodel_len *) ((SA*)m_pFunc)->m_pModel;
			bool bOutDbg = (m_nIterNum+1)%m_opt_nPrintPerIter==0;
			m_dCurPiDiffRate = 
				pModel->UpdateApproximateValues(gamma_zeta, ((bAverage_zeta&&t>nAverageBeg&&t<=nAverageEnd)?t-nAverageBeg+1:-1), true/*bOutDbg*/);

			if ( t<t0 && m_dNormAutoRate>0 && m_dCurPiDiffRate<=m_dNormAutoRate ) {
				//�л��ڶ��׶�
				int nTemp = m_opt_nMaxIterNum - t0;
				t0 = t;
				m_opt_nMaxIterNum = t0 + nTemp;
				lout<<"[SAIter] NormTermate dRate="<< m_dCurPiDiffRate <<" t0="<<t0<<" tmax="<<m_opt_nMaxIterNum<<endl;
			}
			
/*	
			//Approx Normalization
			SA *pSA = (SA*)m_pFunc;
			lout<<"ApproxNormalization: [beg]"<<endl;
			pModel->SetParams(pdNextParam, false); //���ò���
			//pModel->UpdateApproximateValues(gamma_zeta, ((bAverage_zeta&&t<=t0&&t>=nAverageBeg)?t-nAverageBeg+1:-1));
			pModel->ApproxNormalization(pSA->m_pThreadMger->m_ppSeqBuf[0], pSA->m_pThreadMger->m_pSeqLen[0], 0.01, 10000);
	*/
#endif

			return gamma_lambda;	
		}

		virtual int GetExValues( double *pdCurParams, double *pdExValue )
		{
			int t = m_nIterNum + 1;
			int nValue = 0;
#ifdef Scheme1
			CDmodel_len *pModel = (CDmodel_len *) ((SA*)m_pFunc)->m_pModel;
			if ( bAverage_zeta ) {
				pModel->ExchangeAvgNoavgZeta(); //ʹ��Avg��Zeta
			}
#endif

			if ( bAverage_lambda )
				nValue = m_pFunc->GetExtraValues( pAvgLambda, pdExValue );
			else
				nValue = m_pFunc->GetExtraValues( pdCurParams, pdExValue );
#ifdef Scheme1
			if ( bAverage_zeta ) {
				pModel->ExchangeAvgNoavgZeta(); //�滻�ط�Avg��Zeta
			}
#endif

// #ifdef _LBFGS
// 			pdExValue[nValue++] = m_dSYprod_avg;
// 			if ( m_pd_s && m_pd_y ) {
// 				pdExValue[nValue++] = VecProduct(m_pd_s, m_pd_y, m_pFunc->m_nParamNum);
// 			}
// 			
// #endif
#ifdef Hessian
			///����rescaled���ݶȵ�ģ;
			//pdExValue[nValue++] = VecNorm(m_aRescaledGradientAvg, m_pFunc->m_nParamNum);
#endif
			if ( bAutoTermate )  ///��ӡ�Զ���ֹ����
				pdExValue[nValue++] = m_valueDet.m_nSignSum;
			if ( m_dNormAutoRate > 0 ) 
				pdExValue[nValue++] = m_dCurPiDiffRate;

			return nValue;
		}
		virtual void OutputDbg(double *pParams, double *pGradient, double *pdDir)
		{
			int t = m_nIterNum + 1;
			int nVecLen = m_pFunc->m_nParamNum;

			if ( m_pfdbg_dir ) {
				m_pfdbg_dir->PrintArray("%f", pdDir, nVecLen);
			}
			if ( m_pfdbg_x ) {
				double *px = pParams;
				if ( bAverage_lambda ) {
					px = pAvgLambda;
				} 
				
				m_pfdbg_x->PrintArray("%f", px, nVecLen);
			}
			if ( m_pfdbg_zeta ) {
				CDmodel_len *pModel = (CDmodel_len *) ((SA*)m_pFunc)->m_pModel;
				double *pZeta = pModel->m_aApproxLogNormFactors;
				if ( bAverage_lambda ) {
					pZeta = pModel->m_aAvgLogNormFactors;
				}

				m_pfdbg_zeta->PrintArray("%f", pModel->m_aApproxLogNormFactors+1, pModel->m_nMaxLen);
				m_pfdbg_zeta->PrintArray("%f", pModel->m_aAvgLogNormFactors+1, pModel->m_nMaxLen);

			}
			if ( m_pfdbg_g ) {
				m_pfdbg_g->PrintArray("%f", pGradient, nVecLen);
			}

#ifdef Hessian
			/// write file: monitor hessian
			if (m_pfdbg_hessian) {
				m_pfdbg_hessian->PrintArray("%f", m_aHessianDiag.GetBuffer(), nVecLen);
			}
			/// write file: the current hessian
			if ( m_pfdbg_curHessian ) {
				m_pfdbg_curHessian->Reopen( "wt" );
				m_pfdbg_curHessian->PrintArray("%f", m_aHessianDiag.GetBuffer(), nVecLen );
				m_pfdbg_curHessian->Close();
			}
			/// wirte file: the average of rescaled gradient
			if ( m_pfdbg_scaledG ) {
				 m_pfdbg_scaledG->PrintArray("%f ", m_aRescaledGradientAvg.GetBuffer(), nVecLen);
			}
#endif
#ifdef _LBFGS
			if ( m_pfdbg_diffGradient ) {
				m_pfdbg_diffGradient->PrintArray("%f", m_aGradientDiff.GetBuffer(), nVecLen);
			}
#endif
#ifdef _Class
			if (m_pfdbg_class) {
				SA *pSA = (SA*)m_pFunc;
				wbDArray<wbArray<double> *> *pClassProb = &((SA*)m_pFunc)->m_aClassProb;
				for (int len=1; len<=pSA->m_pModel->m_nMaxLen; len++) {
					for (int h=0; h<len; h++) {
						m_pfdbg_class->Print("%d %d ", len, h);
						for ( int c=0; c<pSA->m_pModel->m_pVocab->nClassIdTop; c++ ) {
							m_pfdbg_class->Print("%lf ", pClassProb->Get(len, h)->Get(c));
						}
						m_pfdbg_class->Print("\n");
					}
				}
				m_pfdbg_class->Print("\n");
			}
#endif
		}

#ifdef _LBFGS
		virtual void IterInit()
		{
			//��ʼ��m_aPrevAvgParams
			m_aPrevAvgParams.SetNum(m_pFunc->m_nParamNum);
			( (SA*)m_pFunc )->m_pModel->GetParams(m_aPrevAvgParams);
			m_aCurAvgParams.SetNum(m_pFunc->m_nParamNum);
			m_aCurAvgParams.Fill(0);

			//init the window
			m_aSYprod_wind.Init(10*m_nLBFGS_avgNum);
		}
		virtual void GetGradient(double *pdCurParam, double *pdCurGradient, double *pdPreGradient /* = NULL */)
		{
			SA *pSA = (SA*)m_pFunc;
			if ( (m_nIterNum+1) % m_nLBFGS_avgNum == 0 ) {
				lout<<"[LBFGS update] m_nLBFGS_avgNum="<<m_nLBFGS_avgNum<<endl;
				//����һ��LBFGS y
				for (int i=0; i<pSA->m_nParamNum; i++)
					m_aCurAvgParams[i] /= m_nLBFGS_avgNum;

				for (int i=0; i<pSA->m_nParamNum; i++)
					m_aParamDiff[i] = m_aCurAvgParams[i] - m_aPrevAvgParams[i];
				pSA->m_pThreadMger->m_pVectorS = m_aParamDiff.GetBuffer(); //����diff_x

				m_aPrevAvgParams.Copy(m_aCurAvgParams);
				m_aCurAvgParams.Fill(0);
			} else {
				pSA->m_pThreadMger->m_pVectorS = NULL;
			}

			pSA->GetGradient(pdCurParam, pdCurGradient);

			///< ����diff_gradient
// 			wbArray<double> aCurDiff(m_pFunc->m_nParamNum);
// 			pSA->GetGradientDiff( aCurDiff );

// 			for (int i=0; i<m_pFunc->m_nParamNum; i++)
// 				m_aGradientDiff[i] = aCurDiff[i]; 

		}
		virtual void AddDiff(double *pdCurParams, double *pdPreParams, double *pdCurGradient, double *pdPreGradient)
		{
			if ( (m_nIterNum+1) % m_nLBFGS_avgNum == 0 ) {
				//lout<<"[LBFGS add] m_nLBFGS_curNum="<<m_nLBFGS_curNum<<endl;
				

				//wbArray<double> aCurDiff(m_pFunc->m_nParamNum);
				m_aGradientDiff.SetNum(m_pFunc->m_nParamNum);
				((SA*)m_pFunc)->GetGradientDiff( m_aGradientDiff );

				double temp = VecProduct(m_aParamDiff, m_aGradientDiff, m_pFunc->m_nParamNum);

				
				m_aSYprod_wind.In(temp);
				m_dSYprod_avg = m_aSYprod_wind.GetSum() / m_aSYprod_wind.GetNum();
				lout<<"[LBFGS add] s*y_avg="<<m_dSYprod_avg<<" s*y_cur="<<temp<<endl;

				if ( m_dSYprod_avg == 0 || temp > m_dSYprod_avg/2 || temp > m_dHessianGap) {
					m_nLBFGS_curNum++;
					
// 					double *pds = m_pd_s;
// 					double *pdy = m_pd_y;

					CirQueueBuf_In(m_pd_s, m_pd_y);

// 					if ( pds && pdy )
// 					{
// 						for (int n=0; n<m_pFunc->m_nParamNum; n++) {
// 							m_pd_s[n] = pds[n] + gamma_lambda * (m_aParamDiff[n] - pds[n]);
// 							m_pd_y[n] = pdy[n] + gamma_lambda * (m_aGradientDiff[n] - pdy[n]);
// 						}
// 					}
// 					else
// 					{
						for (int n=0; n<m_pFunc->m_nParamNum; n++) {
							m_pd_s[n] = m_aParamDiff[n];
							m_pd_y[n] = m_aGradientDiff[n];
						}
//					}				
				}

			}
		}
#endif
		virtual void IterStepEnd(int k)
		{
			SA *pSAFunc = (SA*)m_pFunc;
			int nVecNum = m_pFunc->m_nParamNum;
#ifdef _QNSG
			//���½���Hessian��Խ�Ԫ
			int nNozero = 0;
			for (int i=0; i<nVecNum; i++)
			{
				if ( m_pd_s[i] != 0 && m_pd_y[i] !=0 ) {
					nNozero++;
					m_aHessianDiag[i] += 2.0/(k+1) * ( m_pd_s[i] / m_pd_y[i] - m_aHessianDiag[i] );
				} else {
					m_aHessianDiag[i] = 1;
				}
			}
			lout_variable_precent(nNozero, nVecNum);
#endif

			//����min-batch
			if ( m_nMinBatch_Step > 0 ) {
				pSAFunc->m_nMinBatch = m_nMinBatch_Init + m_nMinBatch_Step * (k+1);
				pSAFunc->m_pThreadMger->SetMinBatch(pSAFunc->m_nMinBatch);
				lout_LBFGS<<"Update min-batch = "<<pSAFunc->m_nMinBatch<<endl;
			}
			
			// ���浱ǰ��MCMC״̬
			pSAFunc->m_pThreadMger->Save(wbFile( wbString(m_pPathModel).FileName() + ".mcmc", "wt" ));

			wbArray<wbString> aWritePaths;
			//��ӡ�ļ�
			if ( m_nWriteModelPerIter>0 && (k+1)%m_nWriteModelPerIter == 0 ) 
			{
				char fileName[2048];
				if (m_strWriteModelDir != "" && *m_strWriteModelDir.End() != '\\')
					m_strWriteModelDir += "\\";
				sprintf(fileName, "%sTemp%d.mode", m_strWriteModelDir.GetBuffer(), (k+1)/m_nWriteModelPerIter);
				aWritePaths.Add(fileName);
			}
			if ( m_pPathModel && (k+1)%5000 == 0 )
			{
				aWritePaths.Add(m_pPathModel);
			}

			if ( aWritePaths.GetNum() > 0 ) {
				//�滻ΪAvg�Ĳ���
				if ( bAverage_lambda ) {
					pSAFunc->m_pModel->SetParams( pAvgLambda, !(pSAFunc->m_bFastIter) );
				}
				if ( bAverage_zeta ) {
					( (CDmodel_len *)(pSAFunc->m_pModel) )->ExchangeAvgNoavgZeta();
				}

				//д�ļ�
				for (int i=0; i<aWritePaths.GetNum(); i++) {
					lout<<"[Write Model] => "<<aWritePaths[i].GetBuffer()<<endl;
					pSAFunc->m_pModel->WriteT( wbFile(aWritePaths[i], "wt") );
				}
				
				//�滻�ص�������
				if ( bAverage_zeta ) {
					( (CDmodel_len *)(pSAFunc->m_pModel) )->ExchangeAvgNoavgZeta();
				}
			}

		}

		virtual void IterEnd()
		{
			//������ƽ��������Ҫʹ��ƽ�����lambda
			if ( bAverage_lambda ) {
				SA *pSAFunc = (SA*)m_pFunc;
				pSAFunc->m_pModel->SetParams(pAvgLambda, !pSAFunc->m_bFastIter);
			}
			// ��ƽ������ʹ��ƽ�����zeta 
			if ( bAverage_zeta ) {
				CDmodel_len *pModel = (CDmodel_len *) ((SA*)m_pFunc)->m_pModel;
				pModel->ExchangeAvgNoavgZeta();
			}
		}
	};

}


