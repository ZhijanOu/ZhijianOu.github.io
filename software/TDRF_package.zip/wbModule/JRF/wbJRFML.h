// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF model, Exact estimation.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/** 
 * \file
 * \author wangbin
 * \date 2014-03-3
 * \brief JRFģ��, MLѵ���㷨
 */

#pragma once
#include "wbJRFMLmodel.h"
#include "wbJRFClassModel.h"
#include "wbLBFGS.h"
#include "wbGD.h"
#include <omp.h>

namespace wbJRF
{
	class MLfunc : public wbFunc
	{
	public:
// 		wbArray<wbArray<int>> m_aTrainSeqs;
// 		wbArray<wbArray<int>> m_aTestSeqs;

		Corpus m_corpusTrain;
		Corpus m_corpusTest;
		int m_nSeqMaxLen;		///< ������������󳤶�
		int m_nSeqNum;			///< ѵ�����Ͼ�����
		bool m_bLoadTrainAll; ///< �Ƿ�train����ȫ�������ڴ�
		bool m_bLoadTestAll;  ///< �Ƿ�test����ȫ�������ڴ�

		MLmodel *m_pModel;

		wbArray<LogP> m_aFeaExpe; ///< ���������ֲ�,����
		wbArray<int> m_aLenCount; ///< ÿ�����ȵĸ���

		wbArray<LogP> m_aFeaVar; ///< �����ķ���

		double m_reg_l2;
		double m_reg_l1;

	public:
		MLfunc() : m_pModel(NULL){
			m_bLoadTrainAll = false;
			m_bLoadTestAll = false;
			m_reg_l2 = 0;
			m_reg_l1 = 0;
		}

		/// ׼������
		virtual void Prepare(MLmodel *pModel, const char *pathTrain, const char *pathTest, 
			const char *pathEmpirical = NULL, const char *pathVar = NULL )
		{
			m_pModel = pModel;
			wbFunc::m_nParamNum = m_pModel->m_nFeatNum;

			m_corpusTrain.Reset(pathTrain, m_bLoadTrainAll);
			m_corpusTest.Reset(pathTest, m_bLoadTestAll);
			m_nSeqMaxLen = max(m_corpusTrain.m_nSize, m_corpusTest.m_nSize);
			m_nSeqNum = m_corpusTrain.m_nLine;
			lout_variable(m_nSeqNum);
			lout_variable(m_nSeqMaxLen);
			if (m_pModel->m_nMaxLen < m_nSeqMaxLen) {
				lout_error("ģ���趨���ȣ�"<<m_pModel->m_nMaxLen<<"�� < ������������󳤶ȣ�"<<m_nSeqMaxLen<<"��");
			}

			//ͳ�Ƴ��ȷֲ�
			m_aLenCount.SetNum(m_pModel->m_nMaxLen+1);
			m_aLenCount.Fill(0);
			wbArray<int> aSeq;
			for (int i=0; i<m_corpusTrain.m_nLine; i++) {
				m_corpusTrain.GetLine(i, aSeq);
				m_aLenCount[aSeq.GetNum()]++;
			}
			if ( pModel->m_aLenProb.GetNum() == 0 ) { //��ģ�͵ĳ��ȷֲ�û�г�ʼ��������г�ʼ��������ʹ��ģ���Դ��ĳ��ȷֲ�
				for (int i=0; i<m_aLenCount.GetNum(); i++) { //Ϊ���ȷֲ���ֵ
					m_pModel->m_aLenProb[i] = 1.0 * m_aLenCount[i] / m_corpusTrain.m_nLine;
				}
			}
			


			//ͳ�ƾ��������� ��ʹ��ģ���еĳ��ȷֲ�
			if (pathEmpirical)
				ReadEmpirical(wbFile(pathEmpirical, "rt"));
			else
				Empirical(m_corpusTrain);

#ifdef _FeatNorm
			//ͳ����������
			if (pathVar)
				ReadFeatVar(wbFile(pathVar, "rt"));
			else
				EmpiricalVar(m_corpusTrain);
			m_pModel->SetFeatMeanVar( m_aFeaExpe, m_aFeaVar );
#endif


			lout_variable(m_corpusTrain.m_nLine);
			lout_variable(m_corpusTest.m_nLine);
		}
		/// ͨ��count�ļ�����������
//		void LoadFeatures(const char *pathCount); 
		/// ����Gram����ģ��
//		void AddFeature(Ngram *pf, double dValue = 0);
		/// ͳ��feature�ľ�������
		void Empirical(Corpus &corpus);
		/// ��ȥ��������С�ڸ���ֵ������
//		void CutFeatrues(double dCutoff = 0);
		/// ��������
//		void LoadSeqs(wbFile &file, wbArray<wbArray<int>> &aSeqs);
		/// ͳ�������ķ���
		void EmpiricalVar( Corpus &corpus );

		virtual double GetValue(double *pdParams);
		virtual bool GetGradient(double *pdParams, double *pdGradient);
		virtual int GetExtraValues(double *pdParams, double *pdValues);

		/// ����ĳһά���ݶ�ֵ
		double GetGradient(double *pdParams, int i);
		/// ����Hession�Խ���Ԫ��
		virtual bool GetHession(double *pdParams, double *pdHession, wbFile &file);

		void WriteEmpirical(wbFile &file);
		void ReadEmpirical(wbFile &file);

		void WriteFeatVar(wbFile &file);
		void ReadFeatVar(wbFile &file);

		double CaculateLogLikelihood(Corpus *pCorpus, bool bNorm = true, double *pPPL =NULL)
		{
			double dValue = 0;
			double dPPL = 0;
			wbArray<int> aSeq;
			int nWord = 0;
			for (int i=0; i<pCorpus->m_nLine; i++) {
				pCorpus->GetLine(i, aSeq);
				double d = m_pModel->GetLogProb(aSeq, aSeq.GetNum(), bNorm); 
				dValue += d;
				dPPL += d / log(10.0);
				nWord += aSeq.GetNum() + 1;
			}
			dValue /= pCorpus->m_nLine;
			dPPL = pow(10, -dPPL / nWord);

			if (pPPL) *pPPL = dPPL;

			return -dValue; //������Ȼֵ�Ǳ��ģ���Ҫת��Ϊ��׼��С������
		}
	};

	/** 
	 * \class
	 * \brief pseudo-log-likelihood estimation
	 */
	class MPLfunc : public MLfunc
	{
	public:
		bool m_bFast; ///< ��Ϊtrue���򲻼�����Ȼ�Ĺ�һ��ϵ����

#ifdef _OPENMP
		double **m_pParallelGradient;
#endif

	public:
		MPLfunc()
		{
			m_bFast = false;
			m_bLoadTrainAll = true;
			m_bLoadTestAll = true;
#ifdef _OPENMP
			m_pParallelGradient = NULL;
#endif
		}
		~MPLfunc()
		{
#ifdef _OPENMP
			SAFE_DELETE_DARRAY(m_pParallelGradient, omp_get_num_threads());
#endif
		}

// 		virtual void Prepare(MLmodel *pModel, const char *pathTrain, const char *pathTest, const char *pathEmpirical /* = NULL */)
// 		{
// 
// 		}
		virtual double GetValue(double *pdParams);
		virtual bool GetGradient(double *pdParams, double *pdGradient)
		{
#ifdef _OPENMP
			return GetGradient_omp(pdParams, pdGradient);
#else
			return GetGradient_norm(pdParams, pdGradient);
#endif
		}
		int GetExtraValues(double *pdParams, double *pdValues);

		bool GetGradient_norm(double *pdParams, double *pdGradient);
#ifdef _OPENMP
		bool GetGradient_omp(double *pdParams, double *pdGradient);
#endif

		/// ��������ֲ���������P( X_nPos | X_\nPos = pSeq_\nPos )
		/** 
		 * \param [out] pLogP ����log���ʣ��ռ��СΪ�ֵ��С
		 * \param [in] pSeq ��ʼ����
		 * \param [in] nSeq ���г���
		 * \param [in] nPos ��Ҫ���λ��
		 * \return ������������
		*/
		double GetConditionalDistribution(LogP *pLogP, VocabID *pSeq, int nSeq, int nPos)
		{
			VocabID nSave = pSeq[nPos];

			for (VocabID x=0; x<m_pModel->m_pVocab->nSize; x++) {
				pSeq[nPos] = x;
				pLogP[x] = m_pModel->GetWeightSum(pSeq, nSeq, nPos);
			}
			pSeq[nPos] = nSave;

			LogLineNormalize(pLogP, m_pModel->m_pVocab->nSize);

			return pLogP[nSave];
		}
		double CaculatePseudoLogLikelihood(Corpus *pCorpus)
		{
			double dValue = 0;
			wbArray<int> aSeq;
			wbArray<LogP> aProb(m_pModel->m_pVocab->nSize);

#ifdef _OPENMP
			omp_lock_t file_lock;
			omp_lock_t title_lock;
			omp_init_lock(&file_lock);
			omp_init_lock(&title_lock);

			wbArray<double> aValue(omp_get_max_threads());
			aValue.Fill(0);
			titlePrecent(0, true, pCorpus->m_nLine, "PLL: ");
#pragma omp parallel for firstprivate(aSeq, aProb)
			for (int i=0; i<pCorpus->m_nLine; i++) {
				

				omp_set_lock(&file_lock);
				pCorpus->GetLine(i, aSeq);
				omp_unset_lock(&file_lock);

				double dSum = 0;
				for (int r=0; r<aSeq.GetNum(); r++) {
					dSum += GetConditionalDistribution(aProb, aSeq, aSeq.GetNum(), r);
				}

				aValue[omp_get_thread_num()] += dSum;

				omp_set_lock(&title_lock);
				titlePrecent();
				omp_unset_lock(&title_lock);
			}
			omp_destroy_lock(&file_lock);
			omp_destroy_lock(&title_lock);
			for (int t=0; t<omp_get_max_threads(); t++)
				dValue += aValue[t];
#else
			for (int i=0; i<pCorpus->m_nLine; i++) {
				pCorpus->GetLine(i, aSeq);

				double dSum = 0;
				for (int r=0; r<aSeq.GetNum(); r++) {
					dSum += GetConditionalDistribution(aProb, aSeq, aSeq.GetNum(), r);
				}

				dValue += dSum;
			}
#endif
			dValue /= pCorpus->m_nLine;

			return -dValue; //������Ȼֵ�Ǳ��ģ���Ҫת��Ϊ��׼��С������
		}
	};

	/** 
	 * \class
	 * \brief Iter
	 */
	 class wbML : public wbLBFGS
	 {
	 public:
		 wbString m_strModelPath;
	 public:
		 wbML(wbFunc *pfunc = NULL) : wbLBFGS(pfunc) 
		 {
		 }

		 virtual void IterStepEnd(int k)
		 {
			 if ( k % 100 == 0 && m_strModelPath != "") {
				 MLfunc *pfunc = (MLfunc*)m_pFunc;
				 pfunc->m_pModel->WriteT(wbFile(m_strModelPath, "wt"));
			 }
		 }
	 };
	
}