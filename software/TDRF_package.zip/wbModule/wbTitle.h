// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Title class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.



#ifndef _WB_TITLE_H_
#define _WB_TITLE_H_

#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
using namespace std;
//=========================================================
//==========  �����ࣺwbTitle =============================
//wbTitle�ṩ��title�������Ϣ,ͬʱ�ṩһЩ���õĹ��ܣ�������ٷֱȵȵ�
//=========================================================

#define wbTITLE_MAX_LEN 500

class wbTitle
{
public:
	static void Puts(const char *pStr)
	{
		char command[10+wbTITLE_MAX_LEN];
		sprintf(command, "title \"%s\"", pStr);
		system(command);
	}
	static void Precent(long long n, bool bNew = false, long long nTotal = 100, const char* title = "Process")
	{
		static int snLastPrecent = 0;
		static long long snTotal = 100;
		static char strTitle[500];

		bool bUpdate = false;
		if (bNew)
		{
			if (nTotal > 0)
				snTotal = nTotal;
			snLastPrecent = n * 100 / snTotal;
			strcpy(strTitle, title);
			bUpdate = true;
		}
		else
		{
			int nNew = (int)(1.0*n/snTotal*100);
			if ( nNew > snLastPrecent )
			{
				snLastPrecent = nNew;

				bUpdate = true;
			}
		}

		if (bUpdate)
		{
			char command[wbTITLE_MAX_LEN + 10];
			sprintf(command, "title \"%s%3d%%\"", strTitle, snLastPrecent);
			system(command);
		}
	}

	static void Precent(ifstream &ifile, bool bNew = false, const char* title = "Process")
	{
		if (bNew)
		{
			size_t nCur = ifile.tellg();
			ifile.seekg(0, ios_base::end);
			Precent(nCur, true, ifile.tellg(), title);
			ifile.seekg(nCur);
		}
		else
		{
			Precent(ifile.tellg());
		}
	}

	static void Precent(FILE *fp, bool bNew = false, const char* title = "Process")
	{
		if (bNew)
		{
			long long nCur = _ftelli64(fp);
			_fseeki64(fp, 0, SEEK_END);
			Precent(nCur, true, _ftelli64(fp), title);
			_fseeki64(fp, nCur, SEEK_SET);
		}
		else
		{
			Precent(_ftelli64(fp));
		}
	}
};

#endif