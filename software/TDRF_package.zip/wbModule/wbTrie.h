// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Trie structure
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.



/**
 * \file
 * \author wangbin
 * \date 2014-3-24
 * \brief Trie���ݽṹ
 */
#pragma once
#include "wbSystem.h"
#include "wbLHash.h"
#include "wbList.h"
#include "wbString.h"


#define WBTRIE_LHASH wbLHash<IndexT, wbTrie<IndexT, DataT>*>
#define WBTRIE_LHASH_ITER wbLHashIter<IndexT, wbTrie<IndexT, DataT>*>
#define WBTRIE_LHASH_NODE wbMapUnit<IndexT, wbTrie<IndexT, DataT>*>

/*
Trie��ʹ����һ����Ҫע������⣺
��������һ����״�ṹ����ˣ�����߽׵�index�������ͽ׽ڵ㣬�磺����abc��������a��ab�ڵ㣬���ʹ��Find��Insert�����Żص�
bFoundΪtrue�����Ⲣ����ζ�����ǲ����a��ab�������ȷ���ж��Ƿ����ķ���Ϊ��
DataT *p = trie.Find(index, len);
if ( !p ) {
	*trie.Insert(index, len) = %��һ��ֵ%
	%û�г���%
} else {
	%�г���%
}
��ΪFind�������жϵ�ǰ�ڵ㴦����ֵ�Ƿ񱻸���ֵ��������ֵ����Ż���ָ�룻���򣬷���NULL
*/

template <class IndexT, class DataT>
class wbTrie
{
private:
	DataT data;

public:
	WBTRIE_LHASH TrieHash;

public:
	wbTrie(){  wbMap_noKey(data); };
	~wbTrie() {  Release(); };

	void Release()
	{
		wbTrie<IndexT, DataT> **ppSubTrie;
		IndexT i;
		WBTRIE_LHASH_ITER iter(&TrieHash);
		while (ppSubTrie = iter.Next(i))
		{
			delete *ppSubTrie;
			*ppSubTrie = NULL;
		}
		TrieHash.Clean();
		wbMap_noKey(data);
	}

	void Clean() { Release(); }
	void Fill(DataT d)
	{
		wbTrie<IndexT, DataT> **ppSubTrie;
		IndexT i;
		WBTRIE_LHASH_ITER iter(&TrieHash);
		while (ppSubTrie = iter.Next(i))
		{
			(*ppSubTrie)->Fill(d);
		}
		data = d;
	}

	DataT* GetData() { return &data; }
	bool IsDataLegal() { return !wbMap_noKeyP(data); }

	//���룬������,�����Ƿ��ҵ�
// 	DataT* Insert(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
// 	{
// 		if (nIndexLen == 0)
// 		{
// 			if (wbMap_noKeyP(data))
// 				bFound = false;
// 			return &data;
// 		}
// 
// 		wbTrie<IndexT, DataT> **pSubTrie = TrieHash.Insert(*p_pIndex, bFound);
// 		if (!bFound) {
// 			*pSubTrie = new wbTrie<IndexT, DataT>();
// 		}
// 
// 		return (*pSubTrie)->Insert(p_pIndex+1, nIndexLen-1, bFound);
// 	}
// 
// 	DataT* Find(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
// 	{
// 		if (nIndexLen == 0)
// 		{
// 			if (wbMap_noKeyP(data)) {
// 				bFound = false;
// 
// 				return NULL;
// 			}
// 			return &data;
// 		}
// 
// 		wbTrie<IndexT, DataT> **pSubTrie = TrieHash.Find(*p_pIndex, bFound);
// 		if (!bFound) {
// 			return NULL;
// 		}
// 
// 		return (*pSubTrie)->Find(p_pIndex+1, nIndexLen-1, bFound);
// 	}

	/*
	���߳�ʱ��һ��ҪΪbFound��ֵ������ͬ�߳�֮��Ṳ�� wbTrie::bFound ��ɴ���
	*/
	DataT* Find(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
	{
		wbTrie<IndexT, DataT> *pSub = FindTrie(p_pIndex, nIndexLen, bFound);
		if (pSub && !wbMap_noKeyP(pSub->data)) {
			return &(pSub->data);
		} else {
			bFound = false;
			return NULL;
		}

	}
	DataT* Insert(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
	{
		wbTrie<IndexT, DataT> *pSub = InsertTrie(p_pIndex, nIndexLen, bFound);
		return &(pSub->data);
	}

	wbTrie<IndexT, DataT> *FindTrie(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
	{
		if (nIndexLen == 0) {
			return this;
		}

		wbTrie<IndexT, DataT> **pSubTrie = TrieHash.Find(*p_pIndex, bFound);
		if (!bFound || !pSubTrie) {
			return NULL;
		}

		return (*pSubTrie)->FindTrie(p_pIndex+1, nIndexLen-1, bFound);
	}

	wbTrie<IndexT, DataT> *InsertTrie(IndexT *p_pIndex, int nIndexLen, bool &bFound = wbTrie::bFound)
	{
		if (nIndexLen == 0) {
			return this;
		}

		wbTrie<IndexT, DataT> **pSubTrie = TrieHash.Insert(*p_pIndex, bFound);
		if (!bFound) {
			*pSubTrie = new wbTrie<IndexT, DataT>();
		}
		return (*pSubTrie)->InsertTrie(p_pIndex+1, nIndexLen-1, bFound);
	}

public:
	static bool bFound;
};

template <class IndexT, class DataT>
bool wbTrie<IndexT,DataT>::bFound = false;


/**
 * \class
 * \brief ����Trie���ӽڵ�
 */
template <class IndexT, class DataT>
class wbTrieIter
{
public:
    wbTrieIter(wbTrie<IndexT,DataT> &trie)
	: m_Iter(&trie.TrieHash) {};

    void Init() { m_Iter.Init() } ;
    wbTrie<IndexT,DataT> *Next_1(IndexT &key) { 
		wbTrie<IndexT,DataT> **pp = m_Iter.Next(key); 
		return (pp)? *pp: NULL;
	};
	wbTrie<IndexT,DataT> *Next(IndexT &key) {
		wbTrie<IndexT,DataT> *p;
		while ( p = Next_1(key) ) {
			if ( p->IsDataLegal() )
				break;
		}
		return p;
	}

private:
    WBTRIE_LHASH_ITER m_Iter;
};

/** 
 * \class
 * \brief ����ĳ���ȵ�Index������Ԫ�أ��������صĽڵ���ܲ�����һ����Ч��data.
 */
template <class IndexT, class DataT>
class wbTrieIter2
{
public:
	wbTrieIter2(wbTrie<IndexT, DataT> &trie, IndexT *pIndex, unsigned int level)
		: m_trie(trie), m_pIndex(pIndex), m_nLevel(level),
		m_iter(trie) {
			m_pSubIter = NULL;
	};
	void Init()
	{
		m_iter.Init();
		SAFE_DELETE(m_pSubIter);
	}
	wbTrie<IndexT, DataT> *Next()
	{
		if (m_nLevel == 0) {
			return &m_trie;
		} else if (m_nLevel == 1) {
			return m_iter.Next(*m_pIndex);
		}
		
		while (1)
		{
			if (m_pSubIter == NULL) {
				wbTrie<IndexT, DataT> *pSub = m_iter.Next_1(*m_pIndex);
				if (pSub == NULL)
					return NULL;

				m_pSubIter = new wbTrieIter2<IndexT, DataT>(*pSub, m_pIndex+1, m_nLevel-1);
			}

			wbTrie<IndexT, DataT> *pNext = m_pSubIter->Next();
			if (pNext == NULL) {
				delete m_pSubIter;
				m_pSubIter = NULL;
			} else {
				return pNext;
			}
		}
		
	}

private:
	wbTrieIter<IndexT, DataT> m_iter;
	wbTrieIter2<IndexT, DataT> *m_pSubIter;
	wbTrie<IndexT, DataT> &m_trie;
	IndexT *m_pIndex;
	unsigned int m_nLevel;
};

