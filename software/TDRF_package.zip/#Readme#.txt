This toolkit implements Trans-dimensional Random Fields for Language Modeling.

The toolkit is written in C++ and licensed under the Apache License v2.0. 
It includes the following directories:

projects : the source code for the toolkit, written by C++, and can be opened by visual studio 2010 or newer version.

wbModule : the source code

tools : the exe files, for Window x64 system

PTB : the experiments for Penn Treebank corpus. See PTB/#Readme#.txt to reproduce the experiments, as reported in

	Bin Wang, Zhijian Ou and Zhiqiang Tan. 
	Trans-dimensional Random Fields for Language Modeling.
	Annual Meeting of the Association for Computational Linguistics (ACL Long Paper), Beijing, China, 2015,7.

Note that we include just a few sentences from the PTB corpus (separately for training/development/testing), NOT a complete one. If you own a licensed copy of PTB, you can email us so that we are able to provide you the corpus, which is formatted appropriately and can be directly used by the toolkit for your convenience.

Feel free to contact us if you have any questions.

Cheers,
wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
