// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// String class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#ifndef _WB_STRING_H_
#define _WB_STRING_H_
#include <string.h>

#define DEFAULE_STR_LEN 100
#define DEFAULE_MAX_LEN 32*1024

class wbString
{
private:
	char *m_pBuffer;
	int m_nBufSize;

	char *m_tokPtr; //����tokָ��
public:
	wbString(int p_nLen = DEFAULE_STR_LEN) { m_nBufSize = p_nLen+1; m_pBuffer = new char[m_nBufSize]; m_pBuffer[0] = '\0'; }
	wbString(const char *p_str) { m_nBufSize = strlen(p_str)+1; m_pBuffer = new char[m_nBufSize]; memcpy(m_pBuffer, p_str, m_nBufSize); }
	wbString(const char* p_str, int nLen) { 
		if (nLen <=0) { m_pBuffer=NULL; ResetBuffer(1); m_pBuffer[0]='\0'; return; }
		m_nBufSize = nLen+1; m_pBuffer = new char[m_nBufSize]; memcpy(m_pBuffer, p_str, nLen); m_pBuffer[nLen] = '\0'; 
	}
	wbString(const wbString &p_str) { m_nBufSize = p_str.m_nBufSize; m_pBuffer = new char[m_nBufSize]; memcpy(m_pBuffer, p_str.m_pBuffer, m_nBufSize);}
	~wbString() { delete [] m_pBuffer; }

	char *GetBuffer() const { return m_pBuffer; }
	char *End() const {return m_pBuffer+strlen(m_pBuffer)-1; }  //�������һ���ַ�ָ��
	int GetSize() const { return m_nBufSize; }
	int GetLength() const { return strlen(m_pBuffer); }
	
	void Clean() { m_pBuffer[0] = '\0'; }
	/*
	�����������ͷ�ԭ���ռ䣬�����¿ռ�
	*/
	char* ResetBuffer( int p_nBufSize )
	{
		if (m_pBuffer != NULL)
			delete [] m_pBuffer;
		m_nBufSize = p_nBufSize;
		m_pBuffer = new char[m_nBufSize];
		return m_pBuffer;
	}

	/*
	�ı�ռ��С�������ܶ�ı���ԭ������
	�ռ������ַ������ݱ������ռ��С�����ȡǰ��һ���ַ���.
	*/
	char* ModifyBuffer( int p_nBufSize )
	{
		char *pNew = new char[p_nBufSize];
		if (m_pBuffer != NULL)
		{
			memcpy(pNew, m_pBuffer, min(m_nBufSize, p_nBufSize)-1);
			pNew[min(m_nBufSize, p_nBufSize)-1] = '\0';
			delete [] m_pBuffer;
			m_pBuffer = pNew;
		}
		else
		{
			pNew[0] = '\0';
			m_pBuffer = pNew;
		}

		m_nBufSize = p_nBufSize;

		return m_pBuffer;
	}

	/*
	ȷ���ڴ�ռ��㹻, ����������
	��p_nBufSizeС�������ڴ棬�����κδ�����
	��p_nBufSize���������ڴ棬����ModifyBuffer���¿��٣�ͬʱ����ԭ������
	*/
	char* InsureBuffer( int p_nBufSize )
	{
		if (p_nBufSize > m_nBufSize)
			ModifyBuffer(p_nBufSize);

		return m_pBuffer;
	}

	void Format( const char* p_pMessage,... )
	{
		char strBuffer[DEFAULE_MAX_LEN];
		va_list vaParams;
		va_start(vaParams,p_pMessage);

		_vsnprintf(strBuffer,DEFAULE_MAX_LEN,p_pMessage,vaParams);

		int nLen = strlen(strBuffer);
		ResetBuffer( nLen+1 );
		memcpy(m_pBuffer, strBuffer, sizeof(char)*(nLen+1));
	}

	void operator = (const wbString &p_str)
	{
		if (m_nBufSize < p_str.m_nBufSize)
			ResetBuffer(p_str.m_nBufSize);
		memcpy(m_pBuffer, p_str.m_pBuffer, p_str.m_nBufSize);
	}

	void operator = (const char *pStr)
	{
		int nLen = strlen(pStr);
		if (m_nBufSize < nLen+1)
			ResetBuffer(nLen+1);
		memcpy(m_pBuffer, pStr, nLen+1);
	}
	
	operator char*() const { return m_pBuffer; }
	char &operator[] (int i) const { return m_pBuffer[i]; }

	bool operator > (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) > 0; }
	bool operator < (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) < 0; }
	bool operator >= (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) >= 0; }
	bool operator <= (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) <= 0; }
	bool operator == (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) == 0; }
	bool operator != (const wbString &p_str) { return strcmp(m_pBuffer, p_str.m_pBuffer) != 0; }
	wbString operator += (const wbString &str) { strcat(InsureBuffer(strlen(m_pBuffer) + strlen(str) + 1), str.m_pBuffer); return *this;}

	bool operator > (const char *p) { return strcmp(m_pBuffer, p) > 0; }
	bool operator < (const char *p) { return strcmp(m_pBuffer, p) < 0; }
	bool operator >= (const char *p) { return strcmp(m_pBuffer, p) >= 0; }
	bool operator <= (const char *p) { return strcmp(m_pBuffer, p) <= 0; }
	bool operator == (const char *p) { return strcmp(m_pBuffer, p) == 0; }
	bool operator != (const char *p) { return strcmp(m_pBuffer, p) != 0; }
	wbString operator += (const char *p) { strcat(InsureBuffer(strlen(m_pBuffer) + strlen(p) + 1), p); return *this; }
	
	friend wbString operator + (const wbString &str, const char *p) { 
		return wbString(str) += p; 
	}
	friend wbString operator + (const char *p, const wbString &str) { 
		return wbString(p) += str;
	}
	friend wbString operator + (const wbString &str1, const wbString &str2) {
		return wbString(str1) += str2;
	}
	/// ת��Ϊ��д��ĸ
	char *Toupper() { return strupr(m_pBuffer); }
	/// ת��ΪСд��ĸ
	char *Tolower() { return strlwr(m_pBuffer); }

	// һЩ�ϸ��ӵĲ���
	//ɾ��
	void DeleteSub(int nLocal, int nLen)
	{
		m_pBuffer[nLocal] = '\0';
		*this += m_pBuffer + nLocal + nLen;
	}
	//���룬��nLocalλ�ÿ�ʼ�������ַ�����ʣ���Դ�����
// 	void Insert(int nLocal, const char *pSrt)
// 	{
// 
// 	}

	//�з�
	inline char *TokBegin(const char *p)
	{
		m_tokPtr = m_pBuffer;
		return TokSub(p);
	}
	inline char *TokSub(const char *p)
	{
		if (*m_tokPtr == '\0')
			return NULL;

		char *pBeg = NULL;
		for(; *m_tokPtr != '\0'; m_tokPtr++) 
		{
			if (pBeg == NULL) {
				//�ҵ���ʼ��
				if (NULL == strchr(p, *m_tokPtr)) {
					pBeg = m_tokPtr;
				}
			} else {
				//�ҵ�������
				if ( strchr(p, *m_tokPtr) ) {
					*m_tokPtr = '\0';
					m_tokPtr++;
					break;
				}
			}
		}
		
		return pBeg;
	}

	/// �����ļ���
	wbString FileName()
	{
		char *p = strrchr(m_pBuffer, '.');
		if (p)
			return wbString(m_pBuffer, p-m_pBuffer);
		return wbString(m_pBuffer);
	}
};


#endif