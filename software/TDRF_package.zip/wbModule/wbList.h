// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// List class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#ifndef _WB_LIST_H_
#define _WB_LIST_H_
#include "wbSystem.h"

template <typename T, typename W>
class _wb_LIST_NODE_
{
public:
	T m;	//��Ա
	W w;	//Ȩ��,��������
	unsigned int n;	//��¼�ظ�����
	_wb_LIST_NODE_ *next; 
	_wb_LIST_NODE_ *prev;
	_wb_LIST_NODE_(T p_m=0, W p_w=0, _wb_LIST_NODE_ *p_prev=NULL, _wb_LIST_NODE_ *p_next=NULL):m(p_m),w(p_w)
	{
		n = 1;
		next = p_next;
		prev = p_prev;
	}
};




//================list����======================
typedef unsigned short _wb_LIST_MODE_;
//��������<ֻ��ѡ��һ>
#define LISTMODE_NOSORT	0x0001		//default
#define LISTMODE_INCREASE	0x0002	//��С����
#define LISTMODE_DECREASE	0x0004	//�Ӵ�С
#define LISTMODE_SELFDEF	0x0040	//�Զ���
//����wֵ��ȵ����
#define LISTMODE_IGNORE	0x0008	//Ignore
#define LISTMODE_ADD	0x0010	//�����µĽڵ�
#define LISTMODE_SUM	0x0020	//��ǳ��ִ���




template <typename T, typename W>

class wbList
{
private:
	_wb_LIST_NODE_<T, W> *m_pHead;//ͷ����һ����ʱ�ڵ�
	_wb_LIST_NODE_<T, W> *m_pTail;//β����һ����ʱ�ڵ�
	int m_nNum;				//Ԫ������

	_wb_LIST_MODE_ m_mode;	//ģʽ
	bool (*m_funpCompare)(W,W); //comp�����Ĺ����ǣ�������ture���������������������false������뵽p_nExist�ڵ�֮ǰ

	//��������
	_wb_LIST_NODE_<T, W> *m_pCurNode;	//������ǰָ��
	bool m_bPrev;				//�Ƿ���ǰ������Ĭ��������
public:
	wbList( _wb_LIST_MODE_ mode = LISTMODE_NOSORT | LISTMODE_IGNORE )
	{
		m_nNum = 0;
		m_pHead = 0;
		m_pTail = 0;
		m_mode = mode;
		m_funpCompare = NULL;

		m_pCurNode = NULL;
		m_bPrev = false;
		Init();

		if (m_mode & LISTMODE_NOSORT)
			m_funpCompare = NosortCompare;
		if (m_mode & LISTMODE_INCREASE)
			m_funpCompare = IncreaseCompare;
		if (m_mode & LISTMODE_DECREASE)
			m_funpCompare = DecreaseCompare;
	}
	~wbList()
	{
		Release();
	}

	void Init() //��ʼ������
	{
		if (m_pHead == NULL)
			m_pHead = new _wb_LIST_NODE_<T,W>;
		if (m_pTail == NULL)
			m_pTail = new _wb_LIST_NODE_<T,W>;

		m_pHead->next = m_pTail;
		m_pTail->prev = m_pHead;
		m_nNum = 0;
	}

	void Release() //�ͷſռ�
	{
		while (m_pHead != NULL)
		{
			_wb_LIST_NODE_<T, W> *p = m_pHead;
			m_pHead = m_pHead->next;
			delete p;
		}
		m_pHead = NULL;
		m_pTail = NULL;
		m_nNum = 0;
	}

	void Reset() //��������
	{
		Release();
		Init();
	}

public:
	void SetMode( _wb_LIST_MODE_ mode ) { m_mode = mode; }
	bool IsEmpty() const { return m_pHead->next == m_pTail; }
public:
	_wb_LIST_MODE_ GetMode() const { return m_mode; }
	int GetNum() const { return m_nNum; }
	_wb_LIST_NODE_<T,W>* GetHead() const { return m_pHead; }
	_wb_LIST_NODE_<T,W>* GetTail() const { return m_pTail; }
	_wb_LIST_NODE_<T,W>* GetCur() const { return m_pCurNode; }
	
public:
	//���ң����ҿ�ʼ�㣬������ʼ�ڵ㡣
	//���ң�������Ŀ��������Ǹ��ڵ�
	bool Find(W &p_w, _wb_LIST_NODE_<T,W> *&p_pFindNode, _wb_LIST_NODE_<T,W> *p_pBegNode = NULL)
	{
		if (p_pBegNode == NULL)
			p_pBegNode = m_pHead->next;

		

		_wb_LIST_NODE_<T,W> *pCurNode = p_pBegNode;
		while (pCurNode != m_pTail && m_funpCompare(p_w, pCurNode->w))
		{
			if (p_w == pCurNode->w)
			{
				p_pFindNode = pCurNode;
				return true;
			}
			pCurNode = pCurNode->next;
		}
		p_pFindNode = pCurNode;
		return false;
	}
	//���ң���û���ҵ����򷵻�false�����ҵ���ͨ��ָ�뷵������
	bool Find(W &p_w, T *p_pT, int *p_pN, _wb_LIST_NODE_<T,W> *p_pBegNode = NULL)
	{
		_wb_LIST_NODE_<T,W> *pFindNode = NULL;
		if (true == Find(p_w, pFindNode, p_pBegNode))
		{
			if (p_pT) *p_pT = pFindNode->m;
			if (p_pN) *p_pN = pFindNode->n;
			return true;
		}
		return false;
	}

	_wb_LIST_NODE_<T,W>* Insert(T p_T, W p_w, int p_N = 1)
	{
		_wb_LIST_NODE_<T,W> *pFindNode = NULL;
	
		if (m_mode & LISTMODE_NOSORT)
			pFindNode = m_pTail;

		else if (true == Find(p_w, pFindNode)) //�����ظ�
		{
			if (m_mode & LISTMODE_IGNORE)
			{
				return pFindNode;
			}
			if (m_mode & LISTMODE_ADD)
			{
				//��������
			}
			if (m_mode & LISTMODE_SUM)
			{
				pFindNode->n += p_N;
				return pFindNode;
			}
		}
		
		//����
		return InsertPrev(pFindNode, p_T, p_w);
	}

	_wb_LIST_NODE_<T,W>* InsertHead(T p_T, W p_w)
	{
		return InsertNext(m_pHead, p_T, p_w);
	}
	_wb_LIST_NODE_<T,W>* InsertTail(T p_T, W p_w)
	{
		return InsertPrev(m_pTail, p_T, p_w);
	}

	_wb_LIST_NODE_<T,W>* InsertNext(_wb_LIST_NODE_<T,W> *p_pNode, T p_T, W p_w)
	{
		if (p_pNode == m_pTail || p_pNode == NULL)
			return NULL;
		_wb_LIST_NODE_<T,W> *pNew = new _wb_LIST_NODE_<T,W>(p_T, p_w, p_pNode, p_pNode->next);
		p_pNode->next->prev = pNew;
		p_pNode->next = pNew;
		m_nNum++;

		return pNew;
	}
	_wb_LIST_NODE_<T,W>* InsertPrev(_wb_LIST_NODE_<T,W> *p_pNode, T p_T, W p_w)
	{
		if (p_pNode == m_pHead || p_pNode == NULL)
			return NULL;
		_wb_LIST_NODE_<T,W> *pNew = new _wb_LIST_NODE_<T,W>(p_T, p_w, p_pNode->prev, p_pNode);
		p_pNode->prev->next = pNew;
		p_pNode->prev = pNew;
		m_nNum++;

		return pNew;
	}

	void Delete(W p_w)
	{
		_wb_LIST_NODE_<T,W> *pFindNode = NULL;
		if (true == Find(p_w, pFindNode))
		{
			Delete(pFindNode);
		}
	}
	void Delete(_wb_LIST_NODE_<T,W> *p_pNode)
	{
		if (p_pNode == NULL)
			return;
		_wb_LIST_NODE_<T,W> *pPrev = p_pNode->prev;
		_wb_LIST_NODE_<T,W> *pNext = p_pNode->next;
		pPrev->next = pNext;
		pNext->prev = pPrev;
		delete p_pNode;
		m_nNum--;
	}

	//����, ��Begin��ʼ����������Begin�ڵ�
	bool TraverseBegin(_wb_LIST_NODE_<T,W> *p_pBegin = NULL, bool p_bPrev = false)
	{
		if (p_pBegin == NULL)
			p_pBegin = m_pHead->next;

		m_pCurNode = p_pBegin;
		m_bPrev = p_bPrev;

		if (m_pHead == m_pTail)
			return false;
		return true;
	}
	//����m_pCurNodeָ����ָ���ݣ���m_pCurNodeָ��ָ����һ��
	_wb_LIST_NODE_<T,W>* TraverseNext(T *p_pT = NULL, W *p_pW = NULL, int *p_pNum = NULL)
	{
		if (m_pCurNode == NULL)
			return NULL;
		
		_wb_LIST_NODE_<T,W> *pReturn = m_pCurNode;
		if (!m_bPrev)
		{
			if (m_pCurNode == m_pTail)
				return false;
			if (p_pT) *p_pT = m_pCurNode->m;
			if (p_pW) *p_pW = m_pCurNode->w;
			if (p_pNum) *p_pNum = m_pCurNode->n;
			m_pCurNode = m_pCurNode->next;
		}
		else
		{
			if (m_pCurNode == m_pHead)
				return false;
			if (p_pT) *p_pT = m_pCurNode->m;
			if (p_pW) *p_pW = m_pCurNode->w;
			if (p_pNum) *p_pNum = m_pCurNode->n;
			m_pCurNode = m_pCurNode->prev;
		}
		return pReturn;
	}



private:
	static bool IncreaseCompare(W p_nNew, W p_nExist) { return p_nNew >= p_nExist; }
	static bool DecreaseCompare(W p_nNew, W p_nExist) { return p_nNew <= p_nExist; }
	static bool NosortCompare(W p_nNew, W p_nExist) { return true; }
};

template <typename T, typename W>
bool ListMerge(wbList<T,W> *pDestList, wbList<T,W> *pSrcList)
{
	if (pDestList == NULL || pSrcList == NULL)
		return false;
	
	T t;
	W w;
	int N;
	pSrcList->TraverseBegin();
	while (pSrcList->TraverseNext(&t, &w, &N))
		pDestList->Insert(t, w, N);

	return true;
}

#endif