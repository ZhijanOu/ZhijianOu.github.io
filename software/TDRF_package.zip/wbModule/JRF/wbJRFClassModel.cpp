// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// class-based TDRF models.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFClassModel.h"

namespace wbJRF
{
// 	void ClassModel_len::ClassOn()
// 	{
// 		//���������
// 		sv_bContainJumpNgram = m_bContainJumpNgram;
// 		sv_bContainTokenGram = m_bContainTokenGram;
// 		sv_bContainClassGram = m_bContainClassGram;
// 		sv_bContainWordGram = m_bContainWordGram;
// 		sv_bContainPredictGram = m_bContainPredictGram;
// 		sv_bContainMixGram = m_bContainMixGram;
// 
// 		m_bContainJumpNgram = false;
// 		m_bContainTokenGram = false;
// 		m_bContainClassGram = true;  //��class��ȫ����Ϊfalse
// 		m_bContainWordGram = false;
// 		m_bContainPredictGram = false;
// 		m_bContainMixGram = false;
// 	}
// 	void ClassModel_len::ExceptClassOn()
// 	{
// 		//���������
// 		sv_bContainJumpNgram = m_bContainJumpNgram;
// 		sv_bContainTokenGram = m_bContainTokenGram;
// 		sv_bContainClassGram = m_bContainClassGram;
// 		sv_bContainWordGram = m_bContainWordGram;
// 		sv_bContainPredictGram = m_bContainPredictGram;
// 		sv_bContainMixGram = m_bContainMixGram;
// 
// 	
// 		m_bContainClassGram = false;  
// 	}
// 	void ClassModel_len::Off()
// 	{
// 		//��ԭ���
// 		m_bContainJumpNgram = sv_bContainJumpNgram;
// 		m_bContainTokenGram = sv_bContainTokenGram;
// 		m_bContainClassGram = sv_bContainClassGram;
// 		m_bContainWordGram = sv_bContainWordGram;
// 		m_bContainPredictGram = sv_bContainPredictGram;
// 		m_bContainMixGram = sv_bContainMixGram;
// 	}


 	LogP ClassModel_len::GibbsSample(VocabID *pSeq, int nLen, int pos, bool bSample /* = true */)
	{
		VocabID svToken = -1;
		VocabID svClass = -1;
		int svTokenIndex = -1; 
		if ( !bSample ) {
			svToken = pSeq[pos];
			svClass = m_pVocab->aVocabInfo[svToken].cid;
		}

		
		//����class�ĸ���
		wbArray<Prob> aJumpProb(m_pVocab->nClassIdTop);
		ClassProposal(aJumpProb, pSeq, nLen, pos);

		//sample Class 
		if ( bSample ) {
			svClass = LineSampling(aJumpProb, m_pVocab->nClassIdTop);
		}

		wbArray<VocabID> *pTokens = &m_pVocab->aClassToTokens[svClass];
		wbArray<LogP> aTokenProbs(pTokens->GetNum());
		for (int i=0; i<pTokens->GetNum(); i++) {
			pSeq[pos] = pTokens->Get(i);
			aTokenProbs[i] = GetWeightSum(pSeq, nLen, pos);
		}
		LogLineNormalize(aTokenProbs, aTokenProbs.GetNum());

		//Sample Token
		if ( bSample ) {
			svTokenIndex = LogLineSampling(aTokenProbs, aTokenProbs.GetNum());
			svToken = pTokens->Get(svTokenIndex);
		}

		pSeq[pos] = svToken; //��ԭ
		
		//ȷ��svToken��pTokenProb�е�λ�� 
		if ( svTokenIndex == -1 ) {
			for (int i=0; i<pTokens->GetNum(); i++) {
				if ( pTokens->Get(i) == svToken )  {
					svTokenIndex = i;
					break;
				}
			}
		}
		lout_assert(svTokenIndex >= 0);

		return Prob2LogP( aJumpProb[svClass] ) + aTokenProbs[svTokenIndex];
 	}

	void ClassModel_len::FindFeatures_class(wbArray<int> &a, VocabID *pSeq, int nLen, int h, int nOrder, int tagPos)
	{
		VocabID aIndex[ngram_maxOrder];
		bool bFound;
		wbArray<int> **ppFind = NULL;
		wbArray<wbArray<int>**> aFindList;

		// Class Gram ����
		if (m_bContainClassGram)
		{
			for (int i=0; i<nOrder; i++)
				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;

			if ( nOrder < m_nFullGramLimitedOrder ) {
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
			}


			//class gram ����jump��Ϣ
			if ( m_bContainClassGram_jump && nOrder >= 3 ) 
			{
				FindJumpFeatures(aFindList, aIndex, nOrder);
			}
		}

		// model M�еĻ������
		// ��ʷȫ����word����ǰλ�ÿ���Ϊclass or token����f(w,c) or f(w, cw)
		if (m_bContainPredictGram && nOrder < m_nFullGramLimitedOrder && h+nOrder-1 == tagPos)
		{
			for (int i=0; i<nOrder-1; i++)
				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset; //��ʷȫ��Ϊword

			// f(w,c)
			if (nOrder > 1 || m_bContainClassGram==false) { //��order=1ʱ�������������˻�Ϊunigram-class��������ʹ��ͬһ��������������
				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].cid + m_nClassIndexOffset;
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
			}

			// f(w,cw)
			aIndex[nOrder-1] = pSeq[h+nOrder-1];
			ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
			if (ppFind) {
				aFindList.Add(ppFind);
			}
		}

		//global gram
		//Ŀǰ��֧��ͬһλ�ò���ͬʱ����word��class��Ϣ,�ҽ���һ��classλ��
		//����order < m_nFullGramLimitedOrder ����������
		if (m_bContainMixGram && nOrder>1 && nOrder < m_nFullGramLimitedOrder)
		{
			/// f(c,c,c,w)
			if ( m_bContainMixGram_cpw  && h+nOrder-1 != tagPos) 
			{
				for (int i=0; i<nOrder-1; i++)
					aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].wid + m_nWordIndexOffset;
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
				/// Add  Jump����
				if ( m_bContainMixGram_cpw_jump && nOrder >= 3 ) {
					FindJumpFeatures(aFindList, aIndex, nOrder);
				}
			} else if (m_bContainMixGram_wpc ) {
				lout_error("m_bContainMixGram_wpc ���ܻ���PredictNgram���ͻ������");
			}
			else
			{
				//�ἤ���������
				int pos = tagPos - h;
				//for (int pos=0; pos<nOrder; pos++) //����class��λ��
				{
					for (int i=0; i<nOrder; i++) {
						if ( i != pos ) {//word��Ϣ
							aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
						} else { // class��Ϣ
							aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
						}
					}
					ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
					if (ppFind) {
						aFindList.Add(ppFind);
					}
				}
			}

		}
// 		if (m_bContainMixGram && nOrder>1)
// 		{
// 			//�ἤ���������
// 			int pos = tagPos - h;
// 			//for (int pos=0; pos<nOrder; pos++) //����class��λ��
// 			{
// 
// 				for (int i=0; i<nOrder; i++) {
// 					if ( i != pos ) {//word��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 					} else { // class��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
// 					}
// 				}
// 				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 				if (ppFind) {
// 					aFindList.Add(ppFind);
// 				}
// 			}
// 		}

		//�����ҵ�����������
		for (int n=0; n<aFindList.GetNum(); n++) {
			ppFind = aFindList[n];
			for (int i=0; i<(*ppFind)->GetNum(); i++) {
				int id = (*ppFind)->Get(i);
				if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h)) {
					a.Add(id);
				}
			}
		}
	}
	LogP ClassModel_len::GetWeightSum_class(VocabID *pSeq, int nLen, int nPos)
	{
		LogP logprob = 0;
		wbArray<int> aFeatrues;

		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			for (int h=max(nPos-nOrder+1,0); h<=min(nPos,nLen-nOrder); h++) {
				aFeatrues.Clean();
				FindFeatures_class(aFeatrues, pSeq, nLen, h, nOrder, nPos);
				for (int i=0; i<aFeatrues.GetNum(); i++) {
					logprob += m_aValues[aFeatrues[i]];
				}
			}
		}

		return logprob;
	}
	void ClassModel_len::ClassProposal(Prob *pJumpProb, VocabID *pSeq, int nLen, int nPos)
	{
		for (int c=0; c<m_pVocab->nClassIdTop; c++) {
			wbArray<int> *pTokens = &m_pVocab->aClassToTokens[c];
			if ( pTokens->GetNum() > 0 ) {
				pSeq[nPos] = pTokens->Get(0);
				pJumpProb[c] = LogP2Prob( GetWeightSum_class(pSeq, nLen, nPos) );
			} else {
				pJumpProb[c] = 0;
			}
		}
		LineNormalize(pJumpProb, m_pVocab->nClassIdTop);

// 		for (int c=0; c<m_pVocab->nClassIdTop; c++)
// 			pJumpProb[c] = 1.0 / (m_pVocab->nClassIdTop);

// 		for (int c=0; c<m_pVocab->nClassIdTop; c++)
// 			pJumpProb[c] = m_pClassProb->Get(nLen, nPos)->Get(c);
	}
	void ClassModel_len::OneGibbsSample(VocabID *pSeq, int nLen, int pos)
	{
		VocabID svToken = -1;
		VocabID svClass = -1;
		svToken = pSeq[pos];
		svClass = m_pVocab->aVocabInfo[svToken].cid;

		wbArray<VocabID> *pClassTokens = NULL;  //��������class��Ӧ��Token�б�
		wbArray<LogP> *pTokenProbs = NULL; //����������Ҫ������TokenProb
		
		//����class�ĸ���
		wbArray<Prob> aJumpProb(m_pVocab->nClassIdTop);
		ClassProposal(aJumpProb, pSeq, nLen, pos);
		VocabID newClass = LineSampling(aJumpProb, m_pVocab->nClassIdTop);

		wbArray<VocabID> *pNewTokens = &m_pVocab->aClassToTokens[newClass];
		wbArray<VocabID> *pOldTokens = &m_pVocab->aClassToTokens[svClass];
		wbArray<LogP> aNewProbs(pNewTokens->GetNum()+1);
		wbArray<LogP> aOldProbs(pOldTokens->GetNum()+1);
		LogP newClassProb, oldClassProb;

		for (int i=0; i<pOldTokens->GetNum(); i++) {
			pSeq[pos] = pOldTokens->Get(i);
			aOldProbs[i] = GetWeightSum(pSeq, nLen, pos);
		}
		oldClassProb = LogLineNormalize(aOldProbs, pOldTokens->GetNum());
		pClassTokens = pOldTokens;
		pTokenProbs = &aOldProbs;

		if ( newClass != svClass ) {
			
			for (int i=0; i<pNewTokens->GetNum(); i++) {
				pSeq[pos] = pNewTokens->Get(i);
				aNewProbs[i] = GetWeightSum(pSeq, nLen, pos);
			}
			newClassProb = LogLineNormalize(aNewProbs, pNewTokens->GetNum());
			
			double accProb = LogP2Prob( newClassProb - oldClassProb ) * aJumpProb[svClass] / aJumpProb[newClass];
			if ( Acceptable(accProb) ) {
				svClass = newClass;
				pClassTokens = pNewTokens;
				pTokenProbs = &aNewProbs;

				m_nClassAccept++;
			}
		}
		
		m_nClassTotal++;
		if ( m_nClassTotal > INT_MAX /2 ) {
			m_nClassTotal = 1;
			m_nClassAccept = 0;
		}
		

		//����word�ĸ���
		//LogLineNormalize(pTokenProbs->GetBuffer(), pClassTokens->GetNum());
		int svTokenIndex = LogLineSampling(pTokenProbs->GetBuffer(), pClassTokens->GetNum());
		svToken = pClassTokens->Get(svTokenIndex);
		
		lout_assert( svTokenIndex >= 0 );
		pSeq[pos] = svToken; //��ԭ
	}

	void ClassModel_len::OneSampling(VocabID *pSeq, int &nLen)
	{
		//return OneSamplingEx(pSeq, nLen);


		/// Local Jump
		int nNextLen = LineSampling(m_pLenJumpProb[nLen], m_nMaxLen+1);
		if (nNextLen > nLen) {
			LogP p1 = GetLogProb(pSeq, nLen);
			LogP g = g_Sampling(pSeq, nLen, nNextLen-nLen);  //���л����GibbsSample
			LogP p2 = GetLogProb(pSeq, nNextLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p2-p1-g ); 

			if (Acceptable(accProb)) {
				nLen = nNextLen;
				m_nJumpAccept++;
			}
		} else if (nNextLen < nLen) {
			LogP p1 = GetLogProb(pSeq, nLen);
			LogP g = g_LogProb(pSeq, nNextLen, nLen-nNextLen);
			LogP p2 = GetLogProb(pSeq, nNextLen);
			Prob accProb = m_pLenJumpProb[nNextLen][nLen]/m_pLenJumpProb[nLen][nNextLen] * LogP2Prob( p2+g-p1 ); 

			if (Acceptable(accProb)) {
				nLen = nNextLen;
				m_nJumpAccept++;
			}
		}
		m_nJumpTotal++;
		if ( m_nJumpTotal > INT_MAX /2 ) {
			m_nJumpTotal = 1;
			m_nJumpAccept = 0;
		}

		/// Gibbs Sampling
		//for (int i=0; i<m_nClassGibbsTimes; i++)
			GibbsSample(pSeq, nLen);
	}

	void ClassModel_len::GibbsSample(VocabID *pSeq, int nLen)
	{
		//wbArray<Prob> aProbs(m_pVocab->nSize); //����һά�ֲ�

		wbArray<int> aPos(nLen+1); ///��¼������λ��
		for (int i=0; i<nLen; i++)
			aPos[i] = i;
		int nPos = (m_opt_samplePos>=0)? min(m_opt_samplePos, nLen): nLen;

		if (nPos < nLen) { //���������λ��
			RandomPos(aPos, nLen, nPos );
		} 


		for (int t=0; t<m_nClassGibbsTimes; t++)
		{
			/// Gibbs Sampling
			//����Ҫ��λ�ý���һ��GibbsSampling
			for (int n=0; n<nPos; n++) {
				int h = aPos[n];
				OneGibbsSample(pSeq, nLen, h);
			}
		}
	}
}