// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// control the CMD window.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbConsole.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
wbSmallRect::wbSmallRect()
{
	Left = 0;
	Top = 0;
	Right = 0;
	Bottom = 0;
}
wbSmallRect::wbSmallRect(short l, short t, short r, short b)
{
	Left = l;
	Top = t;
	Right = r;
	Bottom = b;
}
wbSmallRect::wbSmallRect(COORD coord, short width, short height)
{
	Left = coord.X;
	Top = coord.Y;
	Right = Left + width;
	Bottom = Right + height;
}
wbSmallRect::wbSmallRect(SMALL_RECT &rect)
{
	Left = rect.Left;
	Top = rect.Top;
	Right = rect.Right;
	Bottom = rect.Bottom;
}

wbStdOutBlock::wbStdOutBlock(HANDLE h, wbSmallRect *rect):m_rect(*rect)
{
	m_hStdOut = h;

	m_cursor.X = 0;
	m_cursor.Y = 0;

	m_pBuffer = new char[rect->Area()];
	memset(m_pBuffer, CHAR_SPACE, sizeof(char)*rect->Area());

	m_pCellListHead = NULL;
	m_pCellListTail = NULL;

	m_wAttribute = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
}

wbStdOutBlock::~wbStdOutBlock()
{
	delete []m_pBuffer;

	while(m_pCellListHead)
	{
		wbCell *p = m_pCellListHead;
		m_pCellListHead = m_pCellListHead->pNext;
		delete p;
	}
}


void wbStdOutBlock::Printf(const char *format, ...)
{
	char strBuffer[TS_SENTENCE_LEN];
	va_list vaParams;
	va_start(vaParams,format);

	_vsnprintf(strBuffer,TS_SENTENCE_LEN,format,vaParams);
	
	Puts(strBuffer);

	return;
}

void wbStdOutBlock::Puts(const char *strBuffer)
{
	StrProcess(strBuffer);

	const char* pSubStr = NULL;
	unsigned short snLen = 0;
	while (CellListOut(pSubStr, snLen))
	{
		short nNewLine = 0;
		short nCurLineSpace = m_rect.Width() - m_cursor.X;
		short nNewLineChar = (nCurLineSpace > snLen)? 0: snLen-nCurLineSpace;
		switch(*pSubStr)
		{
		case '\n':
			PushLine(2);
			m_cursor.X = 0;
			m_cursor.Y ++;
			break;
		case '\t':
			PushLine(1);
			if (m_cursor.X < m_rect.Width())
			{
				*BufferLocation(m_cursor.Y, m_cursor.X) = CHAR_SPACE;
				m_cursor.X++;
			}
			break;
		case '\b':
			PushLine(1);
			if (m_cursor.X > 0)
			{
				m_cursor.X--;
				*BufferLocation(m_cursor.Y, m_cursor.X) = CHAR_SPACE;
			}
			break;
		default:
			nNewLine = nNewLineChar/m_rect.Width() + ((nNewLineChar%m_rect.Width() > 0)? 1:0);
			PushLine(nNewLine+1);

			memcpy(BufferLocation(m_cursor.Y, m_cursor.X), pSubStr, snLen*sizeof(char));

			m_cursor.X = (nNewLine>0)? nNewLineChar%m_rect.Width(): m_cursor.X + snLen;
			m_cursor.Y += nNewLine;
		}
	}


	DisplayBuffer();
}

void wbStdOutBlock::FillChar(char c)
{
	memset(m_pBuffer, c, sizeof(char)*m_rect.Area());
	DisplayBuffer();
}

void wbStdOutBlock::PushLine(int nLineNum)
{
	int width = m_rect.Width();
	int height = m_rect.Height();

	if (m_cursor.Y + nLineNum <= height)
		return;

	int nMove = m_cursor.Y + nLineNum - height;
	if (nMove > height)
		nMove = height;

	for (int i=0; i<height-nMove; i++)
		memcpy(BufferLocation(i), BufferLocation(i+nMove), width*sizeof(char));

	
	memset(BufferLocation(height-nMove), CHAR_SPACE, nMove*width*sizeof(char));
	m_cursor.Y -= nMove;
}

void wbStdOutBlock::DisplayBuffer()
{
	COORD pos;
	pos.X = m_rect.Left;
	pos.Y = m_rect.Top;

	DWORD n;
	for (int i=0; i<m_rect.Height(); i++)
	{
		//FillConsoleOutputAttribute(m_hStdOut, m_wAttribute, m_rect.Width(), pos, &n);
		WriteConsoleOutputCharacter(m_hStdOut, BufferLocation(pos.Y-m_rect.Top), m_rect.Width(), pos, &n);
		pos.Y ++;
	}
	
	return;
}

void wbStdOutBlock::FillAttribute()
{
	COORD pos;
	pos.X = m_rect.Left;
	pos.Y = m_rect.Top;

	DWORD n;
	for (int i=0; i<m_rect.Height(); i++)
	{
		FillConsoleOutputAttribute(m_hStdOut, m_wAttribute, m_rect.Width(), pos, &n);
		pos.Y ++;
	}
}

char* wbStdOutBlock::BufferLocation(short row, short col /* = 0 */)
{
	return m_pBuffer + row * m_rect.Width() + col;
}

bool wbStdOutBlock::StrProcess(const char *pStr)
{
	if (pStr == NULL)
		return false;

	CellListClean();
	const char *pHead = pStr;
	while (*pStr != '\0')
	{
		if (*pStr == '\n' || *pStr == '\t' || *pStr == '\b')
		{
			if (pStr != pHead)
				CellListIn( pHead, (unsigned short)(pStr-pHead) );
			CellListIn( pStr, 1 );
			pHead = pStr+1;
		}
		pStr++;
	}
	if (pStr != pHead)
		CellListIn( pHead, (unsigned short)(pStr-pHead) );

	return true;
}

void wbStdOutBlock::CellListClean()
{
	while (m_pCellListHead != NULL)
	{
		wbCell *p = m_pCellListHead;
		m_pCellListHead = m_pCellListHead->pNext;
		delete p;
	}
	m_pCellListHead = NULL;
	m_pCellListTail = NULL;
}

void wbStdOutBlock::CellListIn(const char *pStr, unsigned short snLen)
{
	wbCell *p = new wbCell;
	p->pStr = pStr;
	p->nLen = snLen;
	p->pNext = NULL;

	if (m_pCellListHead == NULL)
	{
		m_pCellListHead = p;
		m_pCellListTail = p;
	}
	else
	{
		m_pCellListTail->pNext = p;
		m_pCellListTail = p;
	}
}

bool wbStdOutBlock::CellListOut(const char *&pStr, unsigned short &snLen)
{
	if (m_pCellListHead == NULL)
		return false;

	pStr = m_pCellListHead->pStr;
	snLen = m_pCellListHead->nLen;

	wbCell *p = m_pCellListHead;
	m_pCellListHead = m_pCellListHead->pNext;
	delete p;

	if (m_pCellListHead == NULL)
		m_pCellListTail = NULL;
	return true;
}


wbStdOutMager::wbStdOutMager(int nRow, int nCol, int nRowWidth, int nColWidth, bool bMain)
{
	m_nNum = nRow * nCol;
	
	COORD bufSize;
	bufSize.Y = nRow * nRowWidth;
	bufSize.X = nCol * nColWidth;

	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	wbStdOutBlock** pSubBlock = NULL;

	if (bMain)
	{
		m_nNum++;
		bufSize.Y += nRowWidth;
		m_pStdOutBlock = new wbStdOutBlock *[m_nNum];
		pSubBlock = m_pStdOutBlock+1;

		wbSmallRect rect(0, bufSize.Y - nRowWidth, bufSize.X, bufSize.Y);
		m_pStdOutBlock[0] = new wbStdOutBlock(hStdOut, &rect);
		m_pStdOutBlock[0]->m_wAttribute = cSTDOUT_ATTRIBUTE_ARRAY[cSTDOUT_ATTRIBUTES_NUM-1];
	}
	else
	{
		m_pStdOutBlock = new wbStdOutBlock *[m_nNum];
		pSubBlock = m_pStdOutBlock;
	}

	SMALL_RECT wndRect;
	wndRect.Top = 0;
	wndRect.Left = 0;
	wndRect.Bottom = bufSize.Y-1;
	wndRect.Right = bufSize.X -1;

	//����������˳�����Ҫ
	SetConsoleScreenBufferSize(hStdOut, bufSize);
	SetConsoleWindowInfo(hStdOut, TRUE, &wndRect);
	

	for (int i=0; i<nRow; i++)
	for (int j=0; j<nCol; j++)
	{
		int n = i * nCol + j;
		wbSmallRect rect(j*nColWidth, i*nRowWidth, j*nColWidth+nColWidth, i*nRowWidth+nRowWidth);
		pSubBlock[n] = new wbStdOutBlock(hStdOut, &rect);
		pSubBlock[n]->m_wAttribute = cSTDOUT_ATTRIBUTE_ARRAY[n%min(cSTDOUT_ATTRIBUTES_NUM, nCol)];
	}

	for (int i=0; i<m_nNum; i++)
		m_pStdOutBlock[i]->FillAttribute();
}

wbStdOutMager::~wbStdOutMager()
{
	for (int i=0; i<m_nNum; i++)
		delete m_pStdOutBlock[i];
	delete [] m_pStdOutBlock;
}