// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Matrix class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#ifndef _WB_MATRIX_H_
#define _WB_MATRIX_H_

#include "wbSystem.h"

#define MERROR(x) {cout<<"[Matrix Error]"<<x<<endl;}

//==============================================
//============= ��ά���� ========================
//==============================================
template <typename T>
class wbMatrix
{
public:
	T *m_pBuffer;
	int m_nRow;
	int m_nCol;

public:
	wbMatrix(int nRow, int nCol, T* pBuffer = NULL)
	{
		m_nRow = nRow;
		m_nCol = nCol;
		m_pBuffer = new T[m_nRow*m_nCol];
		if (pBuffer != NULL)
			memcpy(m_pBuffer, pBuffer, sizeof(T)*m_nRow*m_nCol);
		else
			memset(m_pBuffer, 0, sizeof(T)*m_nRow*m_nCol);
	}

	wbMatrix(wbMatrix<T> &matrix)
	{
		m_nRow = matrix.m_nRow;
		m_nCol = matrix.m_nCol;
		m_pBuffer = new T[m_nRow*m_nCol];
		memcpy(m_pBuffer, matrix.m_pBuffer, sizeof(T)*m_nRow*m_nCol);
	}

	~wbMatrix()
	{
		SAFE_DELETE_ARRAY(m_pBuffer);
	}

	T& Get(int i, int j) 
	{
		if (m_pBuffer == NULL || i >= m_nRow || j>=m_nCol)
			MERROR("�������Խ��");

		return m_pBuffer[i*m_nCol+j]; 
	}
	T& Get(int n)  //������һάһ������
	{
		if (m_pBuffer == NULL || n>=m_nCol*m_nRow)
			MERROR("�������Խ��");
		return m_pBuffer[n];
	}

	void Print()
	{
		for (int i=0; i<m_nRow; i++)
		{
			for (int j=0; j<m_nCol; j++)
				cout<<Get(i,j)<<" ";
			cout<<endl;
		}
		
	}

	void Print(FILE *fp)
	{
		fprintf(fp, "[");
		for (int i=0; i<m_nRow; i++)
		{
			for (int j=0; j<m_nCol; j++)
			{
				fprintf(fp, "%f", Get(i,j));
				if (j != m_nCol-1)
					fprintf(fp, ",");
			}
			if (i != m_nRow-1)
				fprintf(fp, ";");
		}
		fprintf(fp, "]\n");
	}

public:
	void Fill(T t)
	{
		for (int i=0; i<m_nRow; i++)
		for (int j=0; j<m_nCol; j++)
			Get(i,j) = t;
	}
	void Zeros()
	{
		memset(m_pBuffer, 0, sizeof(T)*m_nCol*m_nRow);
	}
	void Eye(T t=1) //��Ϊ��λ��
	{
		Zeros();
		for (int i=0; i<m_nRow; i++)
			Get(i,i) = t;
	}

	void operator = (wbMatrix<T> &m)
	{
		if (m_nRow != m.m_nRow || m_nCol != m.m_nCol)
		{
			SAFE_DELETE_ARRAY(m_pBuffer);
			m_nRow = m.m_nRow;
			m_nCol = m.m_nCol;
			m_pBuffer = new T[m_nRow*m_nCol];
		}
		memcpy(m_pBuffer, m.m_pBuffer, sizeof(T)*m.m_nRow*m.m_nCol);
	}

public://���������
	template <typename T>
	friend wbMatrix<T> operator + (wbMatrix<T> &m1, wbMatrix<T> &m2)
	{
		if (m1.m_nRow != m2.m_nRow || m1.m_nCol != m2.m_nCol)
		{
			MERROR("<+>�����С��ƥ��");
		}
		wbMatrix<T> m(m1.m_nRow, m2.m_nCol);
		for (int i=0; i<m.m_nRow; i++)
		for (int j=0; j<m.m_nCol; j++)
			m.Get(i,j) = m1.Get(i,j) + m2.Get(i,j);
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend wbMatrix<T> operator - (wbMatrix<T> &m1, wbMatrix<T> &m2)
	{
		if (m1.m_nRow != m2.m_nRow || m1.m_nCol != m2.m_nCol)
		{
			MERROR("<->�����С��ƥ��");
		}
		wbMatrix<T> m(m1.m_nRow, m2.m_nCol);
		for (int i=0; i<m.m_nRow; i++)
			for (int j=0; j<m.m_nCol; j++)
				m.Get(i,j) = m1.Get(i,j) - m2.Get(i,j);
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend wbMatrix<T> operator * (wbMatrix<T> &m1, wbMatrix<T> &m2)
	{
		if (m1.m_nCol != m2.m_nRow)
			MERROR("<*>�����С��ƥ��");
		wbMatrix<T> m(m1.m_nRow, m2.m_nCol);
		for (int i=0; i<m.m_nRow; i++)
		for (int j=0; j<m.m_nCol; j++)
		{
			T sum = 0;
			for (int n=0; n<m1.m_nCol; n++)
				sum += m1.Get(i,n) * m2.Get(n,j);
			m.Get(i,j) = sum;
		}
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend wbMatrix<T> operator * (T t, wbMatrix<T> m1)
	{
		wbMatrix<T> m(m1);
		for (int i=0; i<m.m_nRow; i++)
		for (int j=0; j<m.m_nCol; j++)
			m.Get(i,j) *= t;
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend wbMatrix<T> operator / (wbMatrix<T> m1, T t)
	{
		wbMatrix<T> m(m1);
		for (int i=0; i<m.m_nRow; i++)
			for (int j=0; j<m.m_nCol; j++)
				m.Get(i,j) /= t;
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend wbMatrix<T> Trans(wbMatrix<T> m1)
	{
		wbMatrix<T> m(m1.m_nCol, m1.m_nRow);
		for (int i=0; i<m.m_nRow; i++)
		for (int j=0; j<m.m_nCol; j++)
			m.Get(i,j) = m1.Get(j,i);
		return wbMatrix<T>(m);
	}

	template <typename T>
	friend T Dot(wbMatrix<T> m1, wbMatrix<T> m2)
	{
		if (m1.m_nRow != m2.m_nRow || m1.m_nCol != m2.m_nCol)
		{
			MERROR("<.>�����С��ƥ��");
		}
		T sum = 0;
		for (int i=0; i<m1.m_nRow; i++)
			for (int j=0; j<m1.m_nCol; j++)
				 sum += m1.Get(i,j) * m2.Get(i,j);
		return sum;
	}

	template <typename T>
	friend wbMatrix<T> Con(wbMatrix<T> m1, wbMatrix<T> m2)
	{
		if (m1.m_nRow != m2.m_nRow || m1.m_nCol != 1 || m2.m_nCol != 1)
		{
			MERROR("<@>�����С��ƥ��");
		}
		
		wbMatrix<T> m(m1.m_nRow, m2.m_nRow);
		for (int i=0; i<m1.m_nRow; i++)
			for (int j=0; j<m2.m_nRow; j++)
				m.Get(i,j) = m1.Get(i) * m2.Get(j);

		return wbMatrix<T>(m);
	}

	template <typename T>
	friend T Norm(wbMatrix<T> m1)
	{
		T sum = 0;
		for (int i=0; i<m1.m_nRow; i++)
		for (int j=0; j<m1.m_nCol; j++)
			sum += m1.Get(i,j)*m1.Get(i,j);

		return sqrt(sum);
	}
};


#endif