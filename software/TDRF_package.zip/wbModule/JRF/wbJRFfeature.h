// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Feature defination for TDRF models
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/** 
 * \file
 * \author wangbin
 * \date 2014-02-27
 * \brief JRFģ����������
 */
#pragma once
#include "wbSystem.h"
#include "wbJRFdef.h"
#include <limits.h>

namespace wbJRF
{
	typedef enum{
		base = 0,  // �������� 
		ngram = 1, // ngram
		jgram = 2,  // jump-ngram
		super = 3,	// super-gram

		cgram = 4,  // class-gram
		wgram = 5,  // word-gram
		pgram = 6,  // predict-gram
		ggram = 7,  // word-class-gram

		skip2w = 8   // skip-bigram
	} FType; ///< ������������

	inline wbString FeatureType2Str(FType t)
	{
		switch(t) {
		case base: return "base"; break;
		case ngram: return "ngram"; break;
		case jgram: return "jgram"; break;
		case super: return "super"; break;
		case cgram: return "cgram"; break;
		case wgram: return "wgram"; break;
		case pgram: return "pgram"; break;
		case ggram: return "ggram"; break;
		case skip2w: return "skip2w"; break;
		default: lout_error("unknown feature type : "<<t);
		}
	}
	inline FType FeatureStr2Type(const char *str)
	{
		wbString s(str);
		if (s == "base") return base;
		else if (s == "ngram") return ngram;
		else if (s == "jgram") return jgram;
		else if (s == "super") return super;
		else if (s == "cgram") return cgram;
		else if (s == "wgram") return wgram;
		else if (s == "pgram") return pgram;
		else if (s == "ggram") return ggram;
		else if (s == "skip2w") return skip2w;
		else { lout_error("unknown feature type(str) : "<<str) };
		return base;
	}
	
	
	/** 
	 * \class
	 * \brief ��������
	 */
	class Feature
	{
	public:
		FType type; ///< ��������
		Feature() { type = base; };
		/// �����Ƿ����
		/** 
		 * \param [in] pSeq ��������
		 * \param [in] nLen	�����ܳ���
		 * \param [in] h	��ǰλ��
		 * \return �����������ܣ��򷵻�true�����򷵻�false 
		 */
		virtual bool bAccept(int *pSeq, int nLen, int h) { return false; }
		/// �������ܴ���, ��ʵ���Ǳ���ÿ��λ�ã��ж��Ƿ���ܣ��������г��Ȼ�λ��Լ�������������Լ��ٵ�������
		/**
		 * \param [in] pSeq ��������
		 * \param [in] nLen	�����ܳ���
		 * \return ���ض�������һ�������˼���
		 */
		virtual int nAccept(int *pSeq, int nLen) { 
			int nTime = 0;
			for (int h=0; h<nLen; h++)
				nTime += bAccept(pSeq, nLen, h);
			return nTime;
		}
		/// д���ļ�
		virtual void Write(wbFile &file) = 0;
		/// �����ļ�
		virtual void Read(wbFile &file) = 0;
		/// ���������Ƿ���jump��Ϣ������ngram������������
		virtual bool bJump() { return false; }
		///  ����������Ƿ�ΪskipBigram����(w,-1,-1,-1,-1,w)
		virtual bool bSkipBigram() { return false; }
	};

	const short ngram_maxOrder = 10; ///< ngram������������
	/** 
	 * \class
	 * \brief n-gram ����
	 */
	class Ngram : public Feature
	{
	public:
		VocabID flag[ngram_maxOrder];
		short order;
		Ngram():order(0){ type=ngram; };
		Ngram(VocabID *pGram, int nOrder){
			type=ngram;
			memcpy(flag, pGram, sizeof(VocabID)*nOrder);
			order = nOrder;
		}
		/// �ж�Gram�Ƿ���ܣ�����֮���class����������
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			return Ngram::bAccept(pSeq, nLen, h);
		}
		/// �жϳ�Gram֮�����Ϣ�Ƿ�����
		virtual bool bExAccept(int nLen, int h)
		{
			if (nLen < order || h < 0 || h + order > nLen)
				return false;
			return true;
		}
		virtual bool bAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;

			
			for (int i=0; i<order; i++) {
				if (pSeq[h+i] != flag[i])
					return false;
			}
			return true;
		}
		virtual void Write(wbFile &file)
		{
			file.Print("order=%d flag=", order);
			for (int i=0; i<order; i++)
				file.Print("%d ", flag[i]);
		}
		virtual void Read(wbFile &file)
		{
			fscanf(file, "order=%d flag=", &order);
			for (int i=0; i<order; i++)
				fscanf(file, "%d ", &flag[i]);
		}
	};

	/** 
	 * \class
	 * \brief JumpNgram����
	 */
	class JumpNgram : public Ngram
	{
	public:
		JumpNgram(){ type=jgram; };
		JumpNgram(VocabID *pGram, int nOrder):Ngram(pGram, nOrder) { type=jgram;};
		virtual bool bAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;


			for (int i=0; i<order; i++) {
				if (flag[i] != VocabID_none && pSeq[h+i] != flag[i])
					return false;
			}
			return true;
		}

		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			return JumpNgram::bAccept(pSeq, nLen, h);
		}

		virtual bool bJump()
		{
			for (int i=0; i<order; i++)  {
				if ( flag[i] == VocabID_none )
					return true;
			}
			return false;
		}
		///  ����������Ƿ�ΪskipBigram����(w,-1,-1,-1,-1,w)
		virtual bool bSkipBigram()
		{
			if ( order <= 2 )
				return false;

			for (int i=1; i<order-1; i++) {
				if ( flag[i] != VocabID_none )
					return false;
			}
			return (flag[0]!=VocabID_none) && (flag[order-1] !=VocabID_none);
		}
	};


	
	const int pos_tail = -1; ///< ����Ϊpos_min��pos_max��ֵ����ʾ�Ǿ��ӵĽ�β, pos����ΪnLen-order
	/** 
	 * \class
	 * \brief ��ȫ��ngram����
	 */
	class SuperNgram : public JumpNgram
	{
	public:
		int len_min, len_max;
		int pos_min, pos_max; ///< �궨gram��һ��Ԫ�ص�λ��

		SuperNgram(): 
			len_min(0), len_max(INT_MAX),
			pos_min(0), pos_max(pos_tail)
		{
			type=super;
		}
		SuperNgram(VocabID *pGram, int nOrder, 
			int _len_min=0, int _len_max=INT_MAX,
			int _pos_min=0, int _pos_max=pos_tail ) 
			: JumpNgram(pGram, nOrder), 
			len_min(_len_min), len_max(_len_max),
			pos_min(_pos_min), pos_max(_pos_max)
		{
			type=super;
		}
		/// �ж��Ƿ������Ч�ĳ��Ⱥ�positionԼ��
		virtual bool bContainExConstaints()
		{
			return !(len_min==0 && len_max==INT_MAX && pos_min==0 && pos_max==pos_tail);
		}
		/// �������Ⱥ�pos��Ϣ
		virtual void CopyExConstaints(SuperNgram *pf)
		{
			len_min = pf->len_min;
			len_max = pf->len_max;
			pos_min = pf->pos_min;
			pos_max = pf->pos_max;
		}
		/// �ж�Gram�Ƿ���ܣ�����֮���class����������
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			return JumpNgram::bAccept(pSeq, nLen, h);
		}
		/// �жϳ�Gram֮�����Ϣ�Ƿ�����
		virtual bool bExAccept(int nLen, int h)
		{
			if (nLen < order)
				return false;

			if (nLen >= len_min && nLen <= len_max) {
				int nMin = (pos_min==pos_tail)? nLen-order: pos_min;
				int nMax = (pos_max==pos_tail)? nLen-order: pos_max;
				if (h >= nMin && h <= nMax && h>=0 && h+order <= nLen) {
					return true;
				}
			}
			return false;
		}
		virtual bool bAccept(int *pSeq, int nLen, int h)
		{
			if (nLen < order)
				return false;

			if (nLen >= len_min && nLen <= len_max) {
				int nMin = (pos_min==pos_tail)? nLen-order: pos_min;
				int nMax = (pos_max==pos_tail)? nLen-order: pos_max;
				if (h >= nMin && h <= nMax) {
					return bGramAccept(pSeq, nLen, h);
				}
			}
			return false;
		}
		/// �����г��Ⱥ�λ��Լ�������������Լ���ѭ������
		virtual int nAccept(int *pSeq, int nLen)
		{
			if (nLen < order)
				return 0;

			if (nLen >= len_min && nLen <= len_max) {
				int nMin = (pos_min==pos_tail)? nLen-order: pos_min;
				int nMax = (pos_max==pos_tail)? nLen-order: pos_max;
				int nTime = 0;
				for (int h=nMin; h<=nMax; h++) {
					nTime += bGramAccept(pSeq, nLen, h);
				}
				return nTime;
			}
			return 0;
		}
		void WriteLenPos(wbFile &file)
		{
			file.Print("len=[%d,", len_min);
			if (len_max == INT_MAX)
				file.Print("*");
			else
				file.Print("%d", len_max);
			file.Print("] pos=[%d,%d] ", pos_min, pos_max);
		}
		void ReadLenPos(wbFile &file)
		{
			fscanf(file, "len=[%d,", &len_min);
			wbArray<char> str(10);
			char c;
			while (c = fgetc(file)) {
				if ( c==']' )
					break;
				str.Add(c);
			}
			str.Add('\0');
			//lout_variable(strcmp(str, "*"));

			if (strcmp(str, "*") == 0) {
				len_max = INT_MAX;
			} else {
				len_max = atoi(str);
			}

			fscanf(file, " pos=[%d,%d] ", &pos_min, &pos_max);

		}
		virtual void Write(wbFile &file)
		{
			WriteLenPos(file);
			JumpNgram::Write(file);
		}
		virtual void Read(wbFile &file)
		{
			ReadLenPos(file);
			JumpNgram::Read(file);
		}
	};

	/** 
	 * \class
	 * \brief ֻ����class��superNgram
	 */
	class ClassNgram : public SuperNgram
	{
	public:
		VocabInfo *m_pInfo;
		ClassNgram(VocabInfo *pInfo):m_pInfo(pInfo) { type = cgram; }
		ClassNgram(VocabInfo *pInfo, VocabID *pGram, int nOrder, 
			int _len_min=0, int _len_max=INT_MAX,
			int _pos_min=0, int _pos_max=pos_tail):m_pInfo(pInfo),
			SuperNgram(pGram, nOrder, _len_min, _len_max, _pos_min, _pos_max){
				type = cgram;
		}
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;

			for (int i=0; i<order; i++) { //�ж�����Ƿ��flagһ��
				if (flag[i] != VocabID_none && m_pInfo[pSeq[h+i]].cid != flag[i] )
					return false;
			}
			return true;
		}
		
	};

	/** 
	 * \class
	 * \brief ֻ����word��superNgram����
	 */
	class WordNgram : public SuperNgram
	{
	public:
		VocabInfo *m_pInfo;
		WordNgram(VocabInfo *pInfo):m_pInfo(pInfo) { type = wgram; }
		WordNgram(VocabInfo *pInfo, VocabID *pGram, int nOrder, 
			int _len_min=0, int _len_max=INT_MAX,
			int _pos_min=0, int _pos_max=pos_tail):m_pInfo(pInfo),
			SuperNgram(pGram, nOrder, _len_min, _len_max, _pos_min, _pos_max){
				type = wgram;
		}
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;

			for (int i=0; i<order; i++) { //�ж�����Ƿ��flagһ��
				if (flag[i] != VocabID_none && m_pInfo[pSeq[h+i]].wid != flag[i] )
					return false;
			}
			return true;
		}
	};

	/** 
	 * \class
	 * \brief ModelM��������ʹ�õģ���ʷΪword����ǰΪclass or token����f(w,c) or f(w,cw)
	 */
	class PredictNgram : public SuperNgram
	{
		/*
		flag�м�¼�������е�word�����У����һ��λ�ÿ���Ϊnone
		c�м�¼���һ��λ�õ�class
		*/
	public:
		VocabID c; ///< ��¼��ǰλ�õ�class
		VocabInfo *m_pInfo;
		PredictNgram(VocabInfo *pInfo):m_pInfo(pInfo),c(VocabID_none) { type = pgram; }
		PredictNgram(VocabInfo *pInfo, VocabID *pGram, int nOrder, VocabID cur_c, 
			int _len_min=0, int _len_max=INT_MAX,
			int _pos_min=0, int _pos_max=pos_tail):m_pInfo(pInfo), c(cur_c),
			SuperNgram(pGram, nOrder, _len_min, _len_max, _pos_min, _pos_max){
				type = pgram;
		}
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;

			for (int i=0; i<order; i++) { //�ж�word�Ƿ��flagһ��
				if (flag[i] != VocabID_none && m_pInfo[pSeq[h+i]].wid != flag[i] )
					return false;
			}

			if ( c != VocabID_none && m_pInfo[pSeq[h+order-1]].cid != c) //�ж����һ��λ�õ�class�Ƿ���������
				return false;

			return true; 
		}
		virtual void Write(wbFile &file)
		{
			SuperNgram::Write(file);
			file.Print("c=%d ", c);
		}
		virtual void Read(wbFile &file)
		{
			SuperNgram::Read(file);
			fscanf(file, "c=%d ", &c);
		}
	};

	/** 
	 * \class
	 * \brief ֻ����word ͬʱ ���� class ��superNgram����
	 */
	class GlobalNgram : public SuperNgram
	{
	public:
		VocabInfo *m_pInfo;
		VocabID cflag[ngram_maxOrder]; //����class-flag
		GlobalNgram(VocabInfo *pInfo):m_pInfo(pInfo) { type = ggram; }
		GlobalNgram(VocabInfo *pInfo, VocabID *pwgram, VocabID *pcgram, int nOrder, 
			int _len_min=0, int _len_max=INT_MAX,
			int _pos_min=0, int _pos_max=pos_tail):m_pInfo(pInfo),
			SuperNgram(pwgram, nOrder, _len_min, _len_max, _pos_min, _pos_max)
		{
				memcpy(cflag, pcgram, sizeof(VocabID)*nOrder); //����class flag
				type = ggram;
		}
		virtual bool bGramAccept(int *pSeq, int nLen, int h)
		{
			if (h < 0 || h + order > nLen)
				return false;

			for (int i=0; i<order; i++) { //�ж�����Ƿ��flagһ��
				if ( 
					( flag[i] != VocabID_none && m_pInfo[pSeq[h+i]].wid != flag[i] ) || //wid��һ��
					( cflag[i] != VocabID_none && m_pInfo[pSeq[h+i]].cid != cflag[i] ) //cid��һ��
					)
					return false;
			}
			return true;
		}
		///  �жϵ�ǰ�������Ƿ���Щ����ģʽ�����ڲ���
		/// �Ƿ�ΪclassԤ��word ( f(c,c,c,w) )
		bool Is_cpw()
		{
			for ( int i=0; i<order-1; i++ ) {
				if ( cflag[i] == VocabID_none || flag[i] != VocabID_none )
					return false;
			}
			return cflag[order-1]==VocabID_none && flag[order-1] != VocabID_none;
		}
		/// �Ƿ�ΪwordԤ��class��ע����PredictNgram��һ������f(w,w,w,c)
		bool Is_wpc()
		{
			for (int i=0; i<order-1; i++) {
				if ( flag[i] == VocabID_none || cflag[i] != VocabID_none )
					return false;
			}
			return flag[order-1]==VocabID_none && cflag[order-1] != VocabID_none;
		}
		virtual bool bJump()
		{
			for (int i=0; i<order; i++)  {
				if ( flag[i] == VocabID_none && cflag[i] == VocabID_none )
					return true;
			}
			return false;
		}
		virtual void Write(wbFile &file)
		{
			WriteLenPos(file);

			file.Print("order=%d wflag=", order);
			for (int i=0; i<order; i++)
				file.Print("%d ", flag[i]);

			file.Print("cflag=");
			for (int i=0; i<order; i++)
				file.Print("%d ", cflag[i]);
		}
		virtual void Read(wbFile &file)
		{
			ReadLenPos(file);

			fscanf(file, "order=%d wflag=", &order);
			for (int i=0; i<order; i++)
				fscanf(file, "%d ", &flag[i]);

			fscanf(file, "cflag=");
			for (int i=0; i<order; i++)
				fscanf(file, "%d ", &cflag[i]);
		}
	};


	inline Feature* FeatureCreate( FType t, Vocab &v )
	{
		switch(t) {
		case base: lout_warning("cannot create Base featrue"); return NULL; break;
		case ngram: return new Ngram(); break;
		case jgram: return new JumpNgram(); break;
		case super: return new SuperNgram(); break;
		case cgram: return new ClassNgram(v.aVocabInfo); break;
		case wgram: return new WordNgram(v.aVocabInfo); break;
		case pgram: return new PredictNgram(v.aVocabInfo); break;
		case ggram: return new GlobalNgram(v.aVocabInfo); break;
		default: lout_error("unknown feature type : "<<t); return NULL;
		}
	}
}