// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Lexicon class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/**
 * \file 
 * \author wangbin
 * \date 2013-9-23
 * \brief gsp�ֵ��ļ��������˶�gsp�ֵ��д������ʹ�� wbGspVocab
*/

#ifndef _WB_LEXCION_H_
#define _WB_LEXCION_H_
#include "wbSystem.h"

class wbWordSet
{
public:
	int nId;
	int nNum; //�����������ݿ��ַ�������
	int nId2; //��������ʲô��˼,��idֵһ��
	char *pChar;
	int *pProun;

	wbWordSet()
	{
		pChar = NULL;
		pProun = NULL;
	}

	wbWordSet(int cLen, int pLen)
	{
		pChar = new char[cLen+1];
		pProun = new int[pLen];
		nNum = pLen;
	}

	wbWordSet(const wbWordSet* p)
	{
		nId = p->nId;
		nId2 = p->nId2;
		nNum = p->nNum;
		pChar = new char[strlen(p->pChar)+1];
		strcpy(pChar, p->pChar);
		pProun = new int[nNum];
		memcpy(pProun, p->pProun, sizeof(int)*nNum);
	}

	~wbWordSet()
	{
		SAFE_DELETE_ARRAY(pChar);
		SAFE_DELETE_ARRAY(pProun);
	}
}; 

/// gsp��ʽ�ʵ�
class wbLexcion
{
public:
	wbArray<wbWordSet*> m_wordArray;

	int nWordInfoNum;
	int nWordInfoSize;
	int nTotalZiNum;

	wbLexcion(int size=90000);
	~wbLexcion();

	void AddWordSet(wbWordSet* pNew) { m_wordArray[nWordInfoNum] = pNew; nWordInfoNum++; nTotalZiNum += pNew->nNum; }

	void LoadGspLext(FILE *fp);
	void WriteGspLext(FILE *fp);

	void AddBegEndSignal()
	{
		wbWordSet *pWordSet = new wbWordSet(2, 1);
		pWordSet->nId = 0;
		pWordSet->nId2 = 0;
		strcpy(pWordSet->pChar, ">>");
		pWordSet->pProun[0] = 60000;
		AddWordSet(pWordSet);

		pWordSet = new wbWordSet(2, 1);
		pWordSet->nId = 1;
		pWordSet->nId2 = 1;
		strcpy(pWordSet->pChar, "<<");
		pWordSet->pProun[0] = 60001;
		AddWordSet(pWordSet);
	}

	/// ���򣬲�����д���
	void SortAndReID(bool bSorted = true);

	

};

#endif