// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF model training method, for sampling
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFCD.h"

namespace wbJRF
{
	bool CDTaskPack::Process(int nThreadId)
	{
		//static wbFile test("testThread_t.dbg", "wt");

		int nSeq = m_aSeq.GetNum();

		//����ǰ������
		for (int i=0; i<m_pMode->m_nFeatNum; i++) {
			int n = m_pMode->m_aFeatures[i]->nAccept(m_aSeq, nSeq);
			int *pCount = m_paPeCount[nThreadId]->Insert(i);
			if (!pCount) *pCount = n;
			else *pCount += n;
		}

// 		for (int i=0; i<nSeq; i++)
// 			test.Print("%c", m_aSeq[i]+'a');
// 		test.Print("\t");

		//����
		m_pMode->Sampling(m_aSeq, nSeq, m_nSampleTimes);
		//wbThreadManager::Printf(nThreadId, "%d\n", rand());

		m_aSeq.m_nTop = nSeq-1;

// 		for (int i=0; i<nSeq; i++)
// 			test.Print("%c", m_aSeq[i]+'a');
// 		test.Print("\n");

		//���������������
		for (int i=0; i<m_pMode->m_nFeatNum; i++) {
			int n = m_pMode->m_aFeatures[i]->nAccept(m_aSeq, nSeq);
			int *pCount = m_paPnCount[nThreadId]->Insert(i);
			if (!pCount) *pCount = n;
			else *pCount += n;
		}

		return true;
	}

	void CDThreadMager::Reset(int *pRandSeq, int nRandNum)
	{
		wbThreadManager::Reset();
		m_pRandomSeq = pRandSeq;
		m_nRandomNum = nRandNum;
		m_nRandomCur = 0;

		//�������
		for (int i=0; i<m_nThreadNum; i++) {
// 			new (m_ppPeCount[i]) wbLHash<int,int>;
// 			new (m_ppPnCount[i]) wbLHash<int,int>;
			m_ppPeCount[i]->Clean();
			m_ppPnCount[i]->Clean();
		}

		titlePrecent(0, true, nRandNum, "GetGradient[t]:");
	}
	wbTaskPack* CDThreadMager::CreateTask()
	{
		if (m_nRandomCur >= m_nRandomNum) //��������
			return NULL;

		CDTaskPack *pTask = new CDTaskPack(m_nTaskNum++, m_ppPeCount, m_ppPnCount, m_pMode, m_nSampleTime);

		m_pTrain->GetLine(m_pRandomSeq[m_nRandomCur], pTask->m_aSeq);
		m_nRandomCur++;

		return pTask;
	}

	void CD::Prepare(int nThreadNum, CDmodel *pModel, const char *pathTrain, const char *pathTest /* = NULL */)
	{
		//ģ��
		m_pModel = pModel;
		wbFunc::m_nParamNum = m_pModel->m_nFeatNum;
		lout_variable(m_pModel->m_nFeatNum);
		lout_variable(m_pModel->m_pVocab->nSize);

		//���ٿռ�
		SAFE_NEW_ARRAY(m_pPefi, double, m_pModel->m_nFeatNum);
		SAFE_NEW_ARRAY(m_pPnfi, double, m_pModel->m_nFeatNum);

		//��������
		m_corpusTrain.Reset(pathTrain, true);
		if (pathTest)
			m_corpusTest.Reset(pathTest);
		m_nSeqMaxLen = max(m_corpusTrain.m_nSize, m_corpusTest.m_nSize);
		m_nSeqNum = m_corpusTrain.m_nLine;
		lout_variable(m_nSeqNum);
		lout_variable(m_nSeqMaxLen);
		if (m_pModel->m_nMaxLen < m_nSeqMaxLen) {
			lout_error("ģ���趨���ȣ�"<<m_pModel->m_nMaxLen<<"�� < ������������󳤶ȣ�"<<m_nSeqMaxLen<<"��");
		}

		//ͳ�Ƴ��ȷֲ�
		m_aLenCount.SetNum(m_pModel->m_nMaxLen+1);
		m_aLenCount.Fill(0);
		wbArray<int> aSeq;
		for (int i=0; i<m_corpusTrain.m_nLine; i++) {
			m_corpusTrain.GetLine(i, aSeq);
			m_aLenCount[aSeq.GetNum()]++;
		}
		if ( pModel->m_aLenProb.GetNum() == 0 ) { //��ģ�͵ĳ��ȷֲ�û�г�ʼ��������г�ʼ��������ʹ��ģ���Դ��ĳ��ȷֲ�
			for (int i=1; i<m_aLenCount.GetNum(); i++) { //Ϊ���ȷֲ���ֵ
				m_pModel->m_aLenProb[i] = 1.0 * m_aLenCount[i] / m_corpusTrain.m_nLine;
				//lout<<m_pModel->m_aLenProb[i]<<" ";
			}
			//lout<<endl;
		}
#ifdef Scheme1
		((CDmodel_len *)pModel)->InitSampling();
#endif

		//Min-batch
		if (m_nBlockSize <= 0 || m_nBlockSize >= m_nSeqNum) {
			m_nBlockSize = m_nSeqNum;
			lout<<"Using Batch Update"<<endl;
		} else {
			lout<<"Min-batch Update :"<<m_nBlockSize<<endl;
		}
		m_nBlockNum = m_nSeqNum / m_nBlockSize;
		lout_variable(m_nBlockNum);
		lout_variable(m_nBlockSize);
		lout_variable(m_nSeqNum % m_nBlockSize);
		RandTrainSeq();
		m_nScanTimes = 0;

		//�����̹߳���
		m_pThreadMager = new CDThreadMager(nThreadNum, 
			m_pModel, &m_corpusTrain, 
			m_aRandSeq, m_nBlockSize, 
			m_nSamplingStep);
		m_pThreadMager->StartThread();
	}

	void CD::RandTrainSeq()
	{
		m_nScanTimes++;

		//lout<<"[CD] Rand Train Seqs"<<endl;
		wbArray<int> aInit(m_nSeqNum);
		for (int i=0; i<m_nSeqNum; i++) {
			aInit[i] = i;
			m_aRandSeq[i] = i;
		}

		//return ;

		m_aRandSeq.Clean();
		int nNum = m_nSeqNum;
		while (nNum > 0) {
			int n = rand()%nNum;
			m_aRandSeq.Add( aInit[n] );
			aInit[n] = aInit[nNum-1];
			nNum--;
		}

		lout_assert(m_aRandSeq.GetNum() == m_nSeqNum);
		m_nCurBlock = 0;
	}

	bool CD::GetGradient_t(double *pdParams, double *pdGradient)
	{
		//wbFile test("cd_gradient.dbg", "wt");

		if (pdParams) {
			m_pModel->SetParams(pdParams, false);
		}

		int nFeatrueNum = m_pModel->m_nFeatNum;
		memset(m_pPefi, 0, sizeof(m_pPefi[0])*nFeatrueNum);
		memset(m_pPnfi, 0, sizeof(m_pPnfi[0])*nFeatrueNum);

		if (m_nCurBlock >= m_nBlockNum)
			RandTrainSeq(); //��������

		int nBeg = m_nCurBlock * m_nBlockSize;
		int nEnd = min(nBeg + m_nBlockSize, m_nSeqNum);
		int nNum = nEnd-nBeg;
		

		m_pThreadMager->Reset(m_aRandSeq+nBeg, nNum); ///< �����̼߳�¼
		//m_pThreadMager->StartThread();
		m_pThreadMager->Run();
		//m_pThreadMager->EndThread();
		m_nCurBlock++;

		//ͳ�Ƹ���
		for (int n=0; n<m_pThreadMager->m_nThreadNum; n++) {
			int *pCount;
			int nFeat;
			wbLHashIter<int,int> iterPe(m_pThreadMager->m_ppPeCount[n]);
			while ( pCount = iterPe.Next(nFeat) ) {
				m_pPefi[nFeat] += 1.0 * (*pCount) / nNum;
			}
			wbLHashIter<int,int> iterPn(m_pThreadMager->m_ppPnCount[n]);
			while ( pCount = iterPn.Next(nFeat) ) {
				m_pPnfi[nFeat] += 1.0 * (*pCount) / nNum;
			}
		}


		//�����ݶ�
		for (int i=0; i<m_nParamNum; i++) {
			pdGradient[i] = m_pPnfi[i] - m_pPefi[i];
		}

// 			for (int i=27; i<30; i++)
// 				lout<<m_pPnfi[i]<<"\t"<<m_pPefi[i]<<endl;

		return true;
	}

	double CD::CaculateLogLikelihood(Corpus *pCorpus, bool bNorm /*= true*/, double *pPPL /*=NULL*/)
	{
		double dValue = 0;
		double dPPL = 0;
		wbArray<int> aSeq;
		int nWord = 0;
		for (int i=0; i<pCorpus->m_nLine; i++) {
			pCorpus->GetLine(i, aSeq);
			double d = m_pModel->GetLogProb(aSeq, aSeq.GetNum(), bNorm); 
			dValue += d;
			dPPL += d / log(10.0);
			nWord += aSeq.GetNum() + 1;
		}
		dValue /= pCorpus->m_nLine;
		dPPL = pow(10, -dPPL / nWord);

		if (pPPL) *pPPL = dPPL;

		return -dValue; //������Ȼֵ�Ǳ��ģ���Ҫת��Ϊ��׼��С������
	}
}