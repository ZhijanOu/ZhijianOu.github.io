// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Word cluster class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbWordCluster.h"



void wbWordCluster::InitCount(const char *path)
{
	bool bFound;
	wbFile file(path, "rt");
	char *pLine = NULL;
	m_nSentNum = 0;
	m_nVocabSize = 0;

	while (pLine = file.GetLine(true)) {

		wbArray<int> aWords;

		char *pWord = strtok(pLine, " \t");
		while (pWord) {
			aWords.Add(atoi(pWord));
			pWord = strtok(NULL, " \t");
		}

		m_nSentNum += 1;
		//Unigram
		for (int i=0; i<aWords.GetNum(); i++) {
			m_nVocabSize = max( m_nVocabSize, aWords[i] + 1 );

			int *pCount = m_wordCount.Insert(aWords[i], bFound);
			if (!bFound) *pCount = 1;
			else (*pCount)++;
		}
		//Bigram
		for (int i=0; i<aWords.GetNum()-1; i++) {
			int *pCount = m_wordGramCount.Insert(aWords.GetBuffer(i), 2, bFound);
			if (!bFound) *pCount = 1;
			else (*pCount)++;

			int idx[3];
			idx[0] = aWords[i+1];
			idx[1] = aWords[i];
			pCount = m_invWordGram.Insert(idx, 2, bFound);
			if ( !bFound ) *pCount = 1;
			else (*pCount)++;
		}
	}

	lout_assert(m_wordCount.GetNum() >= m_nClassNum);
	lout_variable(m_nVocabSize);
	lout_variable(m_nClassNum);

	m_aClass.SetNum(m_nVocabSize);
	m_aClass.Fill(m_nClassNum-1); ///< ���ڴ���û��count��word�������ҪΪû��cout�Ĵʷ���һ��class
	//��Unigram���򣬳�ʼ����
	wbHeap<int,int> heap(HEAPMODE_MAXHEAP);
	int w, n;
	int *pCount;
	wbLHashIter<int, int> iter(&m_wordCount);
	while (pCount = iter.Next(w)) {
		heap.Insert(w, *pCount);
	}
	int nClass = 0;
	while (heap.OutTop(w, n)) {  //ǰm_nClass-2��word��ÿ��wordһ���ࣻ��ߵ����г��ֵ�class����m_nClassNum-2�ࣻδ���ֵĸ���m_nClass-1��
		if ( nClass <= m_nClassNum-2 )
			m_aClass[w] = nClass;
		else
			m_aClass[w] = m_nClassNum-2;
		//m_aClass[w] = (nClass >= m_nClassNum-2)? m_nClassNum-2: nClass;
		nClass++;
	}
	//WriteCount(m_wordGramCount, wbFile("test.count", "wt"));
	//���������ص�count
	UpdataCount();
}

void wbWordCluster::UpdataCount()
{
	//wbFile test("a.dbg", "wt");
	//���count����
	m_classCount.Fill(0);
	//m_classGramCount.Fill(0);
	for (int i=0; i<m_nClassNum+1; i++)
		memset(m_pClassGramCount[i], 0, sizeof(int)*(m_nClassNum+1));
	m_classWordCount.Fill(0);
	m_wordClassCount.Fill(0);

	int w, n;
	int *pCount;
	//���������ص�count
	//Unigram class
	lout<<"Update class Unigram"<<endl;
	wbLHashIter<int, int> iter(&m_wordCount);
	while (pCount = iter.Next(w)) {
		CountAdd(m_classCount, m_aClass[w], *pCount);
	}
	//Bigram class
	lout<<"Update class Bigram"<<endl;
	int gram[10];
	int g[10];
	wbTrie<int,int> *pSub;
	wbTrieIter2<int,int> iter2(m_wordGramCount, gram, 2);
	while (pSub = iter2.Next()) {
		if (!pSub->IsDataLegal())
			continue;
		
		//test.Print("%d %d\t%d\n",  gram[0], gram[1], *(pSub->GetData()));

		g[0] = m_aClass[gram[0]];
		g[1] = m_aClass[gram[1]];
		CountAdd(m_pClassGramCount, g, 2, *(pSub->GetData()) );
		g[0] = m_aClass[gram[0]];
		g[1] = gram[1];
		Reverse(g); //��word������ǰ��Ϊ�˷������ĳ��word����Чǰ��class
		CountAdd(m_classWordCount, g, 2, *(pSub->GetData()) );
		g[0] = gram[0];
		g[1] = m_aClass[gram[1]];
		CountAdd(m_wordClassCount, g, 2, *(pSub->GetData()) );
	}


	//Sum { N(w)logN(w) }
	m_dWordLogSum = 0;
	wbLHashIter<int,int> iterW(&m_wordCount);
	while (pCount = iterW.Next(w)) {
		lout_assert(*pCount>=0);
		if ( *pCount != 0 )
			m_dWordLogSum += 1.0 * (*pCount) / m_nSentNum * log((double)(*pCount));
	}
}

void wbWordCluster::WriteCount(wbLHash<int, int> &count, wbFile &file)
{
	wbLHashIter<int,int> iter(&count);
	int w;
	int *pCount;
	while (pCount = iter.Next(w)) {
		file.Print("%d\t%d\n", w, *pCount);
	}
}
void wbWordCluster::WriteCount(wbTrie<int,int> &count, wbFile &file, bool bReverse /*=false*/)
{
	int gram[10];
	wbTrie<int,int> *pSub;
	wbTrieIter2<int,int> iter(count, gram, 2);
	while (pSub = iter.Next()) {
		if (pSub->IsDataLegal()) {
			if (bReverse)
				file.Print("%d %d\t%d\n", gram[1], gram[0], *(pSub->GetData()) );
			else
				file.Print("%d %d\t%d\n", gram[0], gram[1], *(pSub->GetData()) );
		}
	}
}
void wbWordCluster::WriteRes_WordClass(const char *path)
{
	wbFile file(path, "wt");
	for (int i=0; i<m_aClass.GetNum(); i++) {
		file.Print("%d\t%d\n", i, m_aClass[i]);
	}
}
void wbWordCluster::WriteRes_ClassWord(const char *path)
{
	
	wbArray<wbArray<int>*> aClass(m_nClassNum);
	for (int i=0; i<m_nClassNum+1; i++)
		aClass[i] = new wbArray<int>();

	int w;
	for (w =0; w<m_nVocabSize; w++)
	{  
		aClass[m_aClass[w]]->Add(w);
	}
	
	wbFile file(path, "wt");
	for (int i=0; i<m_nClassNum; i++) {
		file.Print("[%d]\t", i);
		for (int n=0; n<aClass[i]->GetNum(); n++) {

			int w = aClass[i]->Get(n);
			int *pcount = m_wordCount.Find(w);
			int ncount = (pcount==NULL)? 0 : *pcount;

			file.Print("%d{%d} ", aClass[i]->Get(n), ncount); //��ӡ����count
		}
		file.Print("\n");
	}


	for (int i=0; i<m_nClassNum; i++)
		SAFE_DELETE(aClass[i]);
}
void wbWordCluster::WriteRes_TagVocab(const char *path)
{
	wbFile file(path, "wt");
	for (int i=0; i<m_aClass.GetNum(); i++) {
		file.Print("%d\t%d %d\n", i, i, m_aClass[i]);
	}
}
void wbWordCluster::Read_TagVocab(const char *path)
{
	wbFile file(path, "rt");
	for (int i=0; i<m_aClass.GetNum(); i++) {
		int g,w,c;
		fscanf(file, "%d\t%d %d\n", &g,&w,&c);
		if ( g != i ) {
			lout_error("read TagVocab ERROR!!");
		}
		m_aClass[g] = c;
	}
	UpdataCount();
}

double wbWordCluster::LogLikelihood()
{
	double dSumClassGram = 0;
	double dSumClass = 0;
	double dSumWord = 0;
	// Sum{ N(g_v,g_w)logN(g_v,g_w) }
// 	int g[10];
// 	wbTrie<int,int> *pSub;
// 	wbTrieIter2<int,int> iter2(m_classGramCount, g, 2);
// 	while (pSub = iter2.Next()) {
// 		if (!pSub->IsDataLegal())
// 			continue;
// 
// 		int n = *(pSub->GetData());
// 		lout_assert( n>= 0 );
// 		if ( n != 0 ) {
// 			dSumClassGram += 1.0 * n/m_nSentNum * log((double)n);
// 		}
// 	}
	for (int i=0; i<m_nClassNum+1; i++) {
		for (int j=0; j<m_nClassNum+1; j++) {
			int n = m_pClassGramCount[i][j];
			if ( n<0 ) {
				lout_error("classGramCount ("<<n<<") < 0")
			}
			if ( n != 0 ) {
				dSumClassGram += 1.0 * n/m_nSentNum * log((double)n);
			}
		}
	}
	

	
	//Sum { N(g)logN(g) }
	int c, w;
	int *pCount;
	wbLHashIter<int,int> iterC(&m_classCount);
	while (pCount = iterC.Next(c)) {
		lout_assert(*pCount>=0);
		if ( *pCount != 0 )
			dSumClass += 1.0 * (*pCount) / m_nSentNum * log((double)(*pCount));
	}

	//Sum { N(w)logN(w) } 
// 	wbLHashIter<int,int> iterW(&m_wordCount);
// 	while (pCount = iterW.Next(w)) {
// 		lout_assert(*pCount>=0);
// 		if ( *pCount != 0 )
// 			dSumWord += 1.0 * (*pCount) / m_nSentNum * log((double)(*pCount));
// 	}

	double dRes = dSumClassGram - 2*dSumClass + m_dWordLogSum;
	return dRes;
}

void wbWordCluster::MoveWord(int nWord, bool bOut /* = true */)
{
	int nClass = m_aClass[nWord];
	int sig = (bOut)? -1: 1;

	// class unigram
	int *pCount = m_wordCount.Find(nWord);
	if (pCount == NULL)
		return;
	CountAdd(m_classCount, nClass, sig*(*pCount));
	

	// class bigram
	int g[10];
	int w[10];

	g[1] = nClass;
	wbTrie<int,int> *pSub = m_classWordCount.FindTrie(&nWord, 1);
	if (pSub) {  //�������п��ܵ�ǰ��class
		wbTrieIter<int, int> iter(*pSub);
		wbTrie<int,int> *p;
		while (p = iter.Next(g[0])) {
			CountAdd(m_pClassGramCount, g, 2, sig*(*p->GetData()));
		}
	}

	g[0] = nClass;
	pSub = m_wordClassCount.FindTrie(&nWord, 1);
	if (pSub) { //�������п��ܵĺ��class
		wbTrieIter<int, int> iter(*pSub);
		wbTrie<int,int> *p;
		while (p = iter.Next(g[1])) {
			CountAdd(m_pClassGramCount, g, 2, sig*(*p->GetData()));
		}
	}

	g[0] = nClass;
	g[1] = nClass;
	w[0] = nWord;
	w[1] = nWord;
	pCount = m_wordGramCount.Find(w, 2);
	if (pCount) {
		CountAdd(m_pClassGramCount, g, 2, *pCount); //����count
	}

	// word class pair
	
	int v;
	g[1] = nClass;

// 	int a1=0, a2=0;
// 	int b1=0, b2=0;
// 	wbLHashIter<int,int> vocabIter(&m_wordCount);
// 	while (vocabIter.Next(v)) { //�������еĴ�v
// 		g[0] = v;
// 
// 		w[0] = v;
// 		w[1] = nWord;
// 		pCount = m_wordGramCount.Find(w, 2);
// 		if (pCount) {
// 			a1 ++;
// 			CountAdd(m_wordClassCount, g, 2, sig*(*pCount));
// 		}
// 
// 		w[0] = nWord;
// 		w[1] = v;
// 		pCount = m_wordGramCount.Find(w, 2);
// 		if (pCount) {
// 			b1 ++;
// 			CountAdd(m_classWordCount, g, 2, sig*(*pCount));
// 		}
// 	}

	//����nWord��ǰ��
	pSub = m_invWordGram.FindTrie(&nWord, 1);
	if ( pSub ) {
		wbTrieIter<int, int> iter(*pSub);
		wbTrie<int,int> *p;
		while (p = iter.Next(v)) {
			g[0] = v;
			w[0] = v;
			w[1] = nWord;
//			pCount = m_wordGramCount.Find(w, 2);
// 			if ( *pCount != *(p->GetData()) ) {
// 				lout_error("ERROR_test");
// 			}
			pCount = p->GetData();
			if (pCount) {
				//a2++;
				CountAdd(m_wordClassCount, g, 2, sig*(*pCount));
			}
		}
	}
	//����nWord���
	pSub = m_wordGramCount.FindTrie(&nWord, 1);
	if ( pSub ) {
		wbTrieIter<int, int> iter(*pSub);
		wbTrie<int,int> *p;
		while (p = iter.Next(v)) {
			g[0] = v;
			pCount = p->GetData();
			if (pCount) {
				//b2++;
				CountAdd(m_classWordCount, g, 2, sig*(*pCount));
			}
		}
	}

// 	lout_variable(a1);
// 	lout_variable(a2);
// 	lout_variable(b1);
// 	lout_variable(b2);
// 	Pause();
}

void wbWordCluster::ExchangeWord(int nWord, int nToClass)
{
	if (nToClass == m_aClass[nWord])
		return;

	MoveWord(nWord, true); // move out from nClass
	m_aClass[nWord] = nToClass;
	MoveWord(nWord, false); // move into nToClass

// 	m_aClass[nWord] = nToClass;
// 	UpdataCount();
}

void wbWordCluster::Cluster(int nMaxTime /* = -1 */)
{
	bool bChange = false;
	int nTimes = 0;


	lout_variable(m_nVocabSize);
	//��δ���ֵ�word�ֵ�ͬһ��
	for (int w=0; w<m_nVocabSize; w++) {
		if ( m_wordCount.Find(w) == NULL ) {
			m_aClass[w] = m_nClassNum-1; ///< �������һ����
		}
	}

	while (1)  //���ѭ��
	{
		bChange = false;
		int w;
// 		wbLHashIter<int,int> vocabIter(&m_wordCount);
// 		while (vocabIter.Next(w)) //����ÿ��word
		for (w=0; w<m_nVocabSize; w++)
		{  
			if ( m_wordCount.Find(w) == NULL)
				continue;

			int nOldClass = m_aClass[w]; //����Ŀǰ��class
			int nOptClass = -1;
			double dOptValue = -1e22; //������Ȼֵ

			for (int c=0; c<m_nClassNum-1; c++) //ת�Ƶ�ÿ��class
			{ 
				ExchangeWord(w, c);
				double dCurValue = LogLikelihood(); //�滻��ĸ�������Ȼֵ
				if (dCurValue > dOptValue) {
					dOptValue = dCurValue;
					nOptClass = c;
				}
			}
#ifdef _DEBUG
			//lout<<"class_"<<nOldClass<<" -> class_"<<nOptClass<<endl;
#endif
			ExchangeWord(w, nOptClass);
			if (nOptClass != nOldClass) {//�ı�����
				lout<<"[exchange_"<<nTimes+1<<"] "<<w<<" class_"<<nOldClass<<" -> class_"<<nOptClass<<" value="<<dOptValue<<endl;
				bChange = true;
				if ( nOptClass >= m_nClassNum-1 ) {
					lout_error("[cluster] δ�����to class-id ("<<nOptClass<<") for word ("<<w<<") ");
				}
				/*Pause();*/
			}
		}

		lout_variable(LogLikelihood());
		//ͳ����ÿ��class�еĴ���Ŀ
		wbArray<int> aNum(m_nClassNum);
		aNum.Fill(0);
// 		vocabIter.Init();
// 		while (vocabIter.Next(w)) {
		for (w = 0; w<m_nVocabSize; w++) {
			if ( m_aClass[w] >= m_nClassNum ) {
				lout_error("[cluster] δ�����class-id ("<<m_aClass[w]<<") for word ("<<w<<") ");
			}
			aNum[m_aClass[w]] ++;
		}

		for (int i=0; i<m_nClassNum; i++)
			lout<<i<<"["<<aNum[i]<<"] ";
		lout<<endl;

		//��ӡ��ǰ�Ľ��
		if (m_pathWordClass)
			WriteRes_WordClass(m_pathWordClass);
		if (m_pathClassWord)
			WriteRes_ClassWord(m_pathClassWord);
		if (m_pathTagVocab)
			WriteRes_TagVocab(m_pathTagVocab);

		nTimes++;
		if (nTimes == nMaxTime) {
			lout<<"[end] Get Max Times"<<endl;
			break;
		}
		if (!bChange) {
			lout<<"[end] No Change"<<endl;
			break;
		}
	}

	
}

void wbWordCluster::SimpleCluster()
{
	// ����
	wbHeap<int, int> heap(HEAPMODE_MAXHEAP);
	for (int w=0; w<m_nVocabSize; w++) {
		int *p = m_wordCount.Find(w);
		int nTemp = 0;;
		if ( p==NULL )
			nTemp = 0;
		else
			nTemp = (int) sqrt( (double) (*p) );  ///< �Դ�Ƶ����ƽ����
		heap.Insert(w, nTemp);
	}

	
	int n = -1;
	int w, count, preCount = -1;
	while ( heap.OutTop(w, count) ) {
		
		//ȷ����ǰ��class
		if ( count != preCount ) {
			preCount = count;
			n++;
		}


		if ( n>= m_nClassNum )
			m_aClass[w] = m_nClassNum-1;
		else
			m_aClass[w] = n;
		
	}
}