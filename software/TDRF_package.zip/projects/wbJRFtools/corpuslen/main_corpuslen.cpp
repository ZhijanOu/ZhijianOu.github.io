// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// count the corpus length distribution.
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/**
 * \dir
 * \author wangbin
 * \date 2014-03-18
 * \todo ͳ��Ԥ�ϳ��ȷֲ���wordΪ��λ
 * \brief ͳ��Ԥ�ϳ��ȷֲ���wordΪ��λ
*/
/**
 * \file
 * \author wangbin
 * \date 2014-03-18
 * \brief [main]
 */
#include "wbSystem.h"
#include "wbSystem.cpp"

static char *cfg_pathTxt = NULL;
static char *cfg_pathOut = NULL;
static int cfg_nMaxLen = 10000;

wbOption options[] = {
	{wbOPT_STRING, "txt", &cfg_pathTxt, "txt corpus"},
	{wbOPT_STRING, "out", &cfg_pathOut, "out corpus"},
	{wbOPT_INT, "max-len", &cfg_nMaxLen, "max-len, ���������ɸѡ����"}
};

_wbMain
{
	wbOpt_Parse(options);

	wbLargeFile fileTxt(cfg_pathTxt, "rt");
	wbLargeFile fileOut;
	if ( cfg_pathOut )
		fileOut.Open(cfg_pathOut, "wt");

	wbArray<int> aLenCount(10000);
	aLenCount.Fill(0);
	int nTotalSent = 0;
	int nSiftSent = 0;

	char *pLine;
	while (pLine = fileTxt.GetLine(true) ) {
		if ( strlen(pLine) <= 0 )
			continue;
		
		wbString strSave(pLine);

		int nLen = 0;
		char *p = strtok(pLine, " \t");
		while (p) {
			nLen++;
			p = strtok(NULL, " \t");
		}

		aLenCount[nLen]++;
		nTotalSent++;

		if ( nLen <= cfg_nMaxLen ) {
			nSiftSent++;
			if ( cfg_pathOut ) {
				fileOut.PutLine(strSave);
			}
		}
	}

	for (int i=1; i<aLenCount.GetNum(); i++) {
		lout<<i<<"["<<aLenCount[i]<<"]{";
		//cout.precision(2);
		lout<<100.0*aLenCount[i]/nTotalSent<<"%} ";
	}
	lout<<endl;

	lout_variable_precent(nSiftSent, nTotalSent);

	return 1;
};