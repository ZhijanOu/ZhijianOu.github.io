// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// System file
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbSystem.h"
#include <windows.h>

// ================= ��̬�������� =========================
wbLog lout;

//========================wbPath ==========================
wbPath::wbPath()
{
	memset(m_pathPack, '\0', sizeof(char)*MAX_PATHPACK_LEN);
	memset(m_pPath, 0, sizeof(char*)*MAX_PATH_NUM);
	m_nPathNum = 0;
	m_pPathQueue = NULL;
}
wbPath::wbPath(char *p_pPath)
{
	strcpy(m_pathPack, p_pPath);
	memset(m_pPath, 0, sizeof(char*)*MAX_PATH_NUM);
	m_nPathNum = 0;
	m_pPathQueue = NULL;
}
wbPath::~wbPath()
{
	if (m_pPathQueue != NULL)
	{
		for (int i=0; i<m_pPathQueue->m_nTop; i++)
			SAFE_DELETE_ARRAY(m_pPathQueue->Get(i));
		SAFE_DELETE(m_pPathQueue);
	}	
}
void wbPath::pathUnPack()
{
	m_nPathNum = 0;
	bool bLocked = false;
	
	char *pChar = m_pathPack;
	char *pStrHead = pChar;
	int nLen = strlen(m_pathPack);

	for (int i=0; i<=nLen; i++)
	{
		if (*pChar == '"')
			bLocked = !bLocked;
		if ( (bLocked == false && *pChar == '+') || *pChar == '\0')
		{
			*pChar = '\0';
			if (*pStrHead == '"')
			{
				*(pChar-1) = '\0';
				pStrHead++;
			}

			////////Get a path///////
			if (m_nPathNum >= MAX_PATH_NUM)
			{
				cout<<"path<���������> ��������������� "<<MAX_PATH_NUM<<endl;
				return;
			}
			m_pPath[m_nPathNum] = pStrHead;
			m_nPathNum++;
			///////////////

			pStrHead = pChar+1;
		}

		pChar++;
	}
}
void wbPath::pathSearch()
{
	m_pPathQueue = new wbQueue<char*>;

	for (int i=0; i<m_nPathNum; i++)
	{
		//process fileName
		WIN32_FIND_DATAA fd;
		BOOL bRed = TRUE;
		HANDLE hFile = FindFirstFileA(m_pPath[i], &fd);
		while (hFile != INVALID_HANDLE_VALUE && bRed)
		{
			char *p = new char[MAX_PATH_LEN];
			strcpy(p, m_pPath[i]);
			char *temp = strrchr(p, '\\');
			if (temp == NULL)
				temp = p;
			else
				temp++;
			*temp = '\0';
			strcat(p, fd.cFileName);

			m_pPathQueue->In(p);

			bRed = FindNextFileA(hFile, &fd);
		}
	}
}
bool wbPath::GetPath( char *p_path )
{
	if (p_path == NULL)
		return false;
	if (m_pPathQueue == NULL)
	{
		pathUnPack();
		pathSearch();
	}

	char *pTemp;
	if (false == m_pPathQueue->Out(&pTemp))
		return false;
	strcpy(p_path, pTemp);
	SAFE_DELETE_ARRAY(m_pPathQueue->Get(m_pPathQueue->m_nBottom-1));
	return true;
}

void wbPath::LoadListFile( char *p_pBasePath /*= ""*/, char *p_pSuffix/* =""*/, char *p_pListFile /*= NULL*/ )
{
	if (p_pListFile == NULL)
		p_pListFile = m_pathPack;

	FILE *fp = NULL;
	SAFE_FOPEN(fp, p_pListFile, "rt");

	m_pPathQueue = new wbQueue<char*>;
	PATH path;
	while (fgets(path, MAX_PATH_LEN, fp))
	{
		path[strlen(path)-1] = '\0';
		char *p = new char[MAX_PATH_LEN];
		strcpy(p, p_pBasePath);
		strcat(p, path);
		strcat(p, p_pSuffix);
		m_pPathQueue->In(p);
	}

	fclose(fp);
}

//=========================wbConfig========================
wbConfig::wbConfig(int p_ncNum, char** p_ppCVec, bool p_bCopy/* =false */)
{
	m_nConfigNum = p_ncNum;
	m_bCopy = p_bCopy;

	if (m_bCopy)
	{
		m_ppConfigVec = new char*[m_nConfigNum];
		for (int i=0; i<m_nConfigNum; i++)
		{
			m_ppConfigVec[i] = new char[strlen(p_ppCVec[i])+1];
			strcpy(m_ppConfigVec[i], p_ppCVec[i]);
		}
	}
	else
		m_ppConfigVec = p_ppCVec;

	//Value
	m_pValue = new wbConfig_Value[CONFIG_VALUE_NUM];
	m_nValueNum = 0;

	m_pProgramDepiction = NULL;
}


wbConfig::~wbConfig(void)
{
	m_nConfigNum = 0;

	if (m_bCopy)
	{
		for (int i=0; i<m_nConfigNum; i++)
			delete [] m_ppConfigVec[i];
		delete [] m_ppConfigVec;
	}

	SAFE_DELETE_ARRAY(m_pValue);
}

bool wbConfig::ScanConfig(const char* p_format, void* p_pValue)
{
	if (p_pValue == NULL)
	{
		for (int i=0; i<m_nConfigNum; i++)
		{
			if (strcmp(p_format, m_ppConfigVec[i]) == 0)
				return true;
		}
	}
	else
	{
		for (int i=0; i<m_nConfigNum; i++)
		{
			if (sscanf(m_ppConfigVec[i], p_format, p_pValue))
				return true;
		}
	}
	return false;
}

void wbConfig::PrintConfig(ostream &p_out /* = cout */)
{
	for (int i=0; i<m_nConfigNum; i++)
		p_out<<m_ppConfigVec[i]<<endl;
}

void wbConfig::ValueLabel(const char* p_pForamt, void* p_pValue, const char* p_pDepiction)
{
	if (m_nValueNum == CONFIG_VALUE_NUM)
	{
		cout<<"ValueLabel Error: config value buffer is too SMALL"<<endl;
		return;
	}
	wbConfig_Value *p = &m_pValue[m_nValueNum];
	p->pValue = p_pValue;
	p->pFormat = p_pForamt;
	p->pDepiction = p_pDepiction;
	p->bExist = false;

	m_nValueNum++;
}

bool wbConfig::ValueSet()
{
	if (m_nConfigNum == 1)
	{
		ValueUsage();
		return false;
	}

	wbConfig_Value *p = NULL;
	for (int i=0; i<m_nValueNum; i++)
	{
		p = m_pValue+i;
		p->bExist = ScanConfig(p->pFormat, p->pValue);
	}
	return true;
}

void wbConfig::ValuePrint()
{
	for (int i=0; i<m_nValueNum; i++)
	{
		wbConfig_Value *p = m_pValue+i;	

		if (p->pValue == NULL)
		{
			if (p->bExist) 
			{
				printf(p->pFormat);
				printf("\n");
			}
		}
		else
		{
			switch( *(p->pFormat+strlen(p->pFormat)-1) )
			{
			case 's':
				printf(p->pFormat, (char*)(p->pValue));
				break;
			case 'c':
				printf(p->pFormat, *(char*)(p->pValue));
				break;
			case 'd':
				printf(p->pFormat, *(int*)(p->pValue));
				break;
			case 'f':
				printf(p->pFormat, *(float*)(p->pValue));
				break;
			}
			printf("\n");
		}
	}
}

void wbConfig::ValueUsage()
{
	if (m_pProgramDepiction != NULL)
	{
		printf("%s\n", m_pProgramDepiction);
	}
	for (int i=0; i<m_nValueNum; i++)
	{
		wbConfig_Value *p = m_pValue+i;

		printf("%s\t", p->pFormat);
		if (p->pDepiction != NULL)
			printf("%s", p->pDepiction);
		printf("\n");
	}
}

bool wbConfig::ValueExist(const char* p_label)
{
	for (int i=0; i<m_nConfigNum; i++)
	{
		if (strcmp(p_label, m_ppConfigVec[i]) == 0)
			return true;
	}
	return false;
}


//===================wbClock====================
wbClock::wbClock(void)
{
	m_bWork = false;
	m_nBeginTime = 0;
	m_nEndTime = 0;
}

wbClock::~wbClock(void)
{
	m_bWork = false;
	m_nBeginTime = 0;
	m_nEndTime = 0;
}

void wbClock::Clean()
{
	m_bWork = false;
	m_nBeginTime = 0;
	m_nEndTime = 0;
}

clock_t wbClock::Begin()
{
	m_bWork = true;
	return (m_nBeginTime = clock());
}

clock_t wbClock::End()
{
	if (m_bWork == false)
		return 0.0;
	m_bWork = false;
	m_nEndTime = clock();
	return m_nEndTime - m_nBeginTime;
}

clock_t wbClock::Get()
{
	return clock() - m_nBeginTime;
}



//=====================�ٷֺ����==================================
void outPrecent(long long n, bool bNew /*= false*/, long long nTotal /*= 100*/, const char* title /*= "Process"*/)
{
// 	static size_t snLastPrecent = 0;
// 	static size_t snTotal = 100;
// 	if (bNew)
// 	{
// 		if (nTotal > 0)
// 			snTotal = nTotal;
// 		snLastPrecent = n * 100 / snTotal;
// 		cout<<title<<":";
// 		cout.width(3);
// 		cout<<snLastPrecent<<"%";
// 		cout.flush();
// 	}
// 	else
// 	{
// 		int nNew = (int)(1.0*n/snTotal*100);
// 		if ( nNew > snLastPrecent )
// 		{
// 			snLastPrecent = nNew;
// 			cout<<"\b\b\b\b";
// 			cout.width(3);
// 			cout<<snLastPrecent<<"%";
// 			cout.flush();
// 		}
// 	}

	static int snLastPrecent = 0;
	static long long snTotal = 100;
	static char strTitle[500];

	static clock_t begtime = 0;

	bool bUpdate = false;
	if (bNew)
	{
		if (nTotal > 0)
			snTotal = nTotal;
		snLastPrecent = n * 100 / snTotal;
		strcpy(strTitle, title);
		bUpdate = true;

		begtime = clock();
	}
	else
	{

		int nNew = (int)(1.0*n/snTotal*100);
		if ( nNew > snLastPrecent )
		{
			snLastPrecent = nNew;

			bUpdate = true;
		}
	}

	if (bUpdate)
	{
		if (bNew)
			cout<<title<<":";
		else
			cout<<"\b\b\b\b";

		cout.width(3);
		cout<<snLastPrecent<<"%";
	}
}

void outPrecent(ifstream &ifile, bool bNew, const char* title)
{
	if (bNew)
	{
		ifile.seekg(0, ios_base::end);
		outPrecent(0, true, ifile.tellg(), title);
		ifile.seekg(0, ios_base::beg);
	}
	else
	{
		outPrecent(ifile.tellg());
	}
}

void outPrecent(FILE* fp, bool bNew, const char* title)
{
	if (bNew)
	{
		long long iCur = _ftelli64(fp);
		_fseeki64(fp, 0, SEEK_END);
		outPrecent(iCur, true, _ftelli64(fp), title);
		_fseeki64(fp, iCur, SEEK_SET);
	}
	else
	{
		outPrecent(_ftelli64(fp));
	}
}

void titlePrecent(long long n /* = -1 */, short nState /* = 0 */, long long nTotal /* = 100 */, const char* title /* = "Process" */)
{
	/// 2014-5-21,wb: ��n<0, ��ʹ�����õļ�����
	static int snLastPrecent = 0;
	static long long snTotal = 100;
	static long long snCur = 0;
	static char strTitle[500] = "";
	static char strLabel[500] = "Process";

	static clock_t begtime = 0;

	bool bUpdate = false;
	if (nState == 1) //��ʼ��
	{
		if (nTotal > 0)
			snTotal = nTotal;
		snLastPrecent = n * 100 / snTotal;
		snCur = n;
		strcpy(strLabel, title);
		bUpdate = true;
		
		begtime = clock();
	}
	else if (nState == 0) //����update
	{
		if ( n < 0 ) {
			snCur++;
		} else {
			snCur = n;
		}
		int nNew = (int)(1.0*snCur/snTotal*100);
		if ( nNew > snLastPrecent )
		{
			snLastPrecent = nNew;

			bUpdate = true;
		}
	} 
	else if ( nState == 2 ) //�趨title
	{
		strcpy(strTitle, title);
		Title(strTitle);
	}
	
	if (bUpdate)
	{
		char command[MAX_CMD_TITLE_LEN + 10];

		clock_t lasttime = clock() - begtime;
		double remtime = (snLastPrecent==0)? -1: 1.0*lasttime/1000 * (100-snLastPrecent) / snLastPrecent;

		sprintf(command, "title \"%s %s%3d%% [%ds]\"", strTitle, strLabel, snLastPrecent, (int)remtime);
		system(command);
	}
}

void titlePrecent(ifstream &ifile, bool bNew, const char* title )
{
	if (bNew)
	{
		ifile.seekg(0, ios_base::end);
		titlePrecent(0, true, ifile.tellg(), title);
		ifile.seekg(0, ios_base::beg);
	}
	else
	{
		titlePrecent(ifile.tellg());
	}
}

void titlePrecent(FILE* fp, bool bNew, const char* title)
{
	if (bNew)
	{
		//fseek(fp, 0, SEEK_END);
		long long iCur = _ftelli64(fp);
		_fseeki64(fp, 0, SEEK_END);
		//lout_variable(_ftelli64(fp));
		titlePrecent(iCur, true, _ftelli64(fp), title);
		_fseeki64(fp, iCur, SEEK_SET);
	}
	else
	{
		titlePrecent(_ftelli64(fp));
	}
}


unsigned Char2Num(const char *info)
{
	lout_error("������ʹ���˺���Char2Num���ʺ����Ĺ����Ѿ���ʱ����ʹ���º���wbChTxt::Char2Num������");
	unsigned n1 = (unsigned)(info[0]&0x000000ff);
	unsigned n2 = (unsigned)(info[1]&0x000000ff);
	unsigned n3 = n1*256 + n2 - GS_CHAR_BASE_ZH;
	return n3;
}

void Num2Char(unsigned n, char *info)
{
	n += GS_CHAR_BASE_ZH;
	unsigned n1 = n/256;
	unsigned n2 = n%256;
	info[0] = n1;
	info[1] = n2;
}

bool bChSymbol(const char *str )
{
	if ( ((unsigned char)str[0]) <= 9 + 0xA0 ) //GB2312�����У�1��9��λ����
		return true;
	return false;
};
bool bChCharSeq(const char *str)
{
	int nLen = strlen(str);
	if (nLen%2 == 1)
		return false;

	for (int i=0; i<nLen; i+=2)
	{
		if (str[i] > 0 || bChSymbol(str+i))
			return false;
	}
	return true;
}


void Pause()
{
	lout<<"[Press any key to continue...]"<<endl;
	getch();
}
void Title(const char *p)
{
	char command[MAX_CMD_TITLE_LEN + 10];
	sprintf(command, "title \"%s\"", p);
	system(command);
}