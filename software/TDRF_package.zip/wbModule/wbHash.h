// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Hash class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/**
 * \file 
 * \author wangbin
 * \date 2013-9-23
 * \brief ����д�Ĺ�ϣ�����Ѿ�����ʹ�ã���鿴 wbLHash
*/
#ifndef _WB_HASH_H_
#define _WB_HASH_H_
#include "wbSystem.h"

#define WBHASH_LSIZE_CH 256
#define WBHASH_LSIZE_EN 128

/// ����д�Ĺ�ϣ���ڵ㣬�Ѿ�����ʹ�ã���鿴 wbLHash
template <typename T>
class wbHashNode
{
public:
	bool bExit;  
	int w; //weight
	T m;
	wbHashNode<T> *p; // pointer to next level

	wbHashNode<T>() { bExit = false; p = NULL; w = -1;}
};

/// ����д�Ĺ�ϣ�����Ѿ�����ʹ�ã���鿴 wbLHash
template <typename T>
class wbHash
{
public:
	int m_levelSize;
	wbHashNode<T> *m_pLevel;

public:
	wbHash<T>(int levelSize = WBHASH_LSIZE_CH ) 
	{ 
		m_levelSize = levelSize;  
		m_pLevel = new wbHashNode<T>[m_levelSize]; 
	}
	~wbHash<T>()
	{
		Delete(m_pLevel);
	}

	bool Delete(wbHashNode<T> *p)
	{
		if (p == NULL)
			return true;

		for (int i=0; i<m_levelSize; i++)
			Delete(p[i].p);
		delete []p;
		return true;
	}

	void Add(int *pos, int len, T m)
	{
		wbHashNode<T> *p = Get(pos, len, true);
		p->bExit = true;
		p->m = m;
	}

	wbHashNode<T>* Find(int *pos, int len)
	{
		wbHashNode<T> *p = Get(pos, len, false);
		if (p == NULL)
			return p;
		if (p->bExit == false)
			return NULL;
		return p;
	}

	wbHashNode<T>* Get(int *pos, int len, bool bCreate = false)
	{
		wbHashNode<T> *p = m_pLevel;

		for (int i=0; i<len-1; i++)
		{
			if (pos[i] >= m_levelSize)
			{
				cout<<"[ERROR]wbHash: OVER FLOW!"<<endl;
				return NULL;
			}

			if (p[pos[i]].p == NULL)
			{
				if (!bCreate)
					return NULL;
				p[pos[i]].p = new wbHashNode<T>[m_levelSize];
			}
			p = p[pos[i]].p;
		}
		return &p[pos[len-1]];
	}

public:
	int c2u(char c)
	{
		return (unsigned char)c;
	}
	void Add(const char *str, T m)
	{
		wbHashNode<T> *p = Get(str, true);
		p->bExit = true;
		p->m = m;
	}

	wbHashNode<T>* Find(const char *str)
	{
		wbHashNode<T> *p = Get(str, false);
		if (p == NULL)
			return p;
		if (p->bExit == false)
			return NULL;
		return p;

	}

	wbHashNode<T>* Get(const char *str, bool bCreate = false)
	{
		int len = strlen(str);

		wbHashNode<T> *p = m_pLevel;

		for (int i=0; i<len-1; i++)
		{
			int pos = c2u(str[i]);
			if (pos >= m_levelSize)
			{
				cout<<"[ERROR]wbHash: OVER FLOW!"<<str<<endl;
				return NULL;
			}

			if (p[pos].p == NULL)
			{
				if (!bCreate)
					return NULL;
				p[pos].p = new wbHashNode<T>[m_levelSize];
			}
			p = p[pos].p;
		}
		return &p[c2u(str[len-1])];
	}

};



#endif