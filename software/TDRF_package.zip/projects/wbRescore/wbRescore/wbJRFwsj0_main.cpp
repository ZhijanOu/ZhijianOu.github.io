// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF models rescore
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.

/**
 * \dir
 * \author WangBin
 * \date 2015-1-13
 * \todo JRFģ�ͣ���kaldi���ɵ�nbest list����rescore
 * \brief JRFģ�ͣ���kaldi���ɵ�nbest list����rescore
*/
/**
 * \file
 * \author wangbin
 * \date 2015-1-13
 * \brief [main]
 */
#include "wbSystem.h"
#include "wbVocab.h"
#include "JRF\wbJRFCDmodel.h"
//#include "wbFsgNBestDecoder.h"
using namespace wbJRF;

#ifdef _JRF_WSJ0
static char *cfg_pathListFile = NULL;

static char *cfg_pathModel = NULL;
static char *cfg_pathVocab = NULL;
static char *cfg_pathTagVocab = NULL;
static char *cfg_strType = "scheme1";

static char *cfg_pathLmscoreFile = NULL;
static char *cfg_pathWriteCiList = NULL;
static char *cfg_pathWriteCinoList = NULL;

static char *cfg_strTitle = "wbRescore";

wbOption options[] = {
	{wbOPT_STRING, "list", &cfg_pathListFile, "kaldi���ɵ� list ���ļ�"},
	{wbOPT_STRING, "model", &cfg_pathModel, "[Input], model"},
	{wbOPT_STRING, "type", &cfg_strType, "[Input], ģ������(scheme1 or scheme2),(default = scheme1)"},
	{wbOPT_STRING, "vocab", &cfg_pathVocab, "[Input], model vocabulary"},
	{wbOPT_STRING, "tag-vocab", &cfg_pathTagVocab, "[Input], model vocabulary containing class informations"},

	{wbOPT_STRING, "lmscore", &cfg_pathLmscoreFile, "���´�ֵ�lmscore�ļ�"},
	{wbOPT_STRING, "write-ci-list", &cfg_pathWriteCiList, "����ʹ���´ʵ�Լ����ci�ļ�"},
	{wbOPT_STRING, "write-cino-list", &cfg_pathWriteCinoList, "����ʹ���´ʵ�Լ����cino�ļ�"},
	{wbOPT_STRING, "title", &cfg_strTitle, "title"}
};

_wbMain
{
	wbOpt_Parse(options);

	//�����ֵ�
 	Vocab v(cfg_pathVocab);
	if ( cfg_pathTagVocab )
		v.LoadVocabInfo(cfg_pathTagVocab);

	//����ģ��
 	CDmodel *pM = NULL;
	wbString strtype = cfg_strType;
	if (strtype == "scheme1")
		pM = new CDmodel_len(&v);
	else if (strtype == "scheme2")
		pM = new CDmodel(&v);
	lout<<"Read model -> "<<cfg_pathModel<<endl;
	pM->ReadT(wbFile(cfg_pathModel, "rt"));
	pM->PrepareInitModel(false);

	//Ϊ�ֵ���hash
	wbLHash<const char*, int> vocabHash;
	bool bFound;
	for (int i=0; i<v.aWords.GetNum(); i++) {
		int *pId = vocabHash.Insert( v.aWords[i].Toupper(), bFound );
		if ( bFound ) {
			lout_warning("�����ظ���word��Ӧ��ͬid =��"<<v.aWords[i]);
		}
		*pId = i;
	}


	wbFile fileCiList(cfg_pathListFile, "rt");
	wbFile fileLmsore(cfg_pathLmscoreFile, "wt");
	wbFile fileWriteCi, fileWriteCino;
	if ( cfg_pathWriteCiList ) fileWriteCi.Open(cfg_pathWriteCiList, "wt");
	if ( cfg_pathWriteCinoList ) fileWriteCino.Open(cfg_pathWriteCinoList, "wt");


	lout<<"Begin Resocre"<<endl;

	wbClock clk;
	clk.Begin();

	char *pline = NULL;
	while ( pline = fileCiList.GetLine() ) {

		double lmscore = INF;

		char *pLabel = strtok(pline, " \t");

		//��ȡ��ǰ���ÿ��ci
		wbArray<wbString> aSrcCi;
		char *pCi = strtok(NULL, " \t");
		while (pCi) {
			aSrcCi.Add( wbString(pCi).Toupper() );
			pCi = strtok(NULL, " \t");
		}

		//ת��Ϊcino
		wbArray<int> aCino;
		for (int i=0; i<aSrcCi.GetNum(); i++) {
			int *pId = vocabHash.Find(aSrcCi[i].GetBuffer());
			if ( pId == NULL ) { //����<unk>
				if ( (pId = vocabHash.Find("<UNK>")) == NULL ) {
					pId = vocabHash.Find("<unk>");
				}
			}
			if ( pId == NULL ) {
				lout_error("û���ҵ���ǰ�˵�id ->"<<pLabel<<" ci->"<<aSrcCi[i]);
			}
			aCino[i] = *pId;
		}

		//���
		lmscore = -pM->GetLogProb( aCino, aCino.GetNum() );

		//дlmscore
		fileLmsore.Print("%s %lf\n", pLabel, lmscore);
		//дci��cino
// 		fileWriteCi.Print("%s ", pLabel);
// 		fileWriteCino.Print("%s ", pLabel);
		for (int i=0; i<aCino.GetNum(); i++) {
			fileWriteCi.Print("%s ", v.aWords[ aCino[i] ].GetBuffer() );
			fileWriteCino.Print("%d ", aCino[i]);
		}
		fileWriteCi.Print("\n");
		fileWriteCino.Print("\n");
	}
	double totalsecond = clk.ToSecond( clk.End() );
	lout<<"Total time = "<<totalsecond<<"s"<<endl;
	
	SAFE_DELETE(pM);

	return 1;
};

#endif