// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// Transform the no file to id file. i.e minus the number by 2
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


/**
 * \dir
 * \author wangbin
 * \date 2014-12-15
 * \todo �ʺ�ת��ΪJRF��ID����ÿ����ֵ-2����ΪJRF�ֵ�û�п�ʼ������
 * \brief �ʺ�ת��ΪJRF��ID����ÿ����ֵ-2����ΪJRF�ֵ�û�п�ʼ������
*/
/**
 * \file
 * \author wangbin
 * \date 2014-12-15
 * \brief [main]
 */
#include "wbSystem.h"
#include "wbSystem.cpp"
#include "JRF\wbJRFdef.h"

static char *cfg_pathTxt = NULL;
static char *cfg_pathBin = NULL;
static char *cfg_model = "cino2id";

wbOption options[] = {
	{wbOPT_STRING, "in", &cfg_pathTxt, "in corpus"},
	{wbOPT_STRING, "out", &cfg_pathBin, "out corpus"},
	{wbOPT_STRING, "mod", &cfg_model, "cino2id(default) or id2cino"}
};

_wbMain
{
	wbOpt_Parse(options);

	int nDiff = 0;
	if ( strcmp(cfg_model, "cino2id") == 0 )
		nDiff = -2;
	else
		nDiff = 2;

	wbFile fileIn(cfg_pathTxt, "rt");
	wbFile fileOut(cfg_pathBin, "wt");
	char *pLine;
	while ( pLine = fileIn.GetLine(true) )
	{
		wbArray<int> a;

		char *p = strtok(pLine, " \t\n");
		while (p) {
			a.Add( atoi(p) );
			p = strtok(NULL, " \t\n");
		}

		for (int i=0; i<a.GetNum(); i++) {
			fileOut.Print("%d ", a[i]+nDiff);
		}
		fileOut.Print("\n");
	}

	return 1;
};