// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2014-2015 Tsinghua University
// Author: wb.th08@gmail.com (Bin Wang), ozj@tsinghua.edu.cn (Zhijian Ou) 
//
// \file
// TDRF models, based class
// All h, cpp, cc, and script files (e.g. bat, sh, pl, py) should include the above 
// license declaration. Different coding language may use different comment styles.


#include "wbJRFMLmodel.h"

namespace wbJRF
{
	/************************************************************************/
	/* Ϊ������һ�������͵���������Ҫ�����������Ķ�
	/* 1����GetGramIndex��Ϊ�����������������㷨
	/* 2����FindFeatures�����Ӵ��룬�����ܹ��ҵ���������, ClassModel �е� FindFeatures_class ����Ҳ��Ҫ�Ķ�
	/* 3����LogExpectation�����Ӷ��ڴ����������ۼ��㷨
	/************************************************************************/


	void MLmodel::GetGramIndex(Ngram *pGram, VocabID *aIndex)
	{
		/**
			ͳһ��token��word��class��idӳ�䵽ͳһ�ռ䣬�������£�
			0����token_num-1��Ϊtoken��Ӧ����������token��Ӧ������id��ͬ��
			token_num����token_num+word_num-1��Ϊword��Ӧ��������index = word_id + token_num��
			֮����class��Ӧ��������index = class_id + token_num + word_num
		*/
		int order = pGram->order;
		if ( pGram->type == ngram || pGram->type == jgram || pGram->type == super ) {
			memcpy(aIndex, pGram->flag, sizeof(VocabID)*order);
		} else if ( pGram->type == wgram ) {
			for (int n=0; n<order; n++)
				aIndex[n] = (pGram->flag[n] != VocabID_none)? pGram->flag[n] + m_nWordIndexOffset : VocabID_none;
		} else if ( pGram->type == cgram ) {
			for (int n=0; n<order; n++)
				aIndex[n] = (pGram->flag[n] != VocabID_none)? pGram->flag[n] + m_nClassIndexOffset : VocabID_none;
		} else if ( pGram->type == pgram ) {
			PredictNgram *p = (PredictNgram*)pGram;
			for (int n=0; n<order-1; n++)
				aIndex[n] = (pGram->flag[n] != VocabID_none)? pGram->flag[n] + m_nWordIndexOffset : VocabID_none;
			if ( p->flag[order-1] == VocabID_none ) //f(w,c)
				aIndex[order-1] = (p->c != VocabID_none)? p->c + m_nClassIndexOffset : VocabID_none;
			else // f(w, cw)
				aIndex[order-1] = (p->c != VocabID_none)? m_pVocab->FindToken(p->flag[order-1], p->c) : p->flag[order-1] + m_nWordIndexOffset;
		} else if ( pGram->type == ggram ) {
			GlobalNgram *p = (GlobalNgram*)pGram;
			for (int n=0; n<order; n++) {
				if ( p->flag[n] != VocabID_none && p->cflag[n] != VocabID_none ) {//Token
					aIndex[n] = m_pVocab->FindToken(p->flag[n], p->cflag[n]);
					lout_error("[MLmodel] ��֧�ִ���ggram��ͬһλ��ָ��word��class��Ϣ�������FindFeatrue������֧�֣�");
				} else if ( p->flag[n] != VocabID_none ) // word
					aIndex[n] = p->flag[n] + m_nWordIndexOffset;
				else if ( p->cflag[n] != VocabID_none ) // class
					aIndex[n] = p->cflag[n] + m_nClassIndexOffset;
				else //��Ϊnone
					aIndex[n] = VocabID_none;
			}
		}
	}
	void MLmodel::FeaturesReHash()
	{
		lout<<"Feature Rehash [Beg]"<<endl;

		//new (&m_aGramIndex) wbTrie<VocabID, wbArray<int>*>;
		m_aGramIndex.Clean();
		for (int i=0; i<m_aGramPack.GetNum(); i++)
			SAFE_DELETE(m_aGramPack[i]);
		m_aGramPack.Clean();

		VocabID aIndex[ngram_maxOrder];
		titlePrecent(0, true, m_nFeatNum, "Rehash");
		for (int i=0; i<m_nFeatNum; i++) {
			///��������
			Ngram *pGram = (Ngram*)m_aFeatures[i];
			int order = pGram->order;
			
			//�����������ͣ�����������
			GetGramIndex(pGram, aIndex);
			
			bool bFound;
			wbArray<int> **pArray = m_aGramIndex.Find(aIndex, order, bFound);
			if ( !pArray ) { //û�ҵ���һ��Ҫʹ��Find���жϣ���ΪbFound���ر�ʾ�Ƿ��������ڵ㣬����������ڵ㲢����ζֻ������˽ڵ�����
				pArray = m_aGramIndex.Insert(aIndex, order, bFound);
				*pArray = new wbArray<int>(1);
				m_aGramPack.Add(*pArray);
			}
			(*pArray)->Add(i);

// 			if ( (*pArray)->GetNum() > 1024 ) {
// 				for (int j=0; j<order; j++) {
// 					lout<<aIndex[j]<<" ";
// 				}
// 				lout<<endl;
// 				for (int j=0; j<(*pArray)->GetNum(); j++) {
// 					lout<<(*pArray)->Get(j)<<" ";
// 				}
// 				lout<<endl;
// 				Pause();
// 			}

			titlePrecent(i+1);
		}
		lout<<"Feature Rehash [end]"<<endl;
	}

	LogP MLmodel::GetLogProb(VocabID *pSeq, int nLen, bool bNorm /*= true*/)
	{
		LogP logprob = 0;
		wbArray<int> aFeatrues;

		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			for (int h=0; h<=nLen-nOrder; h++) {
				aFeatrues.Clean();
				FindFeatures(aFeatrues, pSeq, nLen, h, nOrder);
				for (int i=0; i<aFeatrues.GetNum(); i++) {
					logprob += m_aValues[aFeatrues[i]];
				}
			}
		}
		
// 		for (int h=0; h<=nLen-m_nOrder; h++) {
// 			logprob += ClusterSum(pSeq, nLen, h);
// 		}

		return (bNorm)? NormalizeProb(logprob, nLen): logprob;
	}

	LogP MLmodel::GetWeightSum(VocabID *pSeq, int nLen, int nPos)
	{
		//������ngram���������ֻ��Ҫ����h����������
		LogP logprob = 0;
		wbArray<int> aFeatrues;
// 		int aFeat[c_nMaxFindFeatures];
// 		int nFeat = 0;

		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			for (int h=max(nPos-nOrder+1,0); h<=min(nPos,nLen-nOrder); h++) {
				aFeatrues.Clean();
				FindFeatures(aFeatrues, pSeq, nLen, h, nOrder);
				for (int i=0; i<aFeatrues.GetNum(); i++) {
					logprob += m_aValues[aFeatrues[i]];
				}
// 				nFeat = 0;
// 				FindFeatures(aFeat, nFeat, c_nMaxFindFeatures, pSeq, nLen, h, nOrder);
// 				for (int i=0; i<nFeat; i++) {
// 					logprob += m_aValues[aFeat[i]];
// 				}
			}
		}
		
		return logprob;
	}

	void MLmodel::ExtractFeatures(VocabID *pSeq, int nLen, int *pVec)
	{
		memset(pVec, 0, sizeof(pVec[0])*m_nFeatNum);
		wbArray<int> aFeatrues;

		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			for (int h=0; h<=nLen-nOrder; h++) {
				aFeatrues.Clean();
				FindFeatures(aFeatrues, pSeq, nLen, h, nOrder);
				for (int i=0; i<aFeatrues.GetNum(); i++) {
					pVec[aFeatrues[i]]++;
				}
			}
		}
	}

	void MLmodel::FindFeatures(wbArray<int> &a, VocabID *pSeq, int nLen, int h, int nOrder )
	{
		//a.Clean();
// 		VocabID aIndex[ngram_maxOrder];
// 		bool bFound;
// 
// 		// ��ͨGram����
// 		if (m_bContainTokenGram) 
// 		{
// 			
// 			wbArray<int> **ppFind = m_aGramIndex.Find(pSeq+h, nOrder, bFound);
// 			if (ppFind) {
// 				for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 					int id = (*ppFind)->Get(i);
// 					//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 					if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 						a.Add(id);
// 					}
// 				}
// 			}
// 		}
// 		// Class Gram ����
// 		if (m_bContainClassGram)
// 		{
// 			for (int i=0; i<nOrder; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
// 			wbArray<int> **ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 					int id = (*ppFind)->Get(i);
// 					//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 					if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 						a.Add(id);
// 					}
// 				}
// 			}
// 		}
// 
// 		// word Gram ����
// 		if (m_bContainWordGram)
// 		{
// 			for (int i=0; i<nOrder; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 			wbArray<int> **ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 					int id = (*ppFind)->Get(i);
// 					//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 					if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 						a.Add(id);
// 					}
// 				}
// 			}
// 		}
// 
// 		// model M�еĻ������
// 		// ��ʷȫ����word����ǰλ�ÿ���Ϊclass or token����f(w,c) or f(w, cw)
// 		if (m_bContainPredictGram)
// 		{
// 			for (int i=0; i<nOrder-1; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset; //��ʷȫ��Ϊword
// 
// 			// f(w,c)
// 			if (nOrder > 1) { //��order=1ʱ�������������˻�Ϊunigram-class��������ʹ��ͬһ��������������
// 				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].cid + m_nClassIndexOffset;
// 				wbArray<int> **ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 				if (ppFind) {
// 					for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 						int id = (*ppFind)->Get(i);
// 						//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 						if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 							a.Add(id);
// 						}
// 					}
// 				}
// 			}
// 			
// 			// f(w,cw)
// 			aIndex[nOrder-1] = pSeq[h+nOrder-1];
// 			wbArray<int> **ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 					int id = (*ppFind)->Get(i);
// 					//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 					if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 						a.Add(id);
// 					}
// 				}
// 			}
// 		}
// 
// 		//global gram
// 		//Ŀǰ��֧��ͬһλ�ò���ͬʱ����word��class��Ϣ,�ҽ���һ��classλ��
// 		if (m_bContainMixGram && nOrder>1)
// 		{
// 			//�ἤ���������
// 			for (int pos=0; pos<nOrder; pos++) //����class��λ��
// 			{
// 				for (int i=0; i<nOrder; i++) {
// 					if ( i != pos ) {//word��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 					} else { // class��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
// 					}
// 				}
// 				wbArray<int> **ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 				if (ppFind) {
// 					for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 						int id = (*ppFind)->Get(i);
// 						//if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 						if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h) ){
// 							a.Add(id);
// 						}
// 					}
// 				}
// 			}
// 		}
// 
// 
// 		if (!m_bContainJumpNgram)
// 			return;
// 
// 		// jumpGram����
// 		VocabID aSeq[c_nMaxOrder];
// 		memcpy(aSeq, pSeq+h, sizeof(VocabID)*nOrder);
// 		for (int k=1; k<=nOrder-2; k++) {
// 			aSeq[k] = VocabID_none;
// 			wbArray<int> **ppFind = m_aGramIndex.Find(aSeq, nOrder, bFound);
// 			if (ppFind) {
// 				for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 					int id = (*ppFind)->Get(i);
// 					if (m_aFeatures[id]->bAccept(pSeq, nLen, h)) {
// 						a.Add(id);
// 					}
// 				}
// 			}
// 
// 			aSeq[k] = pSeq[h+k];
// 		}

		VocabID aIndex[ngram_maxOrder];
		bool bFound;
		wbArray<int> **ppFind = NULL;
		wbArray<wbArray<int>**> aFindList;

		// ��ͨGram����
		if (m_bContainTokenGram) 
		{
			wbArray<int> **ppFind = m_aGramIndex.Find(pSeq+h, nOrder, bFound);
			if (ppFind) {
				aFindList.Add(ppFind);
			}
		}
		// Class Gram ����
		if (m_bContainClassGram)
		{
			for (int i=0; i<nOrder; i++)
				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;

			if ( nOrder < m_nFullGramLimitedOrder ) {
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
			}
			

			//class gram ����jump��Ϣ
			if ( m_bContainClassGram_jump && nOrder >= 3 ) 
			{
				FindJumpFeatures(aFindList, aIndex, nOrder);
			}
		}

		// word Gram ����
		if (m_bContainWordGram)
		{
			for (int i=0; i<nOrder; i++)
				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;

			// ����fullngram
			if ( nOrder < m_nFullGramLimitedOrder ) {
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
			}
			

			//word gram ����jump��Ϣ
			if ( m_bContainWordGram_jump && nOrder >= 3 ) 
			{
				FindJumpFeatures(aFindList, aIndex, nOrder);
			}
		}

		// model M�еĻ������
		// ��ʷȫ����word����ǰλ�ÿ���Ϊclass or token����f(w,c) or f(w, cw)
		if (m_bContainPredictGram && nOrder < m_nFullGramLimitedOrder )
		{
			for (int i=0; i<nOrder-1; i++)
				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset; //��ʷȫ��Ϊword

			// f(w,c)
			if (nOrder > 1 || m_bContainClassGram==false) { //��order=1ʱ�������������˻�Ϊunigram-class��������ʹ��ͬһ��������������
				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].cid + m_nClassIndexOffset;
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
			}

			// f(w,cw)
			aIndex[nOrder-1] = pSeq[h+nOrder-1];
			ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
			if (ppFind) {
				aFindList.Add(ppFind);
			}
		}

		//global gram
		//Ŀǰ��֧��ͬһλ�ò���ͬʱ����word��class��Ϣ,�ҽ���һ��classλ��
		//����order < m_nFullGramLimitedOrder ����������
		if (m_bContainMixGram && nOrder>1 && nOrder < m_nFullGramLimitedOrder)
		{
			/// f(c,c,c,w)
			if ( m_bContainMixGram_cpw  ) 
			{
				for (int i=0; i<nOrder-1; i++)
					aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].wid + m_nWordIndexOffset;
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
				/// Add  Jump����
				if ( m_bContainMixGram_cpw_jump && nOrder >= 3 ) {
					FindJumpFeatures(aFindList, aIndex, nOrder);
				}
			} else if (m_bContainMixGram_wpc ) {
				lout_error("m_bContainMixGram_wpc ���ܻ���PredictNgram���ͻ������");
			}
			else
			{
				//�ἤ���������
				for (int pos=0; pos<nOrder; pos++) //����class��λ��
				{
					for (int i=0; i<nOrder; i++) {
						if ( i != pos ) {//word��Ϣ
							aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
						} else { // class��Ϣ
							aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
						}
					}
					ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
					if (ppFind) {
						aFindList.Add(ppFind);
					}
				}
			}
			
		}

		if (m_bContainJumpNgram)
		{
			// jumpGram����
			VocabID aSeq[c_nMaxOrder];
			memcpy(aSeq, pSeq+h, sizeof(VocabID)*nOrder);
			for (int k=1; k<=nOrder-2; k++) {
				aSeq[k] = VocabID_none;
				ppFind = m_aGramIndex.Find(aSeq, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}

				aSeq[k] = pSeq[h+k];
			}
		}

		//�����ҵ�����������
		for (int n=0; n<aFindList.GetNum(); n++) {
			ppFind = aFindList[n];
			for (int i=0; i<(*ppFind)->GetNum(); i++) {
				int id = (*ppFind)->Get(i);
				if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h)) {
					a.Add(id);
				}
			}
		}
	}

	void MLmodel::FindJumpFeatures(wbArray<wbArray<int>**> &aFindList, VocabID *pIndex, int nOrder)
	{
		VocabID aIndex[ngram_maxOrder];
		bool bFound;
		wbArray<int> **ppFind = NULL;

		if ( nOrder < 3 )
			return;
		
		int nNumMin = 1;
		int nNumMax = nOrder-2;
		if ( nOrder >= m_nFullGramLimitedOrder ) {
			/*
			��nOrder��������趨ֵʱ����������SkipBigram
			*/
			nNumMin = nOrder-2;
			nNumMax = nOrder-2;
		}
		//����ÿ��λ�õ�jump���ܣ�����ֻ����jump��������
		for (int jump_num=nNumMin;  jump_num <=nNumMax; jump_num++) {//jump�ĸ���
			for (int jump_pos=1; jump_pos <=nOrder-1-jump_num; jump_pos++) { //jumpλ��
				//�ȳ�ʼ��ԭʼ������
				for (int i=0; i<nOrder; i++)
					aIndex[i] = pIndex[i];
				//����jump 
				for (int i=jump_pos; i<jump_pos + jump_num; i++) {
					aIndex[i] = VocabID_none;
				}
				//����
				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
				if (ppFind) {
					aFindList.Add(ppFind);
				}
// 				lout<<"[In]\t";
// 				for (int i=0; i<nOrder; i++) {
// 					lout<<aIndex[i]<<" ";
// 				}
// 				lout<<"-> "<<ppFind<<endl;
			}
		}
	}


	void MLmodel::FindFeatures(wbArray<int> &a, VocabID *pSeq, int nLen)
	{
		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			for (int h=0; h<=nLen-nOrder; h++) {
				this->FindFeatures(a, pSeq, nLen, h, nOrder);
			}
		}
	}
// 	void MLmodel::FindFeatures(int *pFeat, int &nFeat, int nMax, VocabID *pSeq, int nLen, int h, int nOrder)
// 	{
// 		VocabID aIndex[ngram_maxOrder];
// 		bool bFound;
// 		wbArray<int> **ppFind = NULL;
// 		wbArray<wbArray<int>**> aFindList;
// 
// 		// ��ͨGram����
// 		if (m_bContainTokenGram) 
// 		{
// 			wbArray<int> **ppFind = m_aGramIndex.Find(pSeq+h, nOrder, bFound);
// 			if (ppFind) {
// 				aFindList.Add(ppFind);
// 			}
// 		}
// 		// Class Gram ����
// 		if (m_bContainClassGram)
// 		{
// 			for (int i=0; i<nOrder; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
// 			ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				aFindList.Add(ppFind);
// 			}
// 		}
// 
// 		// word Gram ����
// 		if (m_bContainWordGram)
// 		{
// 			for (int i=0; i<nOrder; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 			ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				aFindList.Add(ppFind);
// 			}
// 
// 			//word gram ����jump��Ϣ
// 			if ( m_bContainWordGram_jump ) 
// 			{
// 				//����ÿ��λ�õ�jump���ܣ�����ֻ����jump��������
// 				for (int jump_num=1;  jump_num <=nOrder-2; jump_num++) {//jump�ĸ���
// 					for (int jump_pos=1; jump_pos <=nOrder-1-jump_num; jump_pos++) { //jumpλ��
// 						//�ȳ�ʼ��ԭʼ������
// 						for (int i=0; i<nOrder; i++)
// 							aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 						//����jump 
// 						for (int i=jump_pos; i<jump_pos + jump_num; i++) {
// 							aIndex[i] = VocabID_none;
// 						}
// 						//����
// 						ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 						if (ppFind) {
// 							aFindList.Add(ppFind);
// 						}
// 					}
// 				}
// 			}
// 		}
// 
// 		// model M�еĻ������
// 		// ��ʷȫ����word����ǰλ�ÿ���Ϊclass or token����f(w,c) or f(w, cw)
// 		if (m_bContainPredictGram)
// 		{
// 			for (int i=0; i<nOrder-1; i++)
// 				aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset; //��ʷȫ��Ϊword
// 
// 			// f(w,c)
// 			if (nOrder > 1 || m_bContainClassGram==false) { //��order=1ʱ�������������˻�Ϊunigram-class��������ʹ��ͬһ��������������
// 				aIndex[nOrder-1] = m_pVocab->aVocabInfo[pSeq[h+nOrder-1]].cid + m_nClassIndexOffset;
// 				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 				if (ppFind) {
// 					aFindList.Add(ppFind);
// 				}
// 			}
// 
// 			// f(w,cw)
// 			aIndex[nOrder-1] = pSeq[h+nOrder-1];
// 			ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 			if (ppFind) {
// 				aFindList.Add(ppFind);
// 			}
// 		}
// 
// 		//global gram
// 		//Ŀǰ��֧��ͬһλ�ò���ͬʱ����word��class��Ϣ,�ҽ���һ��classλ��
// 		if (m_bContainMixGram && nOrder>1)
// 		{
// 			//�ἤ���������
// 			for (int pos=0; pos<nOrder; pos++) //����class��λ��
// 			{
// 				for (int i=0; i<nOrder; i++) {
// 					if ( i != pos ) {//word��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].wid + m_nWordIndexOffset;
// 					} else { // class��Ϣ
// 						aIndex[i] = m_pVocab->aVocabInfo[pSeq[h+i]].cid + m_nClassIndexOffset;
// 					}
// 				}
// 				ppFind = m_aGramIndex.Find(aIndex, nOrder, bFound);
// 				if (ppFind) {
// 					aFindList.Add(ppFind);
// 				}
// 			}
// 		}
// 
// 		if (m_bContainJumpNgram)
// 		{
// 			// jumpGram����
// 			VocabID aSeq[c_nMaxOrder];
// 			memcpy(aSeq, pSeq+h, sizeof(VocabID)*nOrder);
// 			for (int k=1; k<=nOrder-2; k++) {
// 				aSeq[k] = VocabID_none;
// 				ppFind = m_aGramIndex.Find(aSeq, nOrder, bFound);
// 				if (ppFind) {
// 					aFindList.Add(ppFind);
// 				}
// 
// 				aSeq[k] = pSeq[h+k];
// 			}
// 		}
// 
// 		//�����ҵ�����������
// 		for (int n=0; n<aFindList.GetNum(); n++) {
// 			ppFind = aFindList[n];
// 			for (int i=0; i<(*ppFind)->GetNum(); i++) {
// 				int id = (*ppFind)->Get(i);
// 				if ( ((Ngram*)m_aFeatures[id])->bExAccept(nLen, h)) {
// 					if ( nFeat >= nMax ) {
// 						lout_error("[FindFeatrues] pFeat space ("<<nMax<<") is not enough!!!");
// 					}
// 					pFeat[nFeat++] = id;
// 				}
// 			}
// 		}
// 
// 		
// 	}

	void MLmodel::CleanFeatures()
	{
		model::CleanFeatures();
		m_aGramIndex.Release();
		for (int i=0; i<m_aGramPack.GetNum(); i++)
			SAFE_DELETE(m_aGramPack[i]);
		m_aGramPack.Clean();
	}

	void MLmodel::Reset(int nOrder, int nMaxLen)
	{
		if (nOrder > 2 && m_pVocab->nSize >= 10e3) {
			lout_error("The vocab size over 10e3("<<m_pVocab->nSize<<"), can't afford the memory for order="<<nOrder);
		}
		for (int i=0; i<m_aAlpha.GetNum(); i++)
			SAFE_DELETE(m_aAlpha[i]);
		for (int i=0; i<m_aBeta.GetNum(); i++)
			SAFE_DELETE(m_aBeta[i]);

		for (int i=0; i<=nMaxLen; i++) {
			m_aAlpha[i] = new Msg(nOrder-1, m_pVocab->nSize);
			m_aBeta[i] = new Msg(nOrder-1, m_pVocab->nSize);
		}

// 		for (int i=0; i<m_aClusters.GetNum(); i++)
// 			m_aClusters[i].Clean();
// 		m_aClusters.Clean();
	}

	/// AllocateFeature ����������Ҫ��Cluster����������ʵ�ʷ���featrues
	void MLmodel::AllocateFeatrues(int nLen)
	{
		int nMaxCluster = nLen - m_nOrder;
		nMaxCluster = (nMaxCluster < 0)? 0: nMaxCluster; //��ҪС����
		m_nClusterNum = nMaxCluster + 1;

// 		for (int i=0; i<m_aClusters.GetNum(); i++)
// 			m_aClusters[i].Clean();
// 		m_aClusters.Clean();
// 
// 		for (int h=0; h<nLen; h++)
// 		{
// 			wbArray<GramPack> *pCurCluster = &( m_aClusters[min(h, nMaxCluster)] );
// 			GramPack curPack;
// 
// 			for (int i=0; i<m_aFeatures.GetNum(); i++)
// 			{
// 				SuperNgram *pSuper;
// 				switch(m_aFeatures[i]->type) {
// 				case ngram:;
// 				case jgram:
// 					curPack.nFeatId = i;
// 					curPack.nPos = h;
// 					pCurCluster->Add(curPack);
// 					break;
// 				case super:
// 					pSuper = (SuperNgram *)m_aFeatures[i];
// 					if (nLen >= pSuper->len_min && nLen <= pSuper->len_max &&
// 						h >= pSuper->pos_min && h <= pSuper->pos_max) 
// 					{
// 							curPack.nFeatId = i;
// 							curPack.nPos = h;
// 							pCurCluster->Add(curPack);
// 					}
// 						
// 					break;
// 				default:;
// 				}
// 			}
// 		}
	}

	LogP MLmodel::ClusterSum(VocabID *pSeq, int nLen, int h)
	{
		//wbArray<GramPack> *pCluster = &m_aClusters[h];

		if ( h>m_nClusterNum-1)
			return Logp_Zero;

		LogP dSum = 0;
// 		for (int i=0; i<pCluster->GetNum(); i++) {
// 			GramPack pack = m_aClusters[h][i];
// 			Feature *pFeat = m_aFeatures[pack.nFeatId];
// 			if ( pFeat->bAccept(pSeq, nLen, pack.nPos) ) {
// 				dSum += m_aValues[pack.nFeatId];
// 			}
// 		}

		wbArray<int> a; /// �����ҵ���ƥ���feature
		for (int nOrder=1; nOrder<=m_nOrder; nOrder++) {
			a.Clean();
			FindFeatures(a, pSeq, nLen, h, nOrder);
			for (int i=0; i<a.GetNum(); i++) {
				dSum += m_aValues[a[i]];
			}
		}

		if ( h == m_nClusterNum-1 ) {
			/// ���һ��cluster��Ҫ�ж��������
			for (int nh=h+1; nh<nLen; nh++) {
				for (int nOrder=1; nOrder<=nLen-nh; nOrder++) {
					a.Clean();
					FindFeatures(a, pSeq, nLen, nh, nOrder);
					for (int i=0; i<a.GetNum(); i++) {
						dSum += m_aValues[a[i]];
					}
				}
			}
		}

		return dSum;
	}

	void MLmodel::Forward(int nLen)
	{
// 		if (m_aAlpha.GetNum() == 0) {
// 			lout_assert(m_nOrder>0);
// 			Reset(m_nOrder, m_nMaxLen);
// 		}

		m_aAlpha[0]->Fill(Prob2LogP(1));

		int aSeq[c_nMaxLen];
		for (int h=1; h<m_nClusterNum; h++)
		{
			VecIter iter(aSeq+h, m_nOrder-1, 0, m_pVocab->nSize-1);
			while (iter.bGood()) {
				double dLogSum = Logp_Zero;
				for (aSeq[h-1]=0; aSeq[h-1]<m_pVocab->nSize; aSeq[h-1]++) {
					LogP temp = ClusterSum(aSeq, nLen, h-1) + m_aAlpha[h-1]->Get(aSeq+h-1, m_nOrder-1);
					dLogSum = Log_Sum(dLogSum, temp);
				}
				m_aAlpha[h]->Get(aSeq+h, m_nOrder-1) = dLogSum;
				iter.Next();
			}
		}
	}

	void MLmodel::Backward(int nLen)
	{
// 		if (m_aBeta.GetNum() == 0) {
// 			lout_assert(m_nOrder>0);
// 			Reset(m_nOrder, m_nMaxLen);
// 		}

		m_aBeta[m_nClusterNum]->Fill(Prob2LogP(1));

		int aSeq[c_nMaxLen];
		for (int h=m_nClusterNum-1; h>=1; h--)
		{
			//lout<<"["<<m_aClusters[h].GetNum()<<"] ";
			VecIter iter(aSeq+h, m_nOrder-1, 0, m_pVocab->nSize-1);
			while (iter.bGood()) {
				double dLogSum = Logp_Zero;
				for (VocabID x=0; x<m_pVocab->nSize; x++) {
					aSeq[h+m_nOrder-1] = x;
					double temp = ClusterSum(aSeq, nLen, h) + m_aBeta[h+1]->Get(aSeq+h+1, m_nOrder-1);
					dLogSum = Log_Sum(dLogSum, temp);
				}
				m_aBeta[h]->Get(aSeq+h, m_nOrder-1) = dLogSum;
				iter.Next();
			}
		}
	}

	LogP MLmodel::Normalization(int nLen)
	{
		int aSeq[c_nMaxLen];
		LogP dLogSum = Logp_Zero;

		if (nLen<=2 || nLen < m_nOrder)
		{
			VecIter iter(aSeq, nLen, 0, m_pVocab->nSize-1);
			while (iter.bGood()) {
				double temp = GetLogProb(aSeq, nLen, false);
				dLogSum = Log_Sum(dLogSum, temp);
				iter.Next();

// 				if (nLen == 1)
// 					lout_variable(dLogSum);
			}
		} 
		else 
		{
			AllocateFeatrues(nLen);
			Backward(nLen);
			VecIter iter(aSeq, m_nOrder, 0, m_pVocab->nSize-1);
			while (iter.bGood()) {
				double temp = ClusterSum(aSeq, nLen, 0) + m_aBeta[1]->Get(aSeq+1,m_nOrder-1);
				dLogSum = Log_Sum(dLogSum, temp);
				iter.Next();
			}

// 			Forward(nLen);
// 			VecIter iter(aSeq+nLen-m_nOrder, m_nOrder, 0, m_pVocab->nSize-1);
// 			while (iter.bGood()) {
// 				double temp = ClusterSum(aSeq, nLen, nLen-m_nOrder) + m_aAlpha[nLen-m_nOrder]->Get(aSeq+nLen-m_nOrder, m_nOrder-1);
// 				dLogSum = Log_Sum(dLogSum, temp);
// 				iter.Next();
// 			}
		}
		
		

		return dLogSum;
	}

	void MLmodel::Normalization(bool bPrint /* = false */)
	{
		for (int len=0; len<=m_nMaxLen; len++) {
			m_aLogNormFactors[len] = Normalization(len);
			if (bPrint)
				lout<<"["<<len<<"/"<<m_nMaxLen<<"] "<<m_aLogNormFactors[len]<<endl;
		}


		m_logNormalizationFactor = Logp_Zero;
		for (int len=0; len<=m_nMaxLen; len++) {
			m_logNormalizationFactor = Log_Sum(m_logNormalizationFactor, m_aLogNormFactors[len]);
		}
	}

// 	LogP MLmodel::GetLogProb(int nLen, int h, VocabID *pGram)
// 	{
// 		if (h + m_nOrder > nLen)
// 			return Logp_Zero;
// 
// 		VocabID aSeq[c_nMaxLen];
// 		memcpy(aSeq+h, pGram, sizeof(VocabID)*m_nOrder);
// 
// 		LogP logprob = m_aAlpha[h]->Get(pGram, m_nOrder-1) + ClusterSum(aSeq, nLen, h) + m_aBeta[h+1]->Get(pGram+1, m_nOrder-1);
// 		return NormalizeProb(logprob);
// 	}

	LogP MLmodel::MarginalizeLogProb(int nLen, int h, VocabID *pGram, int nDim)
	{
		if (h + nDim > nLen)
			return Logp_Zero;

		VocabID aSeq[c_nMaxLen];
		LogP logprob = Logp_Zero;

		if (nLen < m_nOrder) {  ///���Ⱥ�С�����

			VecIter iter(aSeq, nLen, 0, m_pVocab->nSize-1);
			while (iter.bGood()) {
				bool bEqual = true;
				for (int i=0; i<nDim; i++) {
					if ( aSeq[h+i] != pGram[i] ) {
						bEqual = false;
						break;
					}
				}
				if (bEqual)
					logprob = Log_Sum(logprob, GetLogProb(aSeq, nLen));
				iter.Next();
			}

			return logprob;
		}

		if (nDim == m_nOrder) {
			memcpy(aSeq+h, pGram, sizeof(VocabID)*m_nOrder);

			logprob = m_aAlpha[h]->Get(pGram, m_nOrder-1) + ClusterSum(aSeq, nLen, h) + m_aBeta[h+1]->Get(pGram+1, m_nOrder-1);
		} else {
			///ѡ��һ������pGram��claster
			logprob = Logp_Zero;

			if ( h<= nLen - m_nOrder ) ///�����
			{
				memcpy(aSeq+h, pGram, sizeof(VocabID)*nDim);
				VecIter iter(aSeq+h+nDim, m_nOrder-nDim, 0, m_pVocab->nSize-1);
				while(iter.bGood()) {
					logprob = Log_Sum( logprob,
						m_aAlpha[h]->Get(aSeq+h, m_nOrder-1) + ClusterSum(aSeq, nLen, h) + m_aBeta[h+1]->Get(aSeq+h+1, m_nOrder-1) );
					iter.Next();
				}
			}
			else  //ʹ�����һ��cluster�����ڴ���λ�ÿ��ܳ�����cluster�м䣨�Ǳ߽磩����˷����������m_nOrderά����
			{
				int nH = nLen-m_nOrder;  ///clusterλ��
				VecIter iter(aSeq+nH, m_nOrder, 0, m_pVocab->nSize-1);
				while (iter.bGood()) {
					bool bEqual = true;
					for (int i=0; i<nDim; i++) {
						if ( aSeq[h+i] != pGram[i] ) {
							bEqual = false;
							break;
						}
					}
					if (bEqual)
						logprob = Log_Sum( logprob, 
							m_aAlpha[nH]->Get(aSeq+nH, m_nOrder-1) + ClusterSum(aSeq, nLen, nH) );
					iter.Next();
				}
			}
		}

		return NormalizeProb(logprob, nLen);
	}

	LogP MLmodel::LogExpectation(int nLen, int i)
	{
		VocabID aSeq[c_nMaxLen];
		LogP logSum = Logp_Zero;

		if (m_aFeatures[i]->type == base)
			lout_error("ML���ƽ�֧��Ngram���͵�����");

		Ngram *pFeatrue = (Ngram*)m_aFeatures[i];
		int nOrder = pFeatrue->order;
		for (int h=0; h<=nLen-nOrder; h++)  //����ÿ��λ��
		{
			if (pFeatrue->type <= super) {
				SupIter iter(aSeq+h, nOrder, 0, m_pVocab->nSize-1, pFeatrue->flag);
				while (iter.bGood()) {
					if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
						logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
					}
					iter.Next();
				}
			} else if (pFeatrue->type == cgram) {  //Class Gram
				DimIter iter(aSeq+h, nOrder);
				for (int k=0; k<nOrder; k++)
					iter.m_aDimArray.Add( &( m_pVocab->aClassToTokens[pFeatrue->flag[k]] ) );
				iter.Init();
				while (iter.bGood()) {
					if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
						logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
					}
					iter.Next();
				}
			} else if (pFeatrue->type == wgram) { //word Gram
				DimIter iter(aSeq+h, nOrder);
				for (int k=0; k<nOrder; k++)
					iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pFeatrue->flag[k]] ) );
				iter.Init();
				while (iter.bGood()) {
					if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
						logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
					}
					iter.Next();
				}
			} else if (pFeatrue->type == pgram) { // Predict Gram
				PredictNgram *pPre = (PredictNgram*)pFeatrue;

				// f(w,c)
				if ( pPre->flag[pPre->order-1] == VocabID_none )
				{
					DimIter iter(aSeq+h, nOrder); 
					for (int k=0; k<nOrder-1; k++) //ǰnOrder-1ά��word
						iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pPre->flag[k]] ) );
					iter.m_aDimArray.Add( &( m_pVocab->aClassToTokens[pPre->c] )  ); //���һά��class
					iter.Init();
					while (iter.bGood()) {
						if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
							logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
						}
						iter.Next();
					}

				} 
				else // f(w, cw)
				{
					if (nOrder == 1) {
						aSeq[h+nOrder-1] = m_pVocab->FindToken(pPre->flag[nOrder-1], pPre->c);
						if (pFeatrue->bAccept(aSeq, nLen, h))
							logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
					} else {
						DimIter iter(aSeq+h, nOrder-1); //��ǰnOrder-1�����б���
						for (int k=0; k<nOrder-1; k++)
							iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pFeatrue->flag[k]] ) );
						aSeq[h+nOrder-1] = m_pVocab->FindToken(pPre->flag[nOrder-1], pPre->c); //���һ��ΪToken
						iter.Init();
						while (iter.bGood()) {
							if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
								logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
							}
							iter.Next();
						}
					}
				}

			} else if (pFeatrue->type == ggram) {
				//ggram����֧��ÿ��λ�ô���ͬʱ����wrod��class��Ϣ
				GlobalNgram *pGlobal = (GlobalNgram*)pFeatrue;

				DimIter iter(aSeq+h, nOrder); 
				for (int k=0; k<nOrder; k++) {
					if ( pGlobal->flag[k] != VocabID_none && pGlobal->cflag[k] != VocabID_none ) {
						lout_error("[MLmodel] ��֧��GlobalNgram��ͬһλ��ͬʱ����word��class��Ϣ");
					} else if ( pGlobal->flag[k] != VocabID_none ) {
						iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pGlobal->flag[k]] ) ); // word
					} else if ( pGlobal->cflag[k] != VocabID_none ) {
						iter.m_aDimArray.Add( &( m_pVocab->aClassToTokens[pGlobal->cflag[k]] )  ); //class
					} else {
						lout_error("[MLmodel] ��֧��GlobalNgram��ͬ����Jump��ʽ");
					}
				}
				iter.Init();
				while (iter.bGood()) {
					if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
						logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
					}
					iter.Next();
				}
			}
		} // for h

		return logSum;
	}

	void MLmodel::LogExpectation(int nLen, LogP *pdExp)
	{
		ForwardBackward(nLen);

		//VocabID aSeq[c_nMaxLen];
		for (int i=0; i<m_nFeatNum; i++)
		{
			/*
			LogP logSum = Logp_Zero;

			if (m_aFeatures[i]->type == base)
				lout_error("ML���ƽ�֧��Ngram���͵�����");

			Ngram *pFeatrue = (Ngram*)m_aFeatures[i];
			int nOrder = pFeatrue->order;
			for (int h=0; h<=nLen-nOrder; h++)  //����ÿ��λ��
			{
				if (pFeatrue->type <= super) {
					SupIter iter(aSeq+h, nOrder, 0, m_pVocab->nSize-1, pFeatrue->flag);
					while (iter.bGood()) {
						if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
							logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
						}
						iter.Next();
					}
				} else if (pFeatrue->type == cgram) {  //Class Gram
					 DimIter iter(aSeq+h, nOrder);
					 for (int k=0; k<nOrder; k++)
						iter.m_aDimArray.Add( &( m_pVocab->aClassToTokens[pFeatrue->flag[k]] ) );
					 iter.Init();
					 while (iter.bGood()) {
						 if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
							 logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
						 }
						 iter.Next();
					 }
				} else if (pFeatrue->type == wgram) { //word Gram
					DimIter iter(aSeq+h, nOrder);
					for (int k=0; k<nOrder; k++)
						iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pFeatrue->flag[k]] ) );
					iter.Init();
					while (iter.bGood()) {
						if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
							logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
						}
						iter.Next();
					}
				} else if (pFeatrue->type == pgram) { // Predict Gram
					PredictNgram *pPre = (PredictNgram*)pFeatrue;

					// f(w,c)
					if ( pPre->flag[pPre->order-1] == VocabID_none )
					{
						DimIter iter(aSeq+h, nOrder); 
						for (int k=0; k<nOrder-1; k++) //ǰnOrder-1ά��word
							iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pPre->flag[k]] ) );
						iter.m_aDimArray.Add( &( m_pVocab->aClassToTokens[pPre->c] )  ); //���һά��class
						iter.Init();
						while (iter.bGood()) {
							if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
								logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
							}
							iter.Next();
						}
					
					} 
					else // f(w, cw)
					{
						if (nOrder == 1) {
							aSeq[h+nOrder-1] = m_pVocab->FindToken(pPre->flag[nOrder-1], pPre->c);
							if (pFeatrue->bAccept(aSeq, nLen, h))
								logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
						} else {
							DimIter iter(aSeq+h, nOrder-1); //��ǰnOrder-1�����б���
							for (int k=0; k<nOrder-1; k++)
								iter.m_aDimArray.Add( &( m_pVocab->aWordToTokens[pFeatrue->flag[k]] ) );
							aSeq[h+nOrder-1] = m_pVocab->FindToken(pPre->flag[nOrder-1], pPre->c); //���һ��ΪToken
							iter.Init();
							while (iter.bGood()) {
								if ( pFeatrue->bAccept(aSeq, nLen, h) ) {
									logSum = Log_Sum(logSum, MarginalizeLogProb(nLen, h, aSeq+h, nOrder));
								}
								iter.Next();
							}
						}
					}

					
				}
			}
			*/
			pdExp[i] = LogExpectation(nLen, i); //logSum;
		}

// 		for (int i=0; i<3; i++)
// 			lout<<pdExp[i]<<endl;
	}

	void MLmodel::LogExpectation(LogP *pdExp)
	{
		//memset(pdExp, 0, sizeof(pdExp[0])*m_aFeatures.GetNum());

		//��ʼ��
		for (int i=0; i<m_nFeatNum; i++)
			pdExp[i] = Logp_Zero; 

		wbArray<LogP> aTemp(m_nFeatNum);
		for (int len=0; len<=m_nMaxLen; len++) {
			LogExpectation(len, aTemp);
			for (int i=0; i<m_nFeatNum; i++)
				pdExp[i] = Log_Sum(pdExp[i], aTemp[i]);

//			lout<<len<<" "<<LogP2Prob(aTemp[26])<<endl;
		}
	}
}