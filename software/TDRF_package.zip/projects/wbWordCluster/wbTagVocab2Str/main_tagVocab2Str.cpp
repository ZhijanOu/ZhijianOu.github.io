/**
 * \dir
 * \author wangbin
 * \date 2014-03-26
 * \todo ���������ļ��еĴʺ�ת���ɴʣ����ڲ鿴
 * \brief ���������ļ��еĴʺ�ת���ɴʣ����ڲ鿴
*/
/**
 * \file
 * \author wangbin
 * \date 2014-03-26
 * \brief [main]
 */

#include "wbSystem.h"
#include "wbSystem.cpp"
#include "wbVocab.h"

static char *cfg_pathInput = NULL;
static char *cfg_pathOutput = NULL;
static char *cfg_pathVocab = NULL;

wbOption options[] = {
	{wbOPT_STRING, "in", &cfg_pathInput, "����"},
	{wbOPT_STRING, "out", &cfg_pathOutput, "���"},
	{wbOPT_STRING, "vocab", &cfg_pathVocab, "�ֵ�"}
};

_wbMain
{

	wbOpt_Parse(options);

	wbVocab v;
	v.ReadT(cfg_pathVocab);

	wbFile fIn(cfg_pathInput, "rt");
	wbFile fOut(cfg_pathOutput, "wt");

	char *pLine;
	while (pLine = fIn.GetLine(true)) {
		char *p = strtok(pLine, " \t");
		while (p) {
			if ( *p >= '0' && *p <= '9' ) {
				fOut.Print("%s ", v.aWords[atoi(p)].GetBuffer());
			} else {
				fOut.Print("%s ", p);
			}
			p = strtok(NULL, " \t");
		}
		fOut.Print("\n");
	}


	return 1;
};